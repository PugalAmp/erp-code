#
# TABLE STRUCTURE FOR: installer
#

DROP TABLE IF EXISTS `installer`;

CREATE TABLE `installer` (
  `id` int NOT NULL,
  `installer_flag` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `installer` (`id`, `installer_flag`) VALUES (1, 1);


#
# TABLE STRUCTURE FOR: tbl_account_details
#

DROP TABLE IF EXISTS `tbl_account_details`;

CREATE TABLE `tbl_account_details` (
  `account_details_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `fullname` varchar(160) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `employment_id` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `warehouse_id` int DEFAULT NULL,
  `company` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `city` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `locale` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'en_US',
  `address` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '-',
  `phone` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '-',
  `mobile` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '',
  `skype` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT '',
  `language` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'english',
  `designations_id` int DEFAULT '0',
  `avatar` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'uploads/default_avatar.jpg',
  `joining_date` date DEFAULT NULL,
  `present_address` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `maratial_status` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `father_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mother_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `passport` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `direction` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`account_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci ROW_FORMAT=COMPACT;

INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('5', 5, 'HAYAT MANPOWER.AE', NULL, NULL, NULL, NULL, NULL, 'en_US', '-', '+971-564803937', '', '', 'english', 0, 'uploads/Untitled.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('6', 6, 'KARTHIK VENKATAPATHY', 'HJ1002', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 3, 'uploads/pp-pica.png', '2025-06-10', '', '1988-07-20', 'male', 'married', 'Venkatapathy', 'Amutha', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('8', 8, 'YAHYA MUZEMIL HUSENN', 'HJ1004', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/photo.jpg', '2025-06-10', '', '2000-12-04', 'male', 'married', 'Muzemil Hussain', 'Hussain', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('9', 9, 'JOEL KISILA', 'HJ1005', NULL, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PHOTO.jpeg', '2025-06-10', '', '1985-11-21', 'male', 'married', 'Kisila', 'Kisila', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('10', 10, 'ERIC AIDOO', 'HJ1006', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/Capture.JPG', '2025-06-10', '', '1994-12-24', 'male', 'married', 'Aidoo', 'Aidoo', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('12', 12, 'AYASH JEMAL ADEM', 'HJ1007', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/photo.jpg', '2025-06-10', '', '2001-12-13', 'male', 'married', 'Adem', 'Adem', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('13', 13, 'ABDURAHMAN SHUKARI JILO', 'HJ1008', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PP2.jpg', '2025-06-10', '', '2002-09-27', 'male', 'married', 'Abdulrahman', 'Shukari', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('14', 14, 'JEMAL HASSEN TURKE', 'HJ1009', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PH.png', '2025-06-10', '', '2000-01-21', 'male', 'married', 'Turke', 'Turke', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('15', 15, 'UMER HUSSEN MAMA', 'HJ1010', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/photo.png', '2025-06-10', '', '2000-08-06', 'male', 'married', 'Hussan', 'Mama', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('16', 16, 'DIRIBA GOSA BEKELE', 'HJ1011', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PHOTO-pica.png', '2025-06-10', '', '1998-05-03', 'male', 'married', 'Bekele', 'Gosa', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('17', 17, 'ADISU TESHOME BOGE', 'HJ1012', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/ph.png', '2025-06-10', '', '1998-11-16', 'male', 'married', 'Teshome', 'Boge', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('18', 18, 'EFREM ZEMACHU MENGISTU', 'HJ1013', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/ph.jpeg', '2025-06-10', '', '2002-02-11', 'male', 'married', 'Zemachu', 'Mengistu', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('19', 19, 'AJAIB HAMDA GENEMO', 'HJ1014', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/AJAIB_HAMDA_GENEMO_PHOTO.jpg', '2025-06-10', '', '2000-01-27', 'male', 'married', 'Hamda', 'Genemo', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('20', 20, 'ABDULJEBAR AMANO DELCHA', 'HJ1015', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/Photo.jpg', '2025-06-10', '', '1997-12-25', 'male', 'married', 'Amano', 'Delcha', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('23', 23, 'HAJI HUSEN KUSU', 'HJ1021', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/WhatsApp_Image_2025-06-17_at_6_13_21_AM.jpeg', '2025-08-13', '', '2001-05-29', 'male', 'married', 'Husen', 'Kusu', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('24', 24, 'JAINULABUDEEN AHIYA', 'HJ1022', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PH.JPG', '2025-08-13', '', '1975-12-07', 'male', 'married', 'Ahiya', 'Hameed Natchiya', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('25', 25, 'MURTEDA MUKTAR', 'HJ1019', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/photo.jpg', '2025-06-10', '', '2002-01-24', 'male', 'married', 'Bashir', 'Muktar', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('26', 26, 'GUTAMA LENCHO', 'HJ1020', 2, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/2.jpg', '2025-08-13', '', '2000-06-02', 'male', 'married', 'LENCHO ', 'TUKE', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('29', 29, 'ANANIOUS RONNY BYMAZIMA', 'HT1025', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/or.jpeg', '2025-09-15', '', '1999-06-04', 'male', 'married', 'Byamazima', 'Ronny', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('30', 30, 'JOSEPH GAKURU GITONGA', 'HT1026', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/photo.jpg', '2025-09-15', '', '1999-08-17', 'male', 'married', 'Gitonga', 'Gakuru', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('31', 31, 'SOLOMON GANDAA', 'HT1027', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/photo.jpg', '2025-09-15', '', '1988-11-28', 'male', 'married', 'Gandaa', 'Gandaa', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('32', 32, 'AWOL SIRAJ AHMED', 'HT1029', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 10, 'uploads/photo.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('33', 33, 'CHINNAIYAN MANIKKAM', 'HT1030', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 10, 'uploads/photo.jpg', '2025-09-15', '', '1991-05-11', 'male', 'married', 'Manikkam', 'Sellammal', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('34', 34, 'ISAAC HAYFORD', 'HT1031', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 11, 'uploads/photo.jpg', '2025-09-15', '', '1986-06-01', 'male', 'married', 'Isaac', 'Hayford', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('35', 35, 'PERIYASAMY CHINNASAMY', 'HT1033', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/Periyasamy.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('36', 36, 'RICHMOND OFORI', 'HT1034', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/photo.jpg', '2025-09-15', '', '1997-12-19', 'male', 'married', 'Richmond', 'Ofori', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('37', 37, 'GIDEON BADU', 'HT1035', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/PH-.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('38', 38, 'PRINCE OSEI', 'HT1036', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/photo.jpeg', '2001-01-01', '', '2005-10-09', 'male', 'married', 'Prince', 'Osei', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('39', 39, 'KARTHIKEYAN SELVARAJ', 'HT1043', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 12, 'uploads/ph-.jpg', '2025-10-09', '', '2000-07-24', 'male', 'married', 'Selvaraj', 'Kaliyammal', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('40', 40, 'PANJAVARNAM THIRUMURUGAN', 'HT1045', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/photo.jpeg', '2025-10-09', '', '1982-02-15', 'male', 'married', 'Panjavarnam', 'Mari', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('41', 41, 'FRANK OSEI', 'HT1046', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/Photo.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('42', 42, 'EMMANUEL ACKAH', 'HT1048', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/photo.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('43', 43, 'ISSAC OPOKU', 'HT1049', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/photo.jpg', '2025-10-09', '', '1996-09-08', 'male', 'married', 'Issac', 'Opokku', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('44', 44, 'EMMANUEL EFFUM', 'HT1050', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/P.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('45', 45, 'ISSAH AHMED', 'HT1051', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 5, 'uploads/PH-.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('46', 46, 'COLLINS BOYE', 'HT1052', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/1.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('47', 47, 'ELIJAH YENNUBE LAARI', 'HT1053', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/P-.jpeg', '0202-10-20', '', '2001-11-09', 'male', 'married', 'Yennube', 'Laari', '', 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('48', 48, 'EMILE NSHEMEZIMANA', 'HT1056', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/P-.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('49', 49, 'THERENCE NITANGA', 'HT1058', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/P.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('50', 50, 'PRIMACY MURINDWA', 'HT1061', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/P.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('51', 51, 'BISMARK MINTAH', 'HT1063', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 5, 'uploads/P-.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('52', 52, 'ANDREW LUVUUMA', 'HT1064', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/p--p.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('53', 53, 'JEAN MARIE SINIREMERA', 'HT1065', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 5, 'uploads/FFFFF_page-0001.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('54', 54, 'EMMANUEL OFORI', 'HT1066', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 5, 'uploads/P.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('55', 55, 'BALPOLO KWABENA BIIFA', 'HT1068', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/P-.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('56', 56, 'LATIF INUSAH', 'HT1069', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 5, 'uploads/P.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('57', 57, 'SADIQUE ALI KAVUNGATHODI', 'HT1070', 0, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 1, 'uploads/PH.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('58', 58, 'RANJITHKUMAR PALANIVEL', 'HT1071', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 12, 'uploads/pp1-.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('59', 59, 'EBENEZER SENIOR KWAKYE', 'HT1072', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 7, 'uploads/P.JPG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('60', 60, 'KELVIN LORD BUABENG ASANTE', 'HT1073', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 6, 'uploads/p-.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('61', 61, 'AMOS KWABENA ATTA', 'HT1074', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/WhatsApp_Image_2025-12-19_at_5_08_03_AM.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('62', 62, 'EMMANUEL KOFI AGYAPONG', 'HT1075', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/WhatsApp_Image_2025-12-20_at_1_15_36_PM.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('63', 63, 'DANIEL ANNOR', 'HT1099', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 10, 'uploads/PHOTO.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('64', 64, 'DAVID SAKYI', 'HT1098', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/P.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('65', 65, 'DEVASUNDAR RASAPAN RASAPAN', 'HT1097', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/PDFGallery_20260205_205039_page-0001.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('66', 66, 'ALEX OPOKU', 'HT1096', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/p.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('67', 67, 'MICHAEL OPPONG', 'HT1094', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/PHOTO.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('68', 68, 'BISMARK SARPONG OWUSU', 'HT1092', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/FFF.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('69', 69, 'SHOWKAT AHMAD PADAR ABDUL RASHID PADAR', 'HT1089', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 9, 'uploads/PHOTO_NEW.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('70', 70, 'MORO ALI', 'HT1080', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/SS.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('71', 71, 'JOUHARA JAFAR JAFAR KOYILLATH', 'HT1079', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/photo.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('72', 72, 'SAMPSON ASIEDU', 'HT1078', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PHOTO_Nero_AI_Image_Upscaler_Photo_Face.jpeg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('73', 73, 'IBRAHIM ABDUL AZIZ', 'HT1077', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/PHOTO.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('74', 74, 'JAMES POURSAH KONFAREH', 'HT1076', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/123.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ltr');
INSERT INTO `tbl_account_details` (`account_details_id`, `user_id`, `fullname`, `employment_id`, `warehouse_id`, `company`, `city`, `country`, `locale`, `address`, `phone`, `mobile`, `skype`, `language`, `designations_id`, `avatar`, `joining_date`, `present_address`, `date_of_birth`, `gender`, `maratial_status`, `father_name`, `mother_name`, `passport`, `direction`) VALUES ('75', 75, 'AFZAL BABU KHAN', 'HJ1024', 1, '0', NULL, NULL, 'en_US', '-', '', '', '', 'english', 8, 'uploads/photo.png', '2025-08-13', '', '1973-03-07', 'male', 'married', 'Babu khan', 'Shehzadi babu khan', '', 'ltr');


#
# TABLE STRUCTURE FOR: tbl_accounts
#

DROP TABLE IF EXISTS `tbl_accounts`;

CREATE TABLE `tbl_accounts` (
  `account_id` int NOT NULL AUTO_INCREMENT,
  `account_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `account_number` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_person` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bank_details` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_activities
#

DROP TABLE IF EXISTS `tbl_activities`;

CREATE TABLE `tbl_activities` (
  `activities_id` int NOT NULL AUTO_INCREMENT,
  `user` int NOT NULL,
  `module` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  `activity` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `activity_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `icon` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'fa-coffee',
  `link` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `value1` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `value2` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `deleted` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`activities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=365 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (46, 5, 'settings', 5, 'activity_save_general_settings', '2025-11-02 15:14:27', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (47, 5, 'settings', 5, 'activity_save_system_settings', '2025-11-02 15:17:11', 'fa-coffee', NULL, 'english', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (48, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:02:37', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (49, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:03:57', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (50, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:06:48', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (51, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:07:09', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (52, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:08:10', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (53, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:08:41', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (54, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 16:11:08', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (55, 5, 'settings', 5, 'activity_save_theme_settings', '2025-11-02 17:25:48', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (56, 5, 'warehouse', 1, 'activity_save_warehouse', '2025-11-02 17:29:28', 'fa-circle-o', NULL, 'WH1 WH1', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (57, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 17:34:45', 'fa-coffee', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (58, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 17:34:45', 'fa-coffee', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (59, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 17:34:45', 'fa-coffee', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (60, 5, 'user', 6, 'activity_added_new_user', '2025-11-02 17:34:59', 'fa-user', NULL, 'karthik', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (61, 5, 'user', 1, 'activity_change_status', '2025-11-02 17:35:34', 'fa-user', NULL, '1', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (62, 5, 'user', 4, 'activity_change_status', '2025-11-02 17:35:48', 'fa-user', NULL, 'adminko Deactive', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (63, 5, 'user', 1, 'activity_change_status', '2025-11-02 17:35:52', 'fa-user', NULL, 'admin Active', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (64, 5, 'user', 1, 'activity_change_status', '2025-11-02 17:35:52', 'fa-user', NULL, 'admin Deactive', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (65, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 21:09:04', 'fa-coffee', NULL, 'Super Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (66, 5, 'user', 7, 'activity_added_new_user', '2025-11-02 21:09:13', 'fa-user', NULL, 'premj', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (67, 5, 'user', 6, 'activity_added_new_user', '2025-11-02 21:14:50', 'fa-user', NULL, 'karthik', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (68, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 21:18:35', 'fa-coffee', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (69, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 21:18:35', 'fa-coffee', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (70, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-02 21:18:35', 'fa-coffee', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (71, 5, 'user', 8, 'activity_added_new_user', '2025-11-02 21:18:47', 'fa-user', NULL, 'YAHYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (72, 5, 'settings', 5, 'activity_update_profile', '2025-11-03 08:40:36', 'fa-coffee', NULL, 'HAYAT JADIDA GROUPS', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (73, 5, 'departments', 1, 'activity_added_a_department', '2025-11-03 10:54:06', 'fa-coffee', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (74, 5, 'user', 6, 'activity_added_new_user', '2025-11-03 13:05:25', 'fa-user', NULL, 'karthik', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (75, 5, 'user', 6, 'activity_added_new_user', '2025-11-03 13:06:34', 'fa-user', NULL, 'karthik', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (76, 5, 'user', 8, 'activity_added_new_user', '2025-11-03 13:07:28', 'fa-user', NULL, 'YAHYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (77, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-03 13:08:10', 'fa-coffee', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (78, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-03 13:08:28', 'fa-coffee', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (79, 5, 'departments', NULL, 'activity_added_a_department', '2025-11-03 13:09:23', 'fa-coffee', NULL, 'LABOUR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (80, 5, 'warehouse', 2, 'activity_save_warehouse', '2025-11-06 09:41:58', 'fa-circle-o', NULL, 'HK House Keeping', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (81, 5, 'user', 9, 'activity_added_new_user', '2025-11-06 09:42:22', 'fa-user', NULL, 'joel', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (82, 5, 'settings', 1, 'activity_added_a_leave_category', '2025-11-06 09:54:04', 'fa-coffee', NULL, 'SICK', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (83, 5, 'settings', 2, 'activity_added_a_leave_category', '2025-11-06 09:55:08', 'fa-coffee', NULL, 'HOLIDAY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (84, 5, 'settings', 3, 'activity_added_a_leave_category', '2025-11-06 09:55:26', 'fa-coffee', NULL, 'FESTIVAL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (85, 5, 'payroll', 1, 'activity_salary_template_delete', '2025-11-06 10:01:34', 'fa-money', NULL, '1200', '700', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (86, 5, 'payroll', NULL, 'activity_hourly_template_added', '2025-11-06 10:02:12', 'fa-money', NULL, '4.5', '4.5', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (87, 5, 'payroll', 1, 'activity_salary_details_update', '2025-11-06 10:03:01', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (88, 5, 'payroll', 1, 'activity_salary_details_update', '2025-11-06 10:03:35', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (89, 5, 'payroll', 1, 'activity_salary_details_update', '2025-11-06 10:04:47', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (90, 5, 'settings', 2, 'customer_group_added', '2025-11-06 10:08:57', 'fa-coffee', NULL, 'Man Power Supply', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (91, 5, 'client', 2, 'activity_update_company', '2025-11-07 19:30:22', 'fa-user', NULL, 'World Star', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (92, 5, 'settings', 3, 'customer_group_added', '2025-11-07 19:33:18', 'fa-coffee', NULL, 'Civil', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (93, 5, 'settings', 4, 'customer_group_added', '2025-11-07 19:37:55', 'fa-coffee', NULL, 'Skilled', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (94, 5, 'settings', 5, 'customer_group_added', '2025-11-07 19:38:08', 'fa-coffee', NULL, 'Unskilled', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (95, 5, 'projects', 1, 'activity_save_project', '2025-11-07 19:38:56', 'fa-folder-open-o', 'admin/projects/project_details/1', 'Construction Civil', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (96, 5, 'projects', 2, 'activity_save_project', '2025-11-07 19:40:33', 'fa-folder-open-o', 'admin/projects/project_details/2', 'Construction Civil Skilled', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (97, 5, 'projects', 1, 'activity_update_project', '2025-11-07 19:40:54', 'fa-folder-open-o', 'admin/projects/project_details/1', 'Construction Civil Unskilled', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (98, 5, 'projects', 2, 'activity_update_project', '2025-11-07 19:42:17', 'fa-folder-open-o', 'admin/projects/project_details/2', 'Construction Civil Skilled', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (99, 5, 'warehouse', 3, 'activity_save_warehouse', '2025-11-07 19:43:42', 'fa-circle-o', NULL, 'CIVIL CV1', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (100, 5, 'leads', 1, 'activity_save_leads', '2025-11-07 19:46:53', 'fa-rocket', 'admin/leads/leads_details/1', 'Welder', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (101, 5, 'job_circular', 1, 'activity_added_job_posted', '2025-11-07 19:49:31', 'fa-ticket', NULL, 'Mason Worker[MASON]', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (102, 5, 'payroll', 1, 'activity_salary_details_update', '2025-11-07 19:52:39', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (103, 5, 'payroll', 1, 'activity_salary_details_update', '2025-11-07 19:52:47', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (104, 5, 'user', 9, 'activity_added_new_user', '2025-11-10 11:12:17', 'fa-user', NULL, 'joel', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (105, 5, 'user', 10, 'activity_added_new_user', '2025-11-10 11:15:24', 'fa-user', NULL, 'ERIC', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (106, 5, 'user', 11, 'activity_added_new_user', '2025-11-10 11:17:14', 'fa-user', NULL, 'AYASH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (107, 5, 'user', 8, 'activity_added_new_user', '2025-11-10 11:18:19', 'fa-user', NULL, 'YAHYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (108, 5, 'user', 11, 'activity_added_new_user', '2025-11-10 11:18:46', 'fa-user', NULL, 'AYASH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (109, 5, 'user', 12, 'activity_added_new_user', '2025-11-10 11:21:20', 'fa-user', NULL, 'AYASH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (110, 5, 'user', 13, 'activity_added_new_user', '2025-11-10 11:23:08', 'fa-user', NULL, 'ABDURAHMAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (111, 5, 'user', 14, 'activity_added_new_user', '2025-11-10 11:24:30', 'fa-user', NULL, 'JEMAL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (112, 5, 'user', 15, 'activity_added_new_user', '2025-11-10 11:27:08', 'fa-user', NULL, 'UMER', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (113, 5, 'user', 16, 'activity_added_new_user', '2025-11-10 11:55:24', 'fa-user', NULL, 'DIRIBA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (114, 5, 'user', 17, 'activity_added_new_user', '2025-11-10 13:06:14', 'fa-user', NULL, 'ADISU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (115, 5, 'user', 18, 'activity_added_new_user', '2025-11-10 13:40:57', 'fa-user', NULL, 'EFREM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (116, 5, 'user', 19, 'activity_added_new_user', '2025-11-10 13:43:42', 'fa-user', NULL, 'AJAIB', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (117, 5, 'user', 20, 'activity_added_new_user', '2025-11-10 13:49:16', 'fa-user', NULL, 'ABDULJEBAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (118, 5, 'user', 21, 'activity_added_new_user', '2025-11-10 13:52:29', 'fa-user', NULL, 'MURTEDA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (119, 5, 'user', 22, 'activity_added_new_user', '2025-11-10 13:54:19', 'fa-user', NULL, 'GUTAMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (120, 5, 'user', 23, 'activity_added_new_user', '2025-11-10 13:56:06', 'fa-user', NULL, 'HAJI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (121, 5, 'user', 24, 'activity_added_new_user', '2025-11-10 14:00:32', 'fa-user', NULL, 'JAINULABUDEEN ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (122, 5, 'settings', 5, 'activity_database_backup', '2025-11-18 20:04:34', 'fa-coffee', NULL, 'BD-backup_2025-11-18_20-04', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (123, 5, 'user', 20, 'activity_added_new_user', '2025-11-19 10:51:53', 'fa-user', NULL, 'ABDULJEBAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (124, 5, 'user', 25, 'activity_added_new_user', '2025-11-19 13:40:30', 'fa-user', NULL, 'muktar', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (125, 5, 'user', 26, 'activity_added_new_user', '2025-11-19 13:42:29', 'fa-user', NULL, 'gutama', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (126, 5, 'user', 8, 'activity_added_new_user', '2026-01-21 12:57:09', 'fa-user', NULL, 'YAHYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (127, 5, 'user', 14, 'activity_added_new_user', '2026-01-21 12:58:13', 'fa-user', NULL, 'JEMAL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (128, 5, 'settings', 5, 'activity_update_profile', '2026-01-21 12:58:17', 'fa-coffee', NULL, 'HAYAT MANPOWER.AE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (129, 5, 'settings', 5, 'activity_update_profile', '2026-01-21 12:59:20', 'fa-coffee', NULL, 'HAYAT MANPOWER.AE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (130, 5, 'payroll', 1, 'activity_salary_details_update', '2026-01-21 14:01:36', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (131, 5, 'payroll', 2, 'activity_salary_template_update', '2026-01-21 14:02:21', 'fa-money', 'admin/payroll/view_salary_template/2', '1200', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (132, 5, 'payroll', 1, 'activity_salary_details_update', '2026-01-21 14:02:58', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (133, 5, 'user', 8, 'activity_added_new_user', '2026-01-21 14:10:51', 'fa-user', NULL, 'YAHYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (134, 5, 'user', 8, 'activity_added_new_user', '2026-01-21 14:12:28', 'fa-user', NULL, 'YAHYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (135, 5, 'client', 3, 'activity_update_company', '2026-01-21 15:54:42', 'fa-user', NULL, 'BCC', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (136, 5, 'client', NULL, 'activity_added_new_contact', '2026-01-21 15:58:18', 'fa-user', NULL, 'prem', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (137, 5, 'client', 4, 'activity_update_company', '2026-01-21 16:00:58', 'fa-user', NULL, 'fsh', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (138, 5, 'client', NULL, 'activity_added_new_contact', '2026-01-21 16:01:44', 'fa-user', NULL, 'john', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (139, 5, 'user', 17, 'activity_documents_update', '2026-01-21 16:10:00', 'fa-user', NULL, 'ADISU TESHOME BOGE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (140, 5, 'user', 18, 'activity_documents_update', '2026-01-21 16:33:05', 'fa-user', NULL, 'EFREM ZEMACHU MENGISTU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (141, 5, 'user', 19, 'activity_documents_update', '2026-01-21 16:39:59', 'fa-user', NULL, 'AJAIB HAMDA GENEMO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (142, 5, 'user', 20, 'activity_documents_update', '2026-01-21 16:43:07', 'fa-user', NULL, 'ABDULJEBAR AMANO DELCHA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (143, 5, 'user', 23, 'activity_documents_update', '2026-01-21 16:47:35', 'fa-user', NULL, 'HAJI HUSEN KUSU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (144, 5, 'user', 24, 'activity_documents_update', '2026-01-21 16:50:22', 'fa-user', NULL, 'JAINULABUDEEN AHIYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (145, 5, 'user', 25, 'activity_documents_update', '2026-01-21 16:55:15', 'fa-user', NULL, 'MURTEDA MUKTAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (146, 5, 'user', 26, 'activity_documents_update', '2026-01-21 17:02:25', 'fa-user', NULL, 'GUTAMA LENCHO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (147, 5, 'user', 6, 'activity_documents_update', '2026-01-21 17:07:00', 'fa-user', NULL, 'KARTHIK VENKATAPATHY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (148, 5, 'user', 8, 'activity_documents_update', '2026-01-21 17:09:50', 'fa-user', NULL, 'YAHYA MUZEMIL HUSENN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (149, 5, 'user', 9, 'activity_documents_update', '2026-01-21 17:21:12', 'fa-user', NULL, 'JOEL KISILA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (150, 5, 'user', 10, 'activity_documents_update', '2026-01-21 17:22:38', 'fa-user', NULL, 'ERIC AIDOO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (151, 5, 'user', 12, 'activity_documents_update', '2026-01-21 17:29:15', 'fa-user', NULL, 'AYASH JEMAL ADEM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (152, 5, 'user', 13, 'activity_documents_update', '2026-01-21 17:34:42', 'fa-user', NULL, 'ABDURAHMAN SHUKARI JILO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (153, 5, 'user', 14, 'activity_documents_update', '2026-01-21 17:36:20', 'fa-user', NULL, 'JEMAL HASSEN TURKE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (154, 5, 'user', 29, 'activity_added_new_user', '2026-01-23 13:32:02', 'fa-user', NULL, 'ANANIOUS', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (155, 5, 'user', 30, 'activity_added_new_user', '2026-01-23 13:33:41', 'fa-user', NULL, 'JOSEPH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (156, 5, 'user', 31, 'activity_added_new_user', '2026-01-23 13:35:17', 'fa-user', NULL, 'SOLOMON', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (157, 5, 'departments', NULL, 'activity_added_a_department', '2026-01-23 13:36:21', 'fa-coffee', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (158, 5, 'departments', NULL, 'activity_added_a_department', '2026-01-23 13:36:34', 'fa-coffee', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (159, 5, 'departments', NULL, 'activity_added_a_department', '2026-01-23 13:36:46', 'fa-coffee', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (160, 5, 'user', 32, 'activity_added_new_user', '2026-01-23 13:38:30', 'fa-user', NULL, 'AWOL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (161, 5, 'user', 33, 'activity_added_new_user', '2026-01-23 13:42:57', 'fa-user', NULL, 'CHINNAIYAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (162, 5, 'user', 34, 'activity_added_new_user', '2026-01-23 13:44:07', 'fa-user', NULL, 'ISAAC', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (163, 5, 'user', 35, 'activity_added_new_user', '2026-01-23 13:45:01', 'fa-user', NULL, 'PERIYASAMY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (164, 5, 'user', 36, 'activity_added_new_user', '2026-01-23 13:46:02', 'fa-user', NULL, 'RICHMOND', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (165, 5, 'user', 37, 'activity_added_new_user', '2026-01-23 13:46:55', 'fa-user', NULL, 'GIDEON', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (166, 5, 'user', 38, 'activity_added_new_user', '2026-01-23 13:47:46', 'fa-user', NULL, 'PRINCE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (167, 5, 'user', 39, 'activity_added_new_user', '2026-01-23 13:49:12', 'fa-user', NULL, 'KARTHIKEYAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (168, 5, 'user', 40, 'activity_added_new_user', '2026-01-23 13:50:14', 'fa-user', NULL, 'PANJAVARNAM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (169, 5, 'user', 41, 'activity_added_new_user', '2026-01-23 13:51:47', 'fa-user', NULL, 'FRANK', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (170, 5, 'user', 42, 'activity_added_new_user', '2026-01-23 13:52:49', 'fa-user', NULL, 'EMMANUEL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (171, 5, 'user', 43, 'activity_added_new_user', '2026-01-23 13:53:45', 'fa-user', NULL, 'ISSAC OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (172, 5, 'user', 44, 'activity_added_new_user', '2026-01-23 13:54:44', 'fa-user', NULL, 'EMMANUEL EFFUM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (173, 5, 'user', 45, 'activity_added_new_user', '2026-01-23 13:56:00', 'fa-user', NULL, 'ISSAHAHMED', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (174, 5, 'user', 46, 'activity_added_new_user', '2026-01-23 13:57:12', 'fa-user', NULL, 'COLLINS BOYE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (175, 5, 'user', 47, 'activity_added_new_user', '2026-01-23 13:58:04', 'fa-user', NULL, 'ELIJAH YENNUBE LAARI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (176, 5, 'user', 48, 'activity_added_new_user', '2026-01-23 14:14:28', 'fa-user', NULL, 'EMILE NSHEMEZIMANA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (177, 5, 'user', 49, 'activity_added_new_user', '2026-01-23 14:15:51', 'fa-user', NULL, 'THERENCE NITANGA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (178, 5, 'user', 50, 'activity_added_new_user', '2026-01-23 16:29:21', 'fa-user', NULL, 'PRIMACY MURINDWA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (179, 5, 'user', 51, 'activity_added_new_user', '2026-01-23 16:31:11', 'fa-user', NULL, 'BISMARK MINTAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (180, 5, 'user', 52, 'activity_added_new_user', '2026-01-23 16:32:08', 'fa-user', NULL, 'ANDREW LUVUUMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (181, 5, 'user', 53, 'activity_added_new_user', '2026-01-23 16:34:11', 'fa-user', NULL, 'JEAN MARIE SINIREMERA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (182, 5, 'user', 54, 'activity_added_new_user', '2026-01-23 16:52:32', 'fa-user', NULL, 'EMMANUEL OFORI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (183, 5, 'user', 55, 'activity_added_new_user', '2026-01-24 13:16:56', 'fa-user', NULL, 'BALPOLO KWABENA BIIFA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (184, 5, 'user', 56, 'activity_added_new_user', '2026-01-24 13:17:48', 'fa-user', NULL, 'LATIF INUSAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (185, 5, 'user', 57, 'activity_added_new_user', '2026-01-24 13:20:25', 'fa-user', NULL, 'SADIQUE ALI KAVUNGATHODI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (186, 5, 'user', 58, 'activity_added_new_user', '2026-01-24 13:21:21', 'fa-user', NULL, 'RANJITHKUMAR PALANIVEL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (187, 5, 'user', 59, 'activity_added_new_user', '2026-01-24 13:22:20', 'fa-user', NULL, 'EBENEZER SENIOR KWAKYE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (188, 5, 'user', 60, 'activity_added_new_user', '2026-01-24 13:23:57', 'fa-user', NULL, 'KELVIN LORD BUABENG ASANTE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (189, 5, 'user', 61, 'activity_added_new_user', '2026-01-24 13:24:56', 'fa-user', NULL, 'AMOS KWABENA ATTA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (190, 5, 'user', 62, 'activity_added_new_user', '2026-01-24 13:25:50', 'fa-user', NULL, 'EMMANUEL KOFI AGYAPONG', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (191, 5, 'settings', 5, 'activity_save_theme_settings', '2026-01-24 20:53:33', 'fa-coffee', NULL, 'hayatjadidagroups', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (192, 5, 'settings', 5, 'activity_database_backup', '2026-02-17 09:24:21', 'fa-coffee', NULL, 'BD-backup_2026-02-17_09-24', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (193, 5, 'settings', 5, 'activity_database_backup', '2026-02-17 09:24:21', 'fa-coffee', NULL, 'BD-backup_2026-02-17_09-24', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (194, 5, 'payroll', 3, 'activity_salary_details_update', '2026-02-23 10:36:31', 'fa-money', NULL, 'LABOUR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (195, 5, 'payroll', 1, 'activity_apply_advance_salary', '2026-02-23 10:41:16', 'cc-mastercard', 'admin/payroll/view_advance_salary/1', 'YAHYA MUZEMIL HUSENN', '20', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (196, 5, 'leave_management', 1, 'activity_leave_save', '2026-02-23 10:44:00', 'fa-ticket', NULL, 'YAHYA MUZEMIL HUSENN -> HOLIDAY', '02.25.2026', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (197, 5, 'leave_management', 1, 'activity_leave_change', '2026-02-23 10:46:10', 'fa-ticket', NULL, 'Accepted', '02.25.2026 TO 01.01.1970', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (198, 5, 'user', 33, 'activity_added_new_user', '2026-02-23 12:17:12', 'fa-user', NULL, 'CHINNAIYAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (199, 5, 'user', 33, 'activity_added_new_user', '2026-02-23 12:17:57', 'fa-user', NULL, 'CHINNAIYAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (200, 5, 'user', 36, 'activity_added_new_user', '2026-02-23 12:24:24', 'fa-user', NULL, 'RICHMOND', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (201, 5, 'user', 63, 'activity_added_new_user', '2026-02-23 12:40:17', 'fa-user', NULL, 'DANIEL ANNOR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (202, 5, 'user', 64, 'activity_added_new_user', '2026-02-23 12:43:06', 'fa-user', NULL, 'DAVID SAKYI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (203, 5, 'user', 65, 'activity_added_new_user', '2026-02-23 12:45:13', 'fa-user', NULL, 'DEVASUNDAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (204, 5, 'user', 66, 'activity_added_new_user', '2026-02-23 12:47:36', 'fa-user', NULL, 'ALEX OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (205, 5, 'user', 67, 'activity_added_new_user', '2026-02-23 12:48:51', 'fa-user', NULL, 'MICHAEL OPPONG', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (206, 5, 'user', 68, 'activity_added_new_user', '2026-02-23 12:56:10', 'fa-user', NULL, 'BISMARK', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (207, 5, 'user', 69, 'activity_added_new_user', '2026-02-23 12:58:38', 'fa-user', NULL, 'SHOWKAT', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (208, 5, 'user', 70, 'activity_added_new_user', '2026-02-23 13:00:28', 'fa-user', NULL, 'MOROALI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (209, 5, 'user', 71, 'activity_added_new_user', '2026-02-23 15:14:28', 'fa-user', NULL, 'JOUHARA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (210, 5, 'user', 72, 'activity_added_new_user', '2026-02-23 15:15:56', 'fa-user', NULL, 'SAMPSON', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (211, 5, 'user', 73, 'activity_added_new_user', '2026-02-23 15:36:13', 'fa-user', NULL, 'IBRAHIM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (212, 5, 'user', 71, 'activity_added_new_user', '2026-02-24 10:51:44', 'fa-user', NULL, 'JOUHARA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (213, 5, 'user', 74, 'activity_added_new_user', '2026-02-24 11:03:19', 'fa-user', NULL, 'JAMES POURSAH KONFAREH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (214, 5, 'user', 35, 'activity_added_new_user', '2026-02-24 15:23:53', 'fa-user', NULL, 'PERIYASAMY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (215, 5, 'user', 1, 'activity_new_user_bank', '2026-02-25 09:38:01', 'fa-user', NULL, 'KARTHIK VENKATAPATHY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (216, 5, 'user', 6, 'activity_update_user', '2026-02-25 09:41:11', 'fa-user', NULL, 'KARTHIK VENKATAPATHY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (217, 5, 'user', 6, 'activity_update_user', '2026-02-25 09:43:12', 'fa-user', NULL, 'KARTHIK VENKATAPATHY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (218, 5, 'user', 2, 'activity_new_user_bank', '2026-02-25 09:44:32', 'fa-user', NULL, 'YAHYA MUZEMIL HUSENN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (219, 5, 'user', 8, 'activity_update_user', '2026-02-25 09:47:34', 'fa-user', NULL, 'YAHYA MUZEMIL HUSENN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (220, 5, 'user', 3, 'activity_new_user_bank', '2026-02-25 09:49:27', 'fa-user', NULL, 'JOEL KISILA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (221, 5, 'user', 9, 'activity_update_user', '2026-02-25 09:50:38', 'fa-user', NULL, 'JOEL KISILA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (222, 5, 'user', 4, 'activity_new_user_bank', '2026-02-25 09:52:48', 'fa-user', NULL, 'ERIC AIDOO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (223, 5, 'user', 10, 'activity_update_user', '2026-02-25 09:54:01', 'fa-user', NULL, 'ERIC AIDOO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (224, 5, 'user', 5, 'activity_new_user_bank', '2026-02-25 09:56:18', 'fa-user', NULL, 'AYASH JEMAL ADEM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (225, 5, 'user', 12, 'activity_added_new_user', '2026-02-25 09:58:24', 'fa-user', NULL, 'AYASH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (226, 5, 'user', 12, 'activity_update_user', '2026-02-25 10:01:56', 'fa-user', NULL, 'AYASH JEMAL ADEM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (227, 5, 'user', 6, 'activity_new_user_bank', '2026-02-25 10:03:08', 'fa-user', NULL, 'ABDURAHMAN SHUKARI JILO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (228, 5, 'user', 13, 'activity_update_user', '2026-02-25 10:07:37', 'fa-user', NULL, 'ABDURAHMAN SHUKARI JILO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (229, 5, 'user', 7, 'activity_new_user_bank', '2026-02-25 10:09:19', 'fa-user', NULL, 'JEMAL HASSEN TURKE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (230, 5, 'user', 14, 'activity_update_user', '2026-02-25 10:11:02', 'fa-user', NULL, 'JEMAL HASSEN TURKE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (231, 5, 'user', 15, 'activity_added_new_user', '2026-02-25 10:12:41', 'fa-user', NULL, 'UMER', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (232, 5, 'user', 8, 'activity_new_user_bank', '2026-02-25 10:13:15', 'fa-user', NULL, 'UMER HUSSEN MAMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (233, 5, 'user', 15, 'activity_documents_update', '2026-02-25 10:14:29', 'fa-user', NULL, 'UMER HUSSEN MAMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (234, 5, 'user', 15, 'activity_update_user', '2026-02-25 10:15:35', 'fa-user', NULL, 'UMER HUSSEN MAMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (235, 5, 'user', 9, 'activity_new_user_bank', '2026-02-25 10:17:05', 'fa-user', NULL, 'DIRIBA GOSA BEKELE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (236, 5, 'user', 16, 'activity_documents_update', '2026-02-25 10:18:49', 'fa-user', NULL, 'DIRIBA GOSA BEKELE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (237, 5, 'user', 16, 'activity_update_user', '2026-02-25 10:20:00', 'fa-user', NULL, 'DIRIBA GOSA BEKELE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (238, 5, 'user', 10, 'activity_new_user_bank', '2026-02-25 10:20:47', 'fa-user', NULL, 'ADISU TESHOME BOGE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (239, 5, 'user', 17, 'activity_update_user', '2026-02-25 10:22:25', 'fa-user', NULL, 'ADISU TESHOME BOGE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (240, 5, 'user', 11, 'activity_new_user_bank', '2026-02-25 10:24:33', 'fa-user', NULL, 'EFREM ZEMACHU MENGISTU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (241, 5, 'user', 18, 'activity_update_user', '2026-02-25 10:26:13', 'fa-user', NULL, 'EFREM ZEMACHU MENGISTU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (242, 5, 'user', 12, 'activity_new_user_bank', '2026-02-25 10:27:22', 'fa-user', NULL, 'AJAIB HAMDA GENEMO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (243, 5, 'user', 19, 'activity_update_user', '2026-02-25 10:28:07', 'fa-user', NULL, 'AJAIB HAMDA GENEMO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (244, 5, 'user', 20, 'activity_added_new_user', '2026-02-25 10:29:32', 'fa-user', NULL, 'ABDULJEBAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (245, 5, 'user', 13, 'activity_new_user_bank', '2026-02-25 10:30:05', 'fa-user', NULL, 'ABDULJEBAR AMANO DELCHA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (246, 5, 'user', 20, 'activity_update_user', '2026-02-25 10:31:03', 'fa-user', NULL, 'ABDULJEBAR AMANO DELCHA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (247, 5, 'user', 25, 'activity_added_new_user', '2026-02-25 10:34:03', 'fa-user', NULL, 'muktar', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (248, 5, 'user', 25, 'activity_added_new_user', '2026-02-25 10:34:45', 'fa-user', NULL, 'muktar', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (249, 5, 'user', 14, 'activity_new_user_bank', '2026-02-25 10:35:57', 'fa-user', NULL, 'MURTEDA MUKTAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (250, 5, 'user', 25, 'activity_update_user', '2026-02-25 10:37:08', 'fa-user', NULL, 'MURTEDA MUKTAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (251, 5, 'user', 15, 'activity_new_user_bank', '2026-02-25 10:45:54', 'fa-user', NULL, 'GUTAMA LENCHO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (252, 5, 'user', 26, 'activity_update_user', '2026-02-25 10:47:00', 'fa-user', NULL, 'GUTAMA LENCHO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (253, 5, 'user', 16, 'activity_new_user_bank', '2026-02-25 10:48:25', 'fa-user', NULL, 'HAJI HUSEN KUSU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (254, 5, 'user', 23, 'activity_update_user', '2026-02-25 10:49:29', 'fa-user', NULL, 'HAJI HUSEN KUSU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (255, 5, 'user', 17, 'activity_new_user_bank', '2026-02-25 10:50:21', 'fa-user', NULL, 'JAINULABUDEEN AHIYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (256, 5, 'user', 24, 'activity_update_user', '2026-02-25 10:51:55', 'fa-user', NULL, 'JAINULABUDEEN AHIYA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (257, 5, 'user', 75, 'activity_added_new_user', '2026-02-25 10:54:37', 'fa-user', NULL, 'AFZAL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (258, 5, 'user', 18, 'activity_new_user_bank', '2026-02-25 10:55:16', 'fa-user', NULL, 'AFZAL BABU KHAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (259, 5, 'user', 75, 'activity_documents_update', '2026-02-25 10:56:35', 'fa-user', NULL, 'AFZAL BABU KHAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (260, 5, 'user', 75, 'activity_update_user', '2026-02-25 10:58:18', 'fa-user', NULL, 'AFZAL BABU KHAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (261, 5, 'user', 19, 'activity_new_user_bank', '2026-02-25 11:02:13', 'fa-user', NULL, 'ANANIOUS RONNY BYMAZIMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (262, 5, 'user', 29, 'activity_update_user', '2026-02-25 11:03:53', 'fa-user', NULL, 'ANANIOUS RONNY BYMAZIMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (263, 5, 'user', 29, 'activity_documents_update', '2026-02-25 11:05:13', 'fa-user', NULL, 'ANANIOUS RONNY BYMAZIMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (264, 5, 'user', 20, 'activity_new_user_bank', '2026-02-25 12:09:20', 'fa-user', NULL, 'JOSEPH GAKURU GITONGA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (265, 5, 'user', 30, 'activity_documents_update', '2026-02-25 12:11:04', 'fa-user', NULL, 'JOSEPH GAKURU GITONGA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (266, 5, 'user', 30, 'activity_update_user', '2026-02-25 12:13:34', 'fa-user', NULL, 'JOSEPH GAKURU GITONGA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (267, 5, 'user', 30, 'activity_added_new_user', '2026-02-25 12:14:03', 'fa-user', NULL, 'JOSEPH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (268, 5, 'user', 30, 'activity_added_new_user', '2026-02-25 12:14:47', 'fa-user', NULL, 'JOSEPH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (269, 5, 'user', 30, 'activity_added_new_user', '2026-02-25 12:15:25', 'fa-user', NULL, 'JOSEPH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (270, 5, 'user', 21, 'activity_new_user_bank', '2026-02-25 12:17:07', 'fa-user', NULL, 'SOLOMON GANDAA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (271, 5, 'user', 31, 'activity_documents_update', '2026-02-25 12:18:33', 'fa-user', NULL, 'SOLOMON GANDAA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (272, 5, 'user', 31, 'activity_update_user', '2026-02-25 12:20:58', 'fa-user', NULL, 'SOLOMON GANDAA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (273, 5, 'user', 31, 'activity_added_new_user', '2026-02-25 12:21:32', 'fa-user', NULL, 'SOLOMON', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (274, 5, 'user', 22, 'activity_new_user_bank', '2026-02-25 12:22:26', 'fa-user', NULL, 'AWOL SIRAJ AHMED', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (275, 5, 'user', 32, 'activity_documents_update', '2026-02-25 12:23:51', 'fa-user', NULL, 'AWOL SIRAJ AHMED', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (276, 5, 'user', 32, 'activity_added_new_user', '2026-02-25 12:24:30', 'fa-user', NULL, 'AWOL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (277, 5, 'user', 32, 'activity_added_new_user', '2026-02-25 12:25:21', 'fa-user', NULL, 'AWOL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (278, 5, 'user', 33, 'activity_added_new_user', '2026-02-25 12:26:19', 'fa-user', NULL, 'CHINNAIYAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (279, 5, 'user', 23, 'activity_new_user_bank', '2026-02-25 12:26:59', 'fa-user', NULL, 'CHINNAIYAN MANIKKAM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (280, 5, 'user', 33, 'activity_documents_update', '2026-02-25 12:29:12', 'fa-user', NULL, 'CHINNAIYAN MANIKKAM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (281, 5, 'user', 33, 'activity_update_user', '2026-02-25 12:30:33', 'fa-user', NULL, 'CHINNAIYAN MANIKKAM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (282, 5, 'user', 34, 'activity_added_new_user', '2026-02-25 12:31:30', 'fa-user', NULL, 'ISAAC', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (283, 5, 'user', 34, 'activity_documents_update', '2026-02-25 12:33:05', 'fa-user', NULL, 'ISAAC HAYFORD', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (284, 5, 'user', 24, 'activity_new_user_bank', '2026-02-25 12:34:30', 'fa-user', NULL, 'ISAAC HAYFORD', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (285, 5, 'user', 34, 'activity_update_user', '2026-02-25 12:35:30', 'fa-user', NULL, 'ISAAC HAYFORD', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (286, 5, 'user', 36, 'activity_added_new_user', '2026-02-25 12:37:07', 'fa-user', NULL, 'RICHMOND', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (287, 5, 'user', 36, 'activity_update_user', '2026-02-25 12:40:49', 'fa-user', NULL, 'RICHMOND OFORI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (288, 5, 'user', 25, 'activity_new_user_bank', '2026-02-25 12:41:22', 'fa-user', NULL, 'RICHMOND OFORI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (289, 5, 'user', 36, 'activity_documents_update', '2026-02-25 12:42:35', 'fa-user', NULL, 'RICHMOND OFORI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (290, 5, 'user', 38, 'activity_added_new_user', '2026-02-25 12:54:50', 'fa-user', NULL, 'PRINCE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (291, 5, 'user', 26, 'activity_new_user_bank', '2026-02-25 12:56:06', 'fa-user', NULL, 'PRINCE OSEI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (292, 5, 'user', 38, 'activity_documents_update', '2026-02-25 12:57:19', 'fa-user', NULL, 'PRINCE OSEI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (293, 5, 'user', 38, 'activity_update_user', '2026-02-25 12:58:47', 'fa-user', NULL, 'PRINCE OSEI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (294, 5, 'user', 39, 'activity_update_user', '2026-02-25 13:01:31', 'fa-user', NULL, 'KARTHIKEYAN SELVARAJ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (295, 5, 'user', 27, 'activity_new_user_bank', '2026-02-25 13:01:57', 'fa-user', NULL, 'KARTHIKEYAN SELVARAJ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (296, 5, 'user', 39, 'activity_documents_update', '2026-02-25 13:03:32', 'fa-user', NULL, 'KARTHIKEYAN SELVARAJ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (297, 5, 'user', 40, 'activity_added_new_user', '2026-02-25 13:26:08', 'fa-user', NULL, 'PANJAVARNAM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (298, 5, 'user', 40, 'activity_update_user', '2026-02-25 13:27:28', 'fa-user', NULL, 'PANJAVARNAM THIRUMURUGAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (299, 5, 'user', 28, 'activity_new_user_bank', '2026-02-25 13:28:10', 'fa-user', NULL, 'PANJAVARNAM THIRUMURUGAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (300, 5, 'user', 40, 'activity_documents_update', '2026-02-25 13:29:37', 'fa-user', NULL, 'PANJAVARNAM THIRUMURUGAN', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (301, 5, 'user', 43, 'activity_added_new_user', '2026-02-25 13:31:42', 'fa-user', NULL, 'ISSAC OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (302, 5, 'user', 29, 'activity_new_user_bank', '2026-02-25 13:32:18', 'fa-user', NULL, 'ISSAC OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (303, 5, 'user', 43, 'activity_documents_update', '2026-02-25 13:33:53', 'fa-user', NULL, 'ISSAC OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (304, 5, 'user', 43, 'activity_update_user', '2026-02-25 13:35:11', 'fa-user', NULL, 'ISSAC OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (305, 5, 'user', 41, 'activity_added_new_user', '2026-02-25 13:36:23', 'fa-user', NULL, 'FRANK', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (306, 5, 'user', 30, 'activity_new_user_bank', '2026-02-25 13:37:12', 'fa-user', NULL, 'FRANK OSEI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (307, 5, 'user', 41, 'activity_documents_update', '2026-02-25 13:38:24', 'fa-user', NULL, 'FRANK OSEI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (308, 5, 'user', 41, 'activity_documents_update', '2026-02-25 13:39:01', 'fa-user', NULL, 'FRANK OSEI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (309, 5, 'user', 42, 'activity_added_new_user', '2026-02-25 13:40:02', 'fa-user', NULL, 'EMMANUEL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (310, 5, 'user', 42, 'activity_documents_update', '2026-02-25 13:41:07', 'fa-user', NULL, 'EMMANUEL ACKAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (311, 5, 'user', 31, 'activity_new_user_bank', '2026-02-25 13:41:34', 'fa-user', NULL, 'EMMANUEL ACKAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (312, 5, 'user', 32, 'activity_new_user_bank', '2026-02-25 13:43:07', 'fa-user', NULL, 'ELIJAH YENNUBE LAARI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (313, 5, 'user', 47, 'activity_documents_update', '2026-02-25 13:44:38', 'fa-user', NULL, 'ELIJAH YENNUBE LAARI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (314, 5, 'user', 47, 'activity_update_user', '2026-02-25 13:46:00', 'fa-user', NULL, 'ELIJAH YENNUBE LAARI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (315, 5, 'user', 33, 'activity_new_user_bank', '2026-02-25 13:47:47', 'fa-user', NULL, 'COLLINS BOYE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (316, 5, 'user', 46, 'activity_documents_update', '2026-02-25 13:49:48', 'fa-user', NULL, 'COLLINS BOYE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (317, 5, 'user', 34, 'activity_new_user_bank', '2026-02-25 14:20:45', 'fa-user', NULL, 'ALEX OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (318, 5, 'user', 66, 'activity_documents_update', '2026-02-25 14:22:24', 'fa-user', NULL, 'ALEX OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (319, 5, 'user', 35, 'activity_new_user_bank', '2026-02-25 14:23:23', 'fa-user', NULL, 'MICHAEL OPPONG', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (320, 5, 'user', 36, 'activity_new_user_bank', '2026-02-25 14:24:08', 'fa-user', NULL, 'BISMARK SARPONG OWUSU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (321, 5, 'user', 37, 'activity_new_user_bank', '2026-02-25 14:24:54', 'fa-user', NULL, 'SHOWKAT AHMAD PADAR ABDUL RASHID PADAR', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (322, 5, 'user', 38, 'activity_new_user_bank', '2026-02-25 14:25:40', 'fa-user', NULL, 'MORO ALI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (323, 5, 'payroll', 25, 'activity_salary_details_update', '2026-02-25 15:21:29', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (324, 5, 'user', 66, 'activity_added_new_user', '2026-02-25 15:29:22', 'fa-user', NULL, 'ALEX OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (325, 5, 'user', 66, 'activity_added_new_user', '2026-02-25 15:31:02', 'fa-user', NULL, 'ALEX OPOKU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (326, 5, 'user', 39, 'activity_new_user_bank', '2026-02-25 15:57:39', 'fa-user', NULL, 'JOUHARA JAFAR JAFAR KOYILLATH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (327, 5, 'user', 40, 'activity_new_user_bank', '2026-02-25 15:58:30', 'fa-user', NULL, 'SAMPSON ASIEDU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (328, 5, 'user', 41, 'activity_new_user_bank', '2026-02-25 15:59:53', 'fa-user', NULL, 'IBRAHIM ABDUL AZIZ', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (329, 5, 'user', 42, 'activity_new_user_bank', '2026-02-25 16:00:36', 'fa-user', NULL, 'JAMES POURSAH KONFAREH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (330, 5, 'user', 43, 'activity_new_user_bank', '2026-02-25 16:01:21', 'fa-user', NULL, 'EMMANUEL KOFI AGYAPONG', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (331, 5, 'user', 44, 'activity_new_user_bank', '2026-02-25 16:02:05', 'fa-user', NULL, 'AMOS KWABENA ATTA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (332, 5, 'user', 45, 'activity_new_user_bank', '2026-02-25 16:02:47', 'fa-user', NULL, 'KELVIN LORD BUABENG ASANTE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (333, 5, 'user', 46, 'activity_new_user_bank', '2026-02-25 16:03:35', 'fa-user', NULL, 'EBENEZER SENIOR KWAKYE', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (334, 5, 'user', 47, 'activity_new_user_bank', '2026-02-25 16:04:54', 'fa-user', NULL, 'PERIYASAMY CHINNASAMY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (335, 5, 'user', 48, 'activity_new_user_bank', '2026-02-25 16:05:33', 'fa-user', NULL, 'GIDEON BADU', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (336, 5, 'user', 49, 'activity_new_user_bank', '2026-02-25 16:06:17', 'fa-user', NULL, 'EMMANUEL EFFUM', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (337, 5, 'user', 50, 'activity_new_user_bank', '2026-02-25 16:06:57', 'fa-user', NULL, 'ISSAH AHMED', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (338, 5, 'user', 51, 'activity_new_user_bank', '2026-02-25 16:07:42', 'fa-user', NULL, 'EMILE NSHEMEZIMANA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (339, 5, 'user', 52, 'activity_new_user_bank', '2026-02-25 16:08:36', 'fa-user', NULL, 'THERENCE NITANGA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (340, 5, 'user', 53, 'activity_new_user_bank', '2026-02-25 16:09:16', 'fa-user', NULL, 'PRIMACY MURINDWA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (341, 5, 'user', 54, 'activity_new_user_bank', '2026-02-25 16:09:55', 'fa-user', NULL, 'BISMARK MINTAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (342, 5, 'user', 55, 'activity_new_user_bank', '2026-02-25 16:10:48', 'fa-user', NULL, 'ANDREW LUVUUMA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (343, 5, 'user', 56, 'activity_new_user_bank', '2026-02-25 16:11:28', 'fa-user', NULL, 'JEAN MARIE SINIREMERA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (344, 5, 'user', 57, 'activity_new_user_bank', '2026-02-25 16:12:09', 'fa-user', NULL, 'EMMANUEL OFORI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (345, 5, 'user', 58, 'activity_new_user_bank', '2026-02-25 16:13:42', 'fa-user', NULL, 'BALPOLO KWABENA BIIFA', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (346, 5, 'user', 59, 'activity_new_user_bank', '2026-02-25 16:15:23', 'fa-user', NULL, 'LATIF INUSAH', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (347, 5, 'user', 60, 'activity_new_user_bank', '2026-02-25 16:16:19', 'fa-user', NULL, 'SADIQUE ALI KAVUNGATHODI', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (348, 5, 'user', 61, 'activity_new_user_bank', '2026-02-25 16:17:11', 'fa-user', NULL, 'RANJITHKUMAR PALANIVEL', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (349, 5, 'payroll', 3, 'activity_salary_template_update', '2026-02-26 10:38:18', 'fa-money', 'admin/payroll/view_salary_template/3', '1500', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (350, 5, 'payroll', 3, 'activity_salary_template_update', '2026-02-26 10:44:33', 'fa-money', 'admin/payroll/view_salary_template/3', 'Admin - Manager', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (351, 5, 'payroll', 25, 'activity_salary_details_update', '2026-02-26 12:12:32', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (352, 5, 'payroll', 25, 'activity_salary_details_update', '2026-02-26 12:12:59', 'fa-money', NULL, 'Employee', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (353, 5, 'payroll', 63, 'activity_salary_details_update', '2026-02-26 12:15:43', 'fa-money', NULL, 'Admin', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (354, 5, 'payroll', 2, 'activity_apply_advance_salary', '2026-02-26 12:16:31', 'cc-mastercard', 'admin/payroll/view_advance_salary/2', 'KARTHIK VENKATAPATHY', '500', 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (355, 5, 'user', 1, 'activity_update_user_bank', '2026-02-26 12:18:47', 'fa-user', NULL, 'KARTHIK VENKATAPATHY', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (356, 5, 'settings', 6, 'activity_delete_a_method', '2026-02-26 12:29:25', 'fa-coffee', NULL, 'NO', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (357, 5, 'settings', 7, 'activity_delete_a_method', '2026-02-26 12:29:29', 'fa-coffee', NULL, 'NOa', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (358, 5, 'settings', 8, 'activity_delete_a_method', '2026-02-26 12:29:33', 'fa-coffee', NULL, 'a', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (359, 5, 'settings', 10, 'activity_delete_a_method', '2026-02-26 12:29:36', 'fa-coffee', NULL, 'OKSSSS', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (360, 5, 'settings', 11, 'activity_delete_a_method', '2026-02-26 12:29:45', 'fa-coffee', NULL, 'ass', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (361, 5, 'settings', 12, 'activity_delete_a_method', '2026-02-26 12:29:48', 'fa-coffee', NULL, 'aaaaa', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (362, 5, 'settings', 13, 'activity_delete_a_method', '2026-02-26 12:29:51', 'fa-coffee', NULL, 'asss', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (363, 5, 'settings', 5, 'activity_backup_delete_success', '2026-02-26 12:31:00', 'fa-coffee', NULL, 'BD-backup_2026-02-17_09-24.zip', NULL, 0);
INSERT INTO `tbl_activities` (`activities_id`, `user`, `module`, `module_field_id`, `activity`, `activity_date`, `icon`, `link`, `value1`, `value2`, `deleted`) VALUES (364, 5, 'settings', 5, 'activity_backup_delete_success', '2026-02-26 12:31:06', 'fa-coffee', NULL, 'BD-backup_2025-11-18_20-04.zip', NULL, 0);


#
# TABLE STRUCTURE FOR: tbl_advance_salary
#

DROP TABLE IF EXISTS `tbl_advance_salary`;

CREATE TABLE `tbl_advance_salary` (
  `advance_salary_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `advance_amount` varchar(200) NOT NULL,
  `deduct_month` varchar(30) DEFAULT NULL,
  `reason` text,
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0 =pending,1=accpect , 2 = reject and 3 = paid',
  `approve_by` int DEFAULT NULL,
  PRIMARY KEY (`advance_salary_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_advance_salary` (`advance_salary_id`, `user_id`, `advance_amount`, `deduct_month`, `reason`, `request_date`, `status`, `approve_by`) VALUES (1, 8, '20', '2026-03', 'Urgent hospital', '2026-02-23 10:41:16', 1, NULL);
INSERT INTO `tbl_advance_salary` (`advance_salary_id`, `user_id`, `advance_amount`, `deduct_month`, `reason`, `request_date`, `status`, `approve_by`) VALUES (2, 6, '500', '2026-03', 'medical', '2026-02-26 12:16:31', 1, NULL);


#
# TABLE STRUCTURE FOR: tbl_allowed_ip
#

DROP TABLE IF EXISTS `tbl_allowed_ip`;

CREATE TABLE `tbl_allowed_ip` (
  `allowed_ip_id` int NOT NULL AUTO_INCREMENT,
  `allowed_ip` varchar(100) NOT NULL,
  `status` enum('active','reject','pending') DEFAULT 'pending',
  PRIMARY KEY (`allowed_ip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_announcements
#

DROP TABLE IF EXISTS `tbl_announcements`;

CREATE TABLE `tbl_announcements` (
  `announcements_id` int NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `user_id` int NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('published','unpublished') NOT NULL DEFAULT 'unpublished' COMMENT '0 = unpublished, 1 = published',
  `view_status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=Read 2=Unread',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `all_client` varchar(20) DEFAULT NULL,
  `attachment` text,
  PRIMARY KEY (`announcements_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_assign_item
#

DROP TABLE IF EXISTS `tbl_assign_item`;

CREATE TABLE `tbl_assign_item` (
  `assign_item_id` int NOT NULL AUTO_INCREMENT,
  `stock_id` int NOT NULL,
  `user_id` int NOT NULL,
  `assign_inventory` int NOT NULL,
  `assign_date` date NOT NULL,
  PRIMARY KEY (`assign_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_attachments
#

DROP TABLE IF EXISTS `tbl_attachments`;

CREATE TABLE `tbl_attachments` (
  `attachments_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `upload_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `module` varchar(50) DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  PRIMARY KEY (`attachments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_attachments_files
#

DROP TABLE IF EXISTS `tbl_attachments_files`;

CREATE TABLE `tbl_attachments_files` (
  `uploaded_files_id` int NOT NULL AUTO_INCREMENT,
  `attachments_id` int NOT NULL,
  `files` text NOT NULL,
  `uploaded_path` text NOT NULL,
  `file_name` text NOT NULL,
  `size` int NOT NULL,
  `ext` varchar(100) NOT NULL,
  `is_image` int NOT NULL,
  `image_width` int NOT NULL,
  `image_height` int NOT NULL,
  PRIMARY KEY (`uploaded_files_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_attendance
#

DROP TABLE IF EXISTS `tbl_attendance`;

CREATE TABLE `tbl_attendance` (
  `attendance_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `leave_application_id` int DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `attendance_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'status 0=absent 1=present 3 = onleave',
  `clocking_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (1, 6, 0, '2025-11-02', '2025-11-06', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (2, 8, 0, '2025-11-02', '2025-11-02', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (3, 7, 0, '2025-11-02', '2025-11-02', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (4, 6, 0, '2025-11-03', '2025-11-06', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (5, 5, 0, '2025-11-03', '2025-11-03', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (6, 9, 0, '2025-11-06', '2025-11-07', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (7, 9, 0, '2025-11-07', '2025-11-07', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (8, 5, 0, '2025-11-07', '2025-11-07', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (9, 5, 0, '2026-01-23', '2026-01-23', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (10, 5, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (11, 6, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (12, 8, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (13, 9, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (14, 10, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (15, 12, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (16, 13, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (17, 14, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (18, 15, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (19, 16, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (20, 17, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (21, 18, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (22, 19, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (23, 20, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (24, 23, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (25, 24, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (26, 25, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (27, 26, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (28, 29, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (29, 30, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (30, 31, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (31, 32, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (32, 33, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (33, 34, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (34, 35, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (35, 36, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (36, 37, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (37, 38, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (38, 39, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (39, 40, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (40, 41, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (41, 42, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (42, 43, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (43, 44, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (44, 45, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (45, 46, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (46, 47, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (47, 48, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (48, 49, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (49, 50, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (50, 51, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (51, 52, 0, '2026-01-24', '2026-01-24', 1, 1);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (52, 53, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (53, 54, 0, '2026-01-24', '2026-01-24', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (54, 5, 0, '2026-02-23', '2026-02-23', 1, 0);
INSERT INTO `tbl_attendance` (`attendance_id`, `user_id`, `leave_application_id`, `date_in`, `date_out`, `attendance_status`, `clocking_status`) VALUES (55, 8, 1, '2026-02-25', '2026-02-25', 3, 0);


#
# TABLE STRUCTURE FOR: tbl_award_points
#

DROP TABLE IF EXISTS `tbl_award_points`;

CREATE TABLE `tbl_award_points` (
  `award_points_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL,
  `user_id` int NOT NULL,
  `client_award_point` varchar(100) DEFAULT NULL,
  `user_award_point` varchar(100) DEFAULT NULL,
  `invoices_id` int NOT NULL,
  `payment_status` varchar(100) NOT NULL,
  `date` varchar(40) NOT NULL,
  PRIMARY KEY (`award_points_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_award_program
#

DROP TABLE IF EXISTS `tbl_award_program`;

CREATE TABLE `tbl_award_program` (
  `award_program_id` int NOT NULL AUTO_INCREMENT,
  `program_name` varchar(100) NOT NULL,
  `award_rule_id` int NOT NULL,
  `client_id` int NOT NULL,
  `start_date` varchar(64) NOT NULL,
  `end_date` varchar(64) NOT NULL,
  `description` varchar(200) NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`award_program_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_award_rule
#

DROP TABLE IF EXISTS `tbl_award_rule`;

CREATE TABLE `tbl_award_rule` (
  `award_rule_id` int NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(200) NOT NULL,
  `date_create` date NOT NULL,
  `client_id` int NOT NULL,
  `award_point_from` varchar(20) NOT NULL,
  `award_point_to` varchar(20) NOT NULL,
  `card` int NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`award_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_bug
#

DROP TABLE IF EXISTS `tbl_bug`;

CREATE TABLE `tbl_bug` (
  `bug_id` int NOT NULL AUTO_INCREMENT,
  `issue_no` varchar(50) DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `opportunities_id` int DEFAULT NULL,
  `task_id` int NOT NULL DEFAULT '0',
  `bug_title` varchar(200) NOT NULL,
  `bug_description` text NOT NULL,
  `bug_status` varchar(30) DEFAULT NULL,
  `notes` text,
  `priority` varchar(20) NOT NULL,
  `severity` varchar(20) DEFAULT NULL,
  `reproducibility` text,
  `reporter` int DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `permission` text,
  `client_visible` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`bug_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_calls
#

DROP TABLE IF EXISTS `tbl_calls`;

CREATE TABLE `tbl_calls` (
  `calls_id` int NOT NULL AUTO_INCREMENT,
  `leads_id` int DEFAULT NULL,
  `opportunities_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  `date` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `call_summary` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`calls_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_card_config
#

DROP TABLE IF EXISTS `tbl_card_config`;

CREATE TABLE `tbl_card_config` (
  `card_config_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `date_create` date DEFAULT NULL,
  `subject_card` int DEFAULT '0',
  `client_name` int DEFAULT '0',
  `membership` int DEFAULT '0',
  `company_name` int DEFAULT '0',
  `member_since` int DEFAULT '0',
  `custom_field` int DEFAULT '0',
  `custom_field_content` varchar(200) DEFAULT NULL,
  `text_color` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`card_config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_checklists
#

DROP TABLE IF EXISTS `tbl_checklists`;

CREATE TABLE `tbl_checklists` (
  `checklist_id` int NOT NULL AUTO_INCREMENT,
  `module` varchar(32) DEFAULT NULL,
  `module_id` int DEFAULT NULL,
  `description` text,
  `finished` int DEFAULT '0',
  `create_datetime` datetime DEFAULT NULL,
  `added_from` int DEFAULT NULL,
  `finished_from` int DEFAULT NULL,
  `list_order` int DEFAULT NULL,
  PRIMARY KEY (`checklist_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_client
#

DROP TABLE IF EXISTS `tbl_client`;

CREATE TABLE `tbl_client` (
  `client_id` int NOT NULL AUTO_INCREMENT,
  `primary_contact` int DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `short_note` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `website` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `phone` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mobile` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `fax` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `zipcode` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `currency` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `skype_id` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `language` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `vat` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hosting_company` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hostname` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `port` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `password` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `username` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `client_status` tinyint(1) NOT NULL COMMENT '1 = person and 2 = company',
  `profile_photo` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `leads_id` int DEFAULT NULL,
  `latitude` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `longitude` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `customer_group_id` int DEFAULT NULL,
  `active` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `sms_notification` tinyint(1) DEFAULT NULL,
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`, `permission`) VALUES (2, 66, 'World Star', 'worldstar@gmail.com', '', '', '', '', '', '', '', '', 'AED', '', '', '', '', 'english', 'United Arab Emirates', '', '', '', '', NULL, '', 0, NULL, '2025-11-07 19:30:22', NULL, '', '', 2, NULL, NULL, 'all');
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`, `permission`) VALUES (3, 27, 'BCC', 'info@bccmanpower.com', '', '', '', '', '', '', '', '', 'AED', '', '', '', '', 'english', 'United Arab Emirates', '', '', '', '', NULL, '', 0, NULL, '2026-01-21 15:54:42', NULL, '', '', 2, NULL, NULL, 'all');
INSERT INTO `tbl_client` (`client_id`, `primary_contact`, `name`, `email`, `short_note`, `website`, `phone`, `mobile`, `fax`, `address`, `city`, `zipcode`, `currency`, `skype_id`, `linkedin`, `facebook`, `twitter`, `language`, `country`, `vat`, `hosting_company`, `hostname`, `port`, `password`, `username`, `client_status`, `profile_photo`, `date_added`, `leads_id`, `latitude`, `longitude`, `customer_group_id`, `active`, `sms_notification`, `permission`) VALUES (4, 28, 'fsh', 'fsh@gmail.com', '', '', '', '', '', '', '', '', 'AED', '', '', '', '', 'english', 'United Arab Emirates', '', '', '', '', NULL, '', 0, NULL, '2026-01-21 16:00:58', NULL, '', '', 2, NULL, NULL, 'all');


#
# TABLE STRUCTURE FOR: tbl_client_menu
#

DROP TABLE IF EXISTS `tbl_client_menu`;

CREATE TABLE `tbl_client_menu` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(20) DEFAULT NULL,
  `link` varchar(200) DEFAULT NULL,
  `icon` varchar(50) NOT NULL,
  `parent` int NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort` int NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (1, 'projects', 'client/projects', 'fa fa-folder-open-o', 0, '2017-04-19 21:48:26', 3, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (2, 'bugs', 'client/bugs', 'fa fa-bug', 0, '2017-04-19 21:48:39', 4, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (3, 'invoices', 'client/invoice/manage_invoice', 'fa fa-shopping-cart', 0, '2017-04-19 21:48:42', 5, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (4, 'estimates', 'client/estimates', 'fa fa-tachometer', 0, '2017-04-19 21:48:45', 6, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (5, 'payments', 'client/invoice/all_payments', 'fa fa-money', 0, '2017-04-19 21:48:48', 7, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (6, 'tickets', 'client/tickets', 'fa fa-ticket', 0, '2017-06-12 11:41:21', 8, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (7, 'quotations', 'client/quotations', 'fa fa-paste', 0, '2017-04-19 21:48:56', 9, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (8, 'users', 'client/user/user_list', 'fa fa-users', 0, '2017-04-19 21:48:59', 10, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (9, 'settings', 'client/settings', 'fa fa-cogs', 0, '2017-04-19 21:49:03', 11, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (12, 'answered', 'client/tickets/answered', 'fa fa-circle-o', 6, '2017-04-19 21:42:34', 1, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (17, 'dashboard', 'client/dashboard', 'icon-speedometer', 0, '2017-04-19 21:47:21', 1, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (18, 'mailbox', 'client/mailbox', 'fa fa-envelope', 0, '2017-04-19 21:47:21', 2, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (19, 'private_chat', 'chat/conversations', 'fa fa-envelope', 0, '2017-12-10 00:33:43', 12, 0);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (20, 'filemanager', 'client/filemanager', 'fa fa-file', 0, '2017-06-03 09:38:23', 2, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (21, 'proposals', 'client/proposals', 'fa fa-leaf', 0, '2017-07-21 08:51:08', 7, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (22, 'knowledgebase', 'knowledgebase', 'fa fa-question-circle', 0, '2017-11-09 06:34:12', 12, 1);
INSERT INTO `tbl_client_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `time`, `sort`, `status`) VALUES (23, 'refund_items', 'client/invoice/refund_itemslist', 'icon-share-alt', 0, '2019-09-23 06:30:29', 6, 0);


#
# TABLE STRUCTURE FOR: tbl_client_role
#

DROP TABLE IF EXISTS `tbl_client_role`;

CREATE TABLE `tbl_client_role` (
  `client_role_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `menu_id` int NOT NULL,
  PRIMARY KEY (`client_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (1, 2, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (2, 2, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (3, 2, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (4, 2, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (5, 2, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (6, 2, 19);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (7, 2, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (8, 2, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (9, 27, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (10, 27, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (11, 27, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (12, 27, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (13, 27, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (14, 27, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (15, 27, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (16, 27, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (17, 27, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (18, 27, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (19, 27, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (20, 27, 22);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (21, 28, 1);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (22, 28, 2);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (23, 28, 3);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (24, 28, 4);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (25, 28, 5);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (26, 28, 6);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (27, 28, 7);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (28, 28, 17);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (29, 28, 18);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (30, 28, 20);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (31, 28, 21);
INSERT INTO `tbl_client_role` (`client_role_id`, `user_id`, `menu_id`) VALUES (32, 28, 22);


#
# TABLE STRUCTURE FOR: tbl_clock
#

DROP TABLE IF EXISTS `tbl_clock`;

CREATE TABLE `tbl_clock` (
  `clock_id` int NOT NULL AUTO_INCREMENT,
  `attendance_id` int NOT NULL,
  `clockin_time` time DEFAULT NULL,
  `clockout_time` time DEFAULT NULL,
  `comments` text,
  `clocking_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1= clockin_time',
  `ip_address` varchar(50) DEFAULT NULL,
  `latitude` varchar(300) DEFAULT NULL,
  `longitude` varchar(300) DEFAULT NULL,
  `location` text,
  PRIMARY KEY (`clock_id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (1, 1, '21:04:14', '21:05:47', NULL, 0, '106.51.172.242', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (2, 2, '21:19:04', '21:20:37', NULL, 0, '106.51.172.242', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (3, 1, '09:20:00', '10:29:15', NULL, 0, '106.51.172.242', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (4, 3, '09:20:03', NULL, NULL, 1, '106.51.172.242', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (5, 4, '08:44:04', '10:29:15', NULL, 0, '94.202.195.223', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (6, 5, '10:45:15', '10:45:35', NULL, 0, '94.202.195.223', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (7, 6, '09:43:18', '09:45:48', NULL, 0, '106.51.170.63', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (8, 6, '10:32:18', '19:58:08', NULL, 0, '106.51.170.63', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (9, 7, '19:58:20', '19:58:39', NULL, 0, '106.51.175.4', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (10, 7, '19:58:55', NULL, NULL, 1, '106.51.175.4', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (11, 8, '07:59:42', '20:10:28', NULL, 0, '106.51.175.4', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (12, 9, '01:27:19', '13:27:23', NULL, 0, '5.31.242.87', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (13, 10, '12:30:35', '04:07:43', NULL, 0, '5.31.242.87', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (14, 11, '12:30:35', '08:44:14', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (15, 12, '12:30:35', '08:44:17', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (16, 13, '12:30:35', '08:44:24', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (17, 14, '12:30:35', '08:44:37', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (18, 15, '12:30:35', '08:44:53', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (19, 16, '12:30:35', '08:44:50', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (20, 17, '12:30:35', '08:44:48', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (21, 18, '12:30:35', '08:44:56', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (22, 19, '12:30:35', '08:45:00', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (23, 20, '12:30:35', '08:44:44', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (24, 21, '12:30:35', '08:45:24', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (25, 22, '12:30:35', '08:44:40', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (26, 23, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (27, 24, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (28, 25, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (29, 26, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (30, 27, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (31, 28, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (32, 29, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (33, 30, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (34, 31, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (35, 32, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (36, 33, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (37, 34, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (38, 35, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (39, 36, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (40, 37, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (41, 38, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (42, 39, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (43, 40, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (44, 41, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (45, 42, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (46, 43, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (47, 44, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (48, 45, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (49, 46, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (50, 47, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (51, 48, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (52, 49, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (53, 50, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (54, 51, '12:30:35', NULL, NULL, 1, '106.51.172.65', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (55, 52, '12:30:35', '08:45:12', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (56, 53, '12:30:35', '08:44:35', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (57, 10, '04:09:18', '08:43:59', NULL, 0, '106.51.171.60', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (58, 54, '10:32:17', '10:32:29', NULL, 0, '106.51.175.215', NULL, NULL, NULL);
INSERT INTO `tbl_clock` (`clock_id`, `attendance_id`, `clockin_time`, `clockout_time`, `comments`, `clocking_status`, `ip_address`, `latitude`, `longitude`, `location`) VALUES (59, 54, '10:32:39', '10:32:54', NULL, 0, '106.51.175.215', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_clock_history
#

DROP TABLE IF EXISTS `tbl_clock_history`;

CREATE TABLE `tbl_clock_history` (
  `clock_history_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `clock_id` int NOT NULL,
  `clockin_edit` time NOT NULL,
  `clockout_edit` time DEFAULT NULL,
  `reason` varchar(300) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=pending and 2 = accept  3= reject',
  `notify_me` tinyint NOT NULL DEFAULT '1',
  `view_status` tinyint NOT NULL DEFAULT '2',
  `request_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`clock_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_config
#

DROP TABLE IF EXISTS `tbl_config`;

CREATE TABLE `tbl_config` (
  `config_key` varchar(255) NOT NULL,
  `value` text,
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_private_key', 'CE6B7C6E-CDC4-404A-80D7-08F40CC0C65D');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_publishable_key', 'D188F8DC-3B8A-408E-A479-15A54113C461');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_seller_id', '901386312');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('2checkout_status', 'deactive');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('absent_color', 'rgba(247,23,36,0.92)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('absent_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('accounting_snapshot', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_background', '#1c7086');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_color', '#c1c1c1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_cronjob', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_custom_color', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('active_pre_loader', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('advance_salary', 'true');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('advance_salary_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_api_login_id', '7F6eJh7uFyD');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_authorize_live ', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_authorize_status', 'deactive');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aim_authorize_transaction_key', '64uhZ93mqH6c3MWf');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allowed_files', 'gif|png|jpeg|jpg|pdf|doc|txt|docx|xls|zip|rar|xls|mp4|ico');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allowed_radius', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_apply_job_from_login', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_client_project', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_client_registration', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_customer_edit_amount', 'No');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_custom_permission', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_geo_clock_in', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_multiple_client_in_project', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_sub_tasks', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('allow_weekend_excluded_from_leave', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('amount_to_words_lowercase', 'No');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('announcements_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('api_signature', 'AZxbwZ9bPVPFFf7hCCNemacLJwlCAqoMULHXAenCuJAwtzfjGbkbaIhV');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aside-collapsed', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('aside-float', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('attendance_report', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('authorize', 'login id');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('authorize_net_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('authorize_transaction_key', 'transfer key');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('automatic_database_backup', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('automatic_email_on_recur', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('auto_check_for_new_notifications', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('auto_close_ticket', '72');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('award_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bank_cash', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bitcoin_address', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bitcoin_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('body_background', 'rgba(229,252,252,0.81)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('body_font_size', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_default_account', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_live_or_sandbox', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_merchant_id', '9m2qzhrptx7wyccy');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_private_key', 'aa804bc269d4a9c8d8170ab8aed353b3');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_public_key', '62grv2dnvfpg599v');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('braintree_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bugs_color', '#1f3d1c');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('bugs_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('build', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_access_code', 'AVEB75FA40AM89BEMA');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_enable_test_mode', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_key', '201F5203749670E18D664192B594B74E');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_merchant_id', '161761');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('ccavenue_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('chat_interval_time', '5');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('client_default_menu', 'a:1:{s:19:\"client_default_menu\";a:12:{i:0;s:2:\"17\";i:1;s:2:\"18\";i:2;s:2:\"20\";i:3;s:1:\"1\";i:4;s:1:\"2\";i:5;s:1:\"3\";i:6;s:1:\"4\";i:7;s:1:\"5\";i:8;s:2:\"21\";i:9;s:1:\"6\";i:10;s:1:\"7\";i:11;s:2:\"22\";}}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_address', 'demo');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_city', 'aaa');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_country', 'United Arab Emirates');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_domain', 'r');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_email', 'admin@hayatjadidagroups.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_legal_name', 'hayatjadidagroups');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_logo', 'uploads/trans_logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_name', 'hayatjadidagroups');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_phone', '98960');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_phone_2', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_vat', 'r');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('company_zip_code', '33434');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_additional_flag', '/novalidate-cert');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_host', 'mail.coderitems.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_imap', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_imap_or_pop', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_mailbox', 'INBOX');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_password', '1c896e7d0fcbf64bb0921dd4bec18c947d34a5397472bb13b9f9ed95e4fd10dea45f365dde644233b2eef83f34e67cfd2fcc29b99c2835b89e8ecde5cdf233081hQfQaY72VtMiijV4wlVI6nmPwdsrMgJHALC3GCDw8E=');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_pop3', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_port', '993');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_ssl', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('config_username', 'support@coderitems.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('contact_person', 'hayatjadidagroups');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('contract_expiration_reminder', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('copyright_name', 'Uniquecoder');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('copyright_url', 'https://prowebber.ru/');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('country', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('cron_key', '34WI2L12L87I1A65M90M9A42N41D08A26I');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('currency_position', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('date_format', '%m.%d.%Y');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('date_php_format', 'Y.m.d');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('date_picker_format', 'yyyy.mm.dd');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('decimal_separator', '2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_account', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_currency', 'AED');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_currency_symbol', '$');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_department', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_language', 'english');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_leads_source', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_lead_permission', 'all');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_lead_status', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_payment_method', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_priority', 'Medium');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_status', 'open');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_tax', 'N;');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('default_terms', 'Thank you for <span style=\"font-weight: bold;\">your</span> busasiness. Please process this invoice within the due date.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('delete_mail_after_import', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('demo_mode', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('deposit_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('desktop_notifications', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('developer', 'ig63Yd/+yuA8127gEyTz9TY4pnoeKq8dtocVP44+BJvtlRp8Vqcetwjk51dhSB6Rx8aVIKOPfUmNyKGWK7C/gg==');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('display_estimate_badge', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('display_invoice_badge', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_account_details', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_estimate_message', 'Hi {CLIENT}<br>Thanks for your business inquiry. <br>The estimate EST {REF} is attached with this email. <br>Estimate Overview:<br>Estimate # : EST {REF}<br>Amount: {CURRENCY} {AMOUNT}<br> You can view the estimate online at:<br>{LINK}<br>Best Regards,<br>{COMPANY}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_invoice_message', 'Hello {CLIENT}<br>Here is the invoice of {CURRENCY} {AMOUNT}<br>You can view the invoice online at:<br>{LINK}<br>Best Regards,<br>{COMPANY}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('email_staff_tickets', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('enable_languages', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('encryption', 'ssl');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_color', 'rgba(160,29,171,1)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_footer', '<span style=\"font-weight: bold; line-height: 21.4px; text-align: right;\">Estimate&nbsp;</span>was created on a computer and is valid without the signature and seal');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_language', 'en');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_prefix', 'EST');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_state', 'block');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('estimate_terms', 'Hey Looking forward to doing business with you.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('expense_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('favicon', 'uploads/favicon.ico');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('file_max_size', '80000');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('for_invoice', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('for_leads', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('for_tickets', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('gcal_api_key', 'AIzaSyBXcmmcboEyAgtoUtXjKXe4TfpsnEtoUDQ');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('gcal_id', 'kla83orf1u7hrj6p0u5gdmpji4@group.calendar.google.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('goal_tracking_color', '#537015');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('goal_tracking_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('google_api_key', 'AIzaSyDH0Cn1U4RGzExl3IySE9X_ZlXKpyxj2Z4');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('gst_state', 'AN');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('holiday_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('imap_search', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('imap_search_for_leads', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('imap_search_for_tickets', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('increment_estimate_number', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('increment_invoice_number', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('increment_proposal_number', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('installed', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoices_due_after', '5');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_color', '#53b567');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_footer', 'Invoice was created on a computer and is valid without the signature and seal');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_language', 'en');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_logo', 'uploads/thumnail.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_prefix', 'INV');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_state', 'block');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('invoice_view', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('item_total_qty_alert', 'No');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('job_circular_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('language', 'english');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('languages', 'spanish');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_autobackup', '1515398440');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_check', '1436363002');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_cronjob_run', '1515398438');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_postmaster_run', '1532751856');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_seen_activities', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('last_tickets_postmaster_run', '1532750363');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('layout-boxed', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('layout-fixed', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('layout-h', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leads_color', '#783131');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leads_keyword', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leads_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('leave_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('locale', 'en_US');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('login_background', 'uploads/office.jpg');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('login_bg', 'bg-login.jpg');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('login_position', 'left');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('logofile', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('logo_or_icon', 'logo_title');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mark_attendance_from_login', 'Yes');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('max_file_size', '5000');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('milestone_color', '#a86495');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('milestone_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mollie_api_key', 'test_tkjFqFF6fP92FDSwBDHpeCzBRMBQBD');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mollie_partner_id', '3106644');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('mollie_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('money_format', '2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('navbar_logo_background', 'rgba(104,155,162,0.95)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notified_user', '[\"1\"]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_bug_assignment', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_bug_comments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_bug_status', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_message_received', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_project_assignments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_project_comments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_project_files', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_task_assignments', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('notify_ticket_reopened', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_hours', '8');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_lat', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_location', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_long', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('office_time', 'same_time');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('only_allowed_ip_can_clock', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('on_leave_color', '#bd1a10');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('on_leave_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('opportunities_color', '#349685');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('opportunities_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('overtime_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payments_color', '#7f21c9');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payments_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_api_password', 'e64448f3fd988dda8ad7e0b1ba21a14c3e59a959008623d9c8bcfca8ca8f73677a82bc6d14075614ea192a98fa0494259859dd0e229ff831c1cdd7751f440cb0cS8v4CPtSoiC4rDwMliNLKtf35DXaZih8pZ7W6mRM9UJg9jYeKg0wwsnFA5Kqywv');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_api_username', 'billing_api1.itsolidity.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_cancel_url', 'paypal/cancel');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_email', 'billing@coderitems.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_ipn_url', 'paypal/t_ipn/ipn');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_live', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('paypal_success_url', 'paypal/success');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payslip_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_enable_test_mode', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_key', '3424');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_salt', '342342');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('payumoney_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pdf_engine', 'invoicr');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('performance_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('postmark_api_key', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('postmark_from_address', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_color', '#e61755');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_details_view', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('project_prefix', 'PRO');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_footer', '<span style=\"font-weight: 700; text-align: right;\">This Proposal&nbsp;</span>was created on a computer and is valid without the signature and seal');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_prefix', 'PRO-');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('proposal_terms', 'Hey Looking forward to doing business with you.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('protocol', 'smtp');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_code', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_prefix', 'PUR');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('purchase_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_app_id', '401479');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_app_key', '4cf88668659dc9c987c3');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_app_secret', '6fce183b214d17c20dd5');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('pusher_cluster', 'ap2');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('qty_calculation_from_items', 'Yes');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('realtime_notification', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('recaptcha_secret_key', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('recaptcha_site_key', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('recurring_invoice', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('reminder_message', 'Hello {CLIENT}<br>This is a friendly reminder to pay your invoice of {CURRENCY} {AMOUNT}<br>You can view the invoice online at:<br>{LINK}<br>Best Regards,<br>{COMPANY}');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('reset_key', '34WI2L12L87I1A65M90M9A42N41D08A26I');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('return_stock_number_format', '[INV]-[yyyy]-[mm]-[dd]-[number]');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('return_stock_prefix', 'R');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('return_stock_start_no', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('rows_per_table', '25');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('RTL', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('security_token', '5027133599');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('send_email_when_recur', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('settings', 'theme');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show-scrollbar', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_estimate_tax', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_invoice_tax', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_item_tax', '0');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_login_image', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_only_logo', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('show_proposal_tax', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_active_background', '#0f778e');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_active_color', '#b3b8cb');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_background', 'rgba(2,53,60,0.95)');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_color', '#fffafa');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_font_size', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('sidebar_theme', 'bg-white');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_appleicon', 'logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_author', 'William M.');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_desc', 'Ultimate Project Manager CRM Pro is a Web based PHP application for Freelancers - buy it on Codecanyon');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_favicon', 'logo.png');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('site_icon', 'fa-flask');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_encryption', '');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_host', 'ss.ss.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_pass', 'L3FpSXB0bER6RWhBM2pueUYrRVlwQT09');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_port', '587');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('smtp_user', 'sss');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('stripe_private_key', 'sk_test_g7PUZTcwwFnxdlHrWSOicHfu');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('stripe_public_key', 'pk_test_x9as1c9jBDpODI7IbC7D0MEB');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('stripe_status', 'active');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('submenu_open_background', '#227f85');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('system_font', 'roboto_condensed');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tables_pagination_limit', '10');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tasks_color', '#0239c7');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tasks_on_calendar', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('task_details_view', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('thousand_separator', ',');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('tickets_keyword', NULL);
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('timezone', 'Asia/Dubai');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('time_format', 'H:i');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('top_bar_background', '#1f9494');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('top_bar_color', '#d9d9d9');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('training_email', '1');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('two_checkout_live ', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('unread_email', 'on');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('use_gravatar', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('use_postmark', 'FALSE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('valid_license', 'TRUE');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('version', '6.0.4');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('webmaster_email', 'support@example.com');
INSERT INTO `tbl_config` (`config_key`, `value`) VALUES ('website_name', 'hayatjadidagroups');


#
# TABLE STRUCTURE FOR: tbl_contract_type
#

DROP TABLE IF EXISTS `tbl_contract_type`;

CREATE TABLE `tbl_contract_type` (
  `contract_type_id` int NOT NULL AUTO_INCREMENT,
  `contract_type` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`contract_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_countries
#

DROP TABLE IF EXISTS `tbl_countries`;

CREATE TABLE `tbl_countries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `value` varchar(250) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_countries` (`id`, `value`) VALUES (1, 'Afghanistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (2, 'Aringland Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (3, 'Albania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (4, 'Algeria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (5, 'American Samoa');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (6, 'Andorra');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (7, 'Angola');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (8, 'Anguilla');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (9, 'Antarctica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (10, 'Antigua and Barbuda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (11, 'Argentina');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (12, 'Armenia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (13, 'Aruba');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (14, 'Australia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (15, 'Austria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (16, 'Azerbaijan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (17, 'Bahamas');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (18, 'Bahrain');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (19, 'Bangladesh');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (20, 'Barbados');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (21, 'Belarus');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (22, 'Belgium');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (23, 'Belize');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (24, 'Benin');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (25, 'Bermuda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (26, 'Bhutan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (27, 'Bolivia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (28, 'Bosnia and Herzegovina');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (29, 'Botswana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (30, 'Bouvet Island');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (31, 'Brazil');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (32, 'British Indian Ocean territory');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (33, 'Brunei Darussalam');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (34, 'Bulgaria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (35, 'Burkina Faso');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (36, 'Burundi');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (37, 'Cambodia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (38, 'Cameroon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (39, 'Canada');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (40, 'Cape Verde');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (41, 'Cayman Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (42, 'Central African Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (43, 'Chad');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (44, 'Chile');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (45, 'China');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (46, 'Christmas Island');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (47, 'Cocos (Keeling) Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (48, 'Colombia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (49, 'Comoros');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (50, 'Congo');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (51, 'Congo');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (52, ' Democratic Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (53, 'Cook Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (54, 'Costa Rica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (55, 'Ivory Coast (Ivory Coast)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (56, 'Croatia (Hrvatska)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (57, 'Cuba');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (58, 'Cyprus');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (59, 'Czech Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (60, 'Denmark');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (61, 'Djibouti');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (62, 'Dominica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (63, 'Dominican Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (64, 'East Timor');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (65, 'Ecuador');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (66, 'Egypt');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (67, 'El Salvador');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (68, 'Equatorial Guinea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (69, 'Eritrea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (70, 'Estonia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (71, 'Ethiopia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (72, 'Falkland Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (73, 'Faroe Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (74, 'Fiji');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (75, 'Finland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (76, 'France');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (77, 'French Guiana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (78, 'French Polynesia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (79, 'French Southern Territories');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (80, 'Gabon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (81, 'Gambia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (82, 'Georgia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (83, 'Germany');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (84, 'Ghana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (85, 'Gibraltar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (86, 'Greece');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (87, 'Greenland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (88, 'Grenada');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (89, 'Guadeloupe');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (90, 'Guam');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (91, 'Guatemala');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (92, 'Guinea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (93, 'Guinea-Bissau');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (94, 'Guyana');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (95, 'Haiti');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (96, 'Heard and McDonald Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (97, 'Honduras');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (98, 'Hong Kong');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (99, 'Hungary');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (100, 'Iceland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (101, 'India');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (102, 'Indonesia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (103, 'Iran');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (104, 'Iraq');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (105, 'Ireland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (106, 'Israel');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (107, 'Italy');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (108, 'Jamaica');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (109, 'Japan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (110, 'Jordan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (111, 'Kazakhstan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (112, 'Kenya');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (113, 'Kiribati');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (114, 'Korea (north)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (115, 'Korea (south)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (116, 'Kuwait');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (117, 'Kyrgyzstan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (118, 'Lao People\'s Democratic Republic');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (119, 'Latvia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (120, 'Lebanon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (121, 'Lesotho');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (122, 'Liberia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (123, 'Libyan Arab Jamahiriya');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (124, 'Liechtenstein');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (125, 'Lithuania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (126, 'Luxembourg');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (127, 'Macao');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (128, 'Macedonia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (129, 'Madagascar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (130, 'Malawi');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (131, 'Malaysia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (132, 'Maldives');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (133, 'Mali');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (134, 'Malta');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (135, 'Marshall Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (136, 'Martinique');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (137, 'Mauritania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (138, 'Mauritius');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (139, 'Mayotte');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (140, 'Mexico');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (141, 'Micronesia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (142, 'Moldova');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (143, 'Monaco');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (144, 'Mongolia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (145, 'Montserrat');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (146, 'Morocco');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (147, 'Mozambique');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (148, 'Myanmar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (149, 'Namibia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (150, 'Nauru');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (151, 'Nepal');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (152, 'Netherlands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (153, 'Netherlands Antilles');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (154, 'New Caledonia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (155, 'New Zealand');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (156, 'Nicaragua');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (157, 'Niger');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (158, 'Nigeria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (159, 'Niue');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (160, 'Norfolk Island');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (161, 'Northern Mariana Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (162, 'Norway');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (163, 'Oman');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (164, 'Pakistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (165, 'Palau');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (166, 'Palestinian Territories');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (167, 'Panama');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (168, 'Papua New Guinea');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (169, 'Paraguay');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (170, 'Peru');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (171, 'Philippines');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (172, 'Pitcairn');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (173, 'Poland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (174, 'Portugal');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (175, 'Puerto Rico');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (176, 'Qatar');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (177, 'Runion');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (178, 'Romania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (179, 'Russian Federation');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (180, 'Rwanda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (181, 'Saint Helena');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (182, 'Saint Kitts and Nevis');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (183, 'Saint Lucia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (184, 'Saint Pierre and Miquelon');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (185, 'Saint Vincent and the Grenadines');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (186, 'Samoa');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (187, 'San Marino');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (188, 'Sao Tome and Principe');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (189, 'Saudi Arabia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (190, 'Senegal');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (191, 'Serbia and Montenegro');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (192, 'Seychelles');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (193, 'Sierra Leone');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (194, 'Singapore');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (195, 'Slovakia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (196, 'Slovenia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (197, 'Solomon Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (198, 'Somalia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (199, 'South Africa');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (200, 'South Georgia and the South Sandwich Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (201, 'Spain');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (202, 'Sri Lanka');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (203, 'Sudan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (204, 'Suriname');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (205, 'Svalbard and Jan Mayen Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (206, 'Swaziland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (207, 'Sweden');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (208, 'Switzerland');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (209, 'Syria');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (210, 'Taiwan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (211, 'Tajikistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (212, 'Tanzania');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (213, 'Thailand');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (214, 'Togo');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (215, 'Tokelau');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (216, 'Tonga');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (217, 'Trinidad and Tobago');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (218, 'Tunisia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (219, 'Turkey');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (220, 'Turkmenistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (221, 'Turks and Caicos Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (222, 'Tuvalu');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (223, 'Uganda');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (224, 'Ukraine');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (225, 'United Arab Emirates');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (226, 'United Kingdom');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (227, 'United States of America');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (228, 'Uruguay');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (229, 'Uzbekistan');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (230, 'Vanuatu');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (231, 'Vatican City');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (232, 'Venezuela');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (233, 'Vietnam');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (234, 'Virgin Islands (British)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (235, 'Virgin Islands (US)');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (236, 'Wallis and Futuna Islands');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (237, 'Western Sahara');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (238, 'Yemen');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (239, 'Zaire');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (240, 'Zambia');
INSERT INTO `tbl_countries` (`id`, `value`) VALUES (241, 'Zimbabwe');


#
# TABLE STRUCTURE FOR: tbl_credit_note
#

DROP TABLE IF EXISTS `tbl_credit_note`;

CREATE TABLE `tbl_credit_note` (
  `credit_note_id` int NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT '0',
  `credit_note_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `credit_note_month` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `credit_note_year` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `currency` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `discount_percent` int DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `tax` int NOT NULL DEFAULT '0',
  `total_tax` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'open',
  `date_saved` timestamp NOT NULL DEFAULT '2018-12-12 10:00:00',
  `emailed` varchar(11) DEFAULT NULL,
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `client_visible` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `discount_type` enum('none','before_tax','after_tax') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'none',
  `user_id` int NOT NULL DEFAULT '0' COMMENT 'sales agent',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `warehouse_id` int DEFAULT NULL,
  `tags` text,
  PRIMARY KEY (`credit_note_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_credit_note_items
#

DROP TABLE IF EXISTS `tbl_credit_note_items`;

CREATE TABLE `tbl_credit_note_items` (
  `credit_note_items_id` int NOT NULL AUTO_INCREMENT,
  `credit_note_id` int NOT NULL,
  `saved_items_id` int DEFAULT '0',
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `item_tax_total` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `date_saved` timestamp NOT NULL DEFAULT '2018-12-12 10:00:00',
  `unit` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `order` int DEFAULT '0',
  PRIMARY KEY (`credit_note_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_credit_used
#

DROP TABLE IF EXISTS `tbl_credit_used`;

CREATE TABLE `tbl_credit_used` (
  `credit_used_id` int NOT NULL AUTO_INCREMENT,
  `invoices_id` int NOT NULL,
  `credit_note_id` int NOT NULL,
  `user_id` int NOT NULL,
  `date` date NOT NULL,
  `date_applied` datetime NOT NULL,
  `amount` decimal(18,3) NOT NULL,
  `payments_id` int DEFAULT NULL,
  PRIMARY KEY (`credit_used_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_currencies
#

DROP TABLE IF EXISTS `tbl_currencies`;

CREATE TABLE `tbl_currencies` (
  `code` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `symbol` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `xrate` decimal(12,5) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('AED', 'dirham', 'د.', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('AUD', 'Australian Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('BAN', 'Bangladesh', 'BDT', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('BRL', 'Brazilian Real', 'R$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CAD', 'Canadian Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CHF', 'Swiss Franc', 'Fr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CLP', 'Chilean Peso', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CNY', 'Chinese Yuan', 'Ã‚Â¥', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('CZK', 'Czech Koruna', 'KÃ„', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('DKK', 'Danish Krone', 'kr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('EUR', 'Euro', 'Ã¢â€š', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('GBP', 'British Pound', 'Ã‚Â£', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('HKD', 'Hong Kong Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('HUF', 'Hungarian Forint', 'Ft', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('IDR', 'Indonesian Rupiah', 'Rp', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('ILS', 'Israeli New Shekel', 'Ã¢â€š', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('INR', 'Indian Rupee', '₹', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('JPY', 'Japanese Yen', 'Ã‚Â¥', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('KRW', 'Korean Won', 'Ã¢â€š', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('MXN', 'Mexican Peso', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('MYR', 'Malaysian Ringgit', 'RM', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('NOK', 'Norwegian Krone', 'kr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('NZD', 'New Zealand Dollar', '$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('PHP', 'Philippine Peso', 'Ã¢â€š', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('PKR', 'Pakistan Rupee', 'PKR', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('PLN', 'Polish Zloty', 'zl', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('RUB', 'Russian Ruble', ' RUB', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('SEK', 'Swedish Krona', 'kr', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('SGD', 'Singapore Dollar', 'S$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('THB', 'Thai Baht', 'Ã Â¸Â', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('TRY', 'Turkish Lira', ' TRY', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('TWD', 'Taiwan Dollar', 'NT$', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('USD', 'US Dollar', '$', '1.00000');
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('VEF', 'Bol?var Fuerte', 'Bs.', NULL);
INSERT INTO `tbl_currencies` (`code`, `name`, `symbol`, `xrate`) VALUES ('ZAR', 'South African Rand', 'R', NULL);


#
# TABLE STRUCTURE FOR: tbl_custom_field
#

DROP TABLE IF EXISTS `tbl_custom_field`;

CREATE TABLE `tbl_custom_field` (
  `custom_field_id` int NOT NULL AUTO_INCREMENT,
  `form_id` int DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text,
  `help_text` varchar(200) NOT NULL,
  `field_type` enum('text','textarea','dropdown','date','checkbox','numeric','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` enum('active','deactive') NOT NULL DEFAULT 'deactive',
  `show_on_table` varchar(5) DEFAULT NULL,
  `visible_for_admin` varchar(5) DEFAULT NULL,
  `visible_for_client` varchar(11) DEFAULT NULL,
  `show_on_details` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`custom_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_customer_group
#

DROP TABLE IF EXISTS `tbl_customer_group`;

CREATE TABLE `tbl_customer_group` (
  `customer_group_id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(100) DEFAULT NULL COMMENT 'customer group,item group',
  `customer_group` varchar(200) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES ('1', 'client', 'Customer', 'Customer Sales Group');
INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES ('2', 'client', 'Man Power Supply', 'Man Power Supplier');
INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES ('3', 'projects', 'Civil', 'Unskilled Labour');
INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES ('4', 'projects', 'Skilled', 'Skilled Labour');
INSERT INTO `tbl_customer_group` (`customer_group_id`, `type`, `customer_group`, `description`) VALUES ('5', 'projects', 'Unskilled', 'Unskilled Labour');


#
# TABLE STRUCTURE FOR: tbl_dashboard
#

DROP TABLE IF EXISTS `tbl_dashboard`;

CREATE TABLE `tbl_dashboard` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `col` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `order_no` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `report` tinyint(1) NOT NULL DEFAULT '0',
  `for_staff` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (1, 'income_expenses_report', 'col-sm-4', 1, 1, 1, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (2, 'invoice_payment_report', 'col-sm-4', 2, 1, 1, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (3, 'ticket_tasks_report', 'col-sm-4', 3, 1, 1, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (5, 'goal_report', 'col-md-6 ', 14, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (6, 'overdue_report', 'col-md-12', 10, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (11, 'my_project', 'col-md-6', 32, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (12, 'my_tasks', 'col-md-6', 35, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (14, 'announcements', 'col-md-6', 38, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (15, 'payments_report', 'col-md-6', 47, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (16, 'income_expense', 'col-md-6', 23, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (17, 'income_report', 'col-md-6', 50, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (18, 'expense_report', 'col-md-6', 44, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (19, 'recently_paid_invoices', 'col-md-6', 29, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (20, 'recent_activities', 'col-md-6', 26, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (21, 'finance_overview', 'col-md-6', 17, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (22, 'todo_list', 'col-md-6', 40, 1, 0, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (23, 'paid_amount', 'col-md-3', 2, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (24, 'due_amount', 'col-md-3', 4, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (25, 'invoice_amount', 'col-md-3', 1, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (26, 'paid_percentage', 'col-md-3', 3, 1, 2, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (27, 'recently_paid_invoices', 'col-sm-6', 2, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (28, 'payments', 'col-sm-6', 1, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (29, 'recent_invoice', 'col-sm-6', 3, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (30, 'recent_projects', 'col-sm-6', 4, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (31, 'recent_emails', 'col-sm-4', 5, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (32, 'recent_activities', 'col-sm-4', 6, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (33, 'announcements', 'col-sm-4', 7, 1, 3, 1);
INSERT INTO `tbl_dashboard` (`id`, `name`, `col`, `order_no`, `status`, `report`, `for_staff`) VALUES (34, 'my_calendar', 'col-md-6', 18, 1, 0, 1);


#
# TABLE STRUCTURE FOR: tbl_days
#

DROP TABLE IF EXISTS `tbl_days`;

CREATE TABLE `tbl_days` (
  `day_id` int NOT NULL AUTO_INCREMENT,
  `day` varchar(100) NOT NULL,
  PRIMARY KEY (`day_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (1, 'Saturday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (2, 'Sunday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (3, 'Monday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (4, 'Tuesday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (5, 'Wednesday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (6, 'Thursday');
INSERT INTO `tbl_days` (`day_id`, `day`) VALUES (7, 'Friday');


#
# TABLE STRUCTURE FOR: tbl_departments
#

DROP TABLE IF EXISTS `tbl_departments`;

CREATE TABLE `tbl_departments` (
  `departments_id` int NOT NULL AUTO_INCREMENT,
  `deptname` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `department_head_id` int DEFAULT NULL COMMENT 'department_head_id == user_id',
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `encryption` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `host` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `password` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `mailbox` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `unread_email` tinyint(1) NOT NULL DEFAULT '0',
  `delete_mail_after_import` tinyint(1) NOT NULL DEFAULT '0',
  `last_postmaster_run` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`departments_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (1, 'Admin', 6, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (2, 'Super Admin', 7, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (3, 'Employee', 8, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL);
INSERT INTO `tbl_departments` (`departments_id`, `deptname`, `department_head_id`, `email`, `encryption`, `host`, `username`, `password`, `mailbox`, `unread_email`, `delete_mail_after_import`, `last_postmaster_run`) VALUES (4, 'LABOUR', 32, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL);


#
# TABLE STRUCTURE FOR: tbl_designations
#

DROP TABLE IF EXISTS `tbl_designations`;

CREATE TABLE `tbl_designations` (
  `designations_id` int NOT NULL AUTO_INCREMENT,
  `departments_id` int NOT NULL,
  `designations` varchar(100) NOT NULL,
  `permission` text,
  PRIMARY KEY (`designations_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (1, 1, 'Manager', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (2, 1, 'Manager', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (3, 1, 'Manager', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (4, 2, 'CTO', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (5, 3, 'Staff', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (6, 3, 'Staff', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (7, 3, 'Staff', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (8, 1, 'CLEANERS', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (9, 1, 'MASON', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (10, 4, 'MASON', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (11, 3, 'CARPENTER', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (12, 3, 'STEEL FIXER', NULL);
INSERT INTO `tbl_designations` (`designations_id`, `departments_id`, `designations`, `permission`) VALUES (13, 3, 'WELDER', NULL);


#
# TABLE STRUCTURE FOR: tbl_discipline
#

DROP TABLE IF EXISTS `tbl_discipline`;

CREATE TABLE `tbl_discipline` (
  `discipline_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `offence_id` int NOT NULL,
  `penalty_id` int NOT NULL,
  `discipline_break_date` varchar(100) NOT NULL,
  `discipline_action_date` varchar(100) NOT NULL,
  `discipline_remarks` varchar(200) NOT NULL,
  `discipline_comments` varchar(200) NOT NULL,
  PRIMARY KEY (`discipline_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_draft
#

DROP TABLE IF EXISTS `tbl_draft`;

CREATE TABLE `tbl_draft` (
  `draft_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `to` text NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message_body` text NOT NULL,
  `attach_file` text,
  `attach_file_path` text,
  `attach_filename` text,
  `message_time` datetime NOT NULL,
  `deleted` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`draft_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_email_templates
#

DROP TABLE IF EXISTS `tbl_email_templates`;

CREATE TABLE `tbl_email_templates` (
  `email_templates_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `email_group` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `template_body` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`email_templates_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (1, 'en', 'registration', 'Registration successful', '<div style=\"height: 7px; background-color: #535353;\"></div><div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Welcome to {SITE_NAME}</div><div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">Thanks for joining {SITE_NAME}. We listed your sign in details below, make sure you keep them safe.<br>To open your {SITE_NAME} homepage, please follow this link:<br><big><b><a href=\"{SITE_URL}\">{SITE_NAME} Account!</a></b></big><br>Link doesn\'t work? Copy the following link to your browser address bar:<br><a href=\"{SITE_URL}\">{SITE_URL}</a><br>Your username: {USERNAME}<br>Your email address: {EMAIL}<br>Your password: {PASSWORD}<br>Have fun!<br>The {SITE_NAME} Team.<br><br></div></div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (2, 'en', 'forgot_password', 'Forgot Password', '        <div style=\"height: 7px; background-color: #535353;\"></div><div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New Password</div><div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">Forgot your password, huh? No big deal.<br>To create a new password, just follow this link:<br><br><big><b><a href=\"{PASS_KEY_URL}\">Create a new password</a></b></big><br>Link doesn\'t work? Copy the following link to your browser address bar:<br><a href=\"{PASS_KEY_URL}\">{PASS_KEY_URL}</a><br><br><br>You received this email, because it was requested by a <a href=\"{SITE_URL}\">{SITE_NAME}</a> user. <p></p><p>This is part of the procedure to create a new password on the system. If you DID NOT request a new password then please ignore this email and your password will remain the same.</p><br>Thank you,<br>The {SITE_NAME} Team</div></div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (3, 'en', 'change_email', 'Change Email', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New email address on {SITE_NAME}</div>\r\n\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">You have changed your email address for {SITE_NAME}.<br>Follow this link to confirm your new email address:<br><big><b><a href=\"{NEW_EMAIL_KEY_URL}\">Confirm your new email</a></b></big><br>Link doesn\'t work? Copy the following link to your browser address bar:<br><a href=\"{NEW_EMAIL_KEY_URL}\">{NEW_EMAIL_KEY_URL}</a><br><br>Your email address: {NEW_EMAIL}<br><br>You received this email, because it was requested by a <a href=\"{SITE_URL}\">{SITE_NAME}</a> user. If you have received this by mistake, please DO NOT click the confirmation link, and simply delete this email. After a short time, the request will be removed from the system.<br>Thank you,<br>The {SITE_NAME} Team</div>\r\n\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (4, 'en', 'activate_account', 'Activate Account', '<p>Welcome to {SITE_NAME}!</p>\r\n\r\n<p>Thanks for joining {SITE_NAME}. We listed your sign in details below, make sure you keep them safe.</p>\r\n\r\n<p>To verify your email address, please follow this link:<br />\r\n<big><strong><a href=\"{ACTIVATE_URL}\">Finish your registration...</a></strong></big><br />\r\nLink doesn&#39;t work? Copy the following link to your browser address bar:<br />\r\n<a href=\"{ACTIVATE_URL}\">{ACTIVATE_URL}</a></p>\r\n\r\n<p><br />\r\n<br />\r\nPlease verify your email within {ACTIVATION_PERIOD} hours, otherwise your registration will become invalid and you will have to register again.<br />\r\n<br />\r\n<br />\r\nYour username: {USERNAME}<br />\r\nYour email address: {EMAIL}<br />\r\nYour password: {PASSWORD}<br />\r\n<br />\r\nHave fun!<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (5, 'en', 'reset_password', 'Reset Password', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New password on {SITE_NAME}</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>You have changed your password.<br>Please, keep it in your records so you don\'t forget it.<br></p>\r\nYour username: {USERNAME}<br>Your email address: {EMAIL}<br>Your new password: {NEW_PASSWORD}<br><br>Thank you,<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (6, 'en', 'bug_assigned', 'New Bug Assigned', '<p>Hi there,</p>\r\n\r\n<p>A new bug &nbsp;{BUG_TITLE} &nbsp;has been assigned to you by {ASSIGNED_BY}.</p>\r\n\r\n<p>You can view this bug by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (7, 'en', 'bug_updated', 'Bug status changed', '<p>Hi there,</p>\r\n\r\n<p>Bug {BUG_TITLE} has been marked as {STATUS} by {MARKED_BY}.</p>\r\n\r\n<p>You can view this bug by logging in to the portal using the link below.</p>\r\n\r\n<p><big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (8, 'en', 'bug_comments', 'New Bug Comment Received', '<p>Hi there,</p>\r\n\r\n<p>A new comment has been posted by {POSTED_BY} to bug {BUG_TITLE}.</p>\r\n\r\n<p>You can view the comment using the link below.</p>\r\n\r\n<p><em>{COMMENT_MESSAGE}</em></p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{COMMENT_URL}\">View Comment</a></strong></big><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (9, 'en', 'bug_attachment', 'New bug attachment', '<p>Hi there,</p>\r\n\r\n<p>A new attachment&nbsp;has been uploaded by {UPLOADED_BY} to issue {BUG_TITLE}.</p>\r\n\r\n<p>You can view the bug using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big></p>\r\n\r\n<p><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (10, 'en', 'bug_reported', 'New bug Reported', '<p>Hi there,</p>\r\n\r\n<p>A new bug ({BUG_TITLE}) has been reported by {ADDED_BY}.</p>\r\n\r\n<p>You can view the Bug using the Dashboard Page.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{BUG_URL}\">View Bug</a></strong></big></p>\r\n\r\n<p><br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (13, 'en', 'refund_confirmation', 'Refund Confirmation', '<p>Refund Confirmation</p>\r\n\r\n<p>Hello {CLIENT}</p>\r\n\r\n<p>This is confirmation that a refund has been processed for Invoice&nbsp; of {CURRENCY} {AMOUNT}&nbsp;sent on {INVOICE_DATE}.<br />\r\nYou can view the invoice online at:<br />\r\n<big><strong><a href=\"{INVOICE_LINK}\">View Invoice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (14, 'en', 'payment_confirmation', 'Payment Confirmation', '<p>Payment Confirmation</p>\r\n\r\n<p>Hello {CLIENT}</p>\r\n\r\n<p>This is a payment receipt for your invoice of {CURRENCY} {AMOUNT}&nbsp;sent on {INVOICE_DATE}.<br />\r\nYou can view the invoice online at:<br />\r\n<big><strong><a href=\"{INVOICE_LINK}\">View Invoice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (15, 'en', 'payment_email', 'Payment Received', '<div style=\"height: 7px; background-color: #535353;\"></div>\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Payment Received</div>\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Dear Customer</p>\n<p>We have received your payment of {INVOICE_CURRENCY} {PAID_AMOUNT}. </p>\n<p>Thank you for your Payment and business. We look forward to working with you again.</p>\n--------------------------<br>Regards<br>The {SITE_NAME} Team</div>\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (16, 'en', 'invoice_overdue_email', 'Invoice Overdue Notice', '<p>Invoice Overdue</p>\r\n\r\n<p>INVOICE {REF}</p>\r\n\r\n<p><strong>Hello {CLIENT}</strong></p>\r\n\r\n<p>This is the notice that your invoice overdue.&nbsp;The invoice {CURRENCY} {AMOUNT}. and Due Date: {DUE_DATE}</p>\r\n\r\n<p>You can view the invoice online at:<br />\r\n<big><strong><a href=\"{INVOICE_LINK}\">View Invoice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (17, 'en', 'invoice_message', 'New Invoice', '<div style=\"height: 7px; background-color: #535353;\"></div><div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">INVOICE {REF}</div><div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><span class=\"style1\"><span style=\"font-weight:bold;\">Hello {CLIENT}</span></span><br><br>Here is the invoice of {CURRENCY} {AMOUNT}.<br><br>You can view the invoice online at:<br><big><b><a href=\"{INVOICE_LINK}\">View Invoice</a></b></big><br><br>Best Regards<br><br>The {SITE_NAME} Team</div></div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (18, 'en', 'invoice_reminder', 'Invoice Reminder', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Invoice Reminder</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Hello {CLIENT}</p>\r\n<br><p>This is a friendly reminder to pay your invoice of {CURRENCY} {AMOUNT}<br>You can view the invoice online at:<br><big><b><a href=\"{INVOICE_LINK}\">View Invoice</a></b></big><br><br>Best Regards,<br>The {SITE_NAME} Team</p>\r\n</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (19, 'en', 'message_received', 'Message Received', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Message Received</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Hi {RECIPIENT},</p>\r\n<p>You have received a message from {SENDER}. </p>\r\n------------------------------------------------------------------<br><blockquote>\r\n{MESSAGE}</blockquote>\r\n<big><b><a href=\"{SITE_URL}\">Go to Account</a></b></big><br><br>Regards<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (20, 'en', 'estimate_email', 'New Estimate', '<p>Estimate {ESTIMATE_REF}</p>\r\n\r\n<p>Hi {CLIENT}</p>\r\n\r\n<p>Thanks for your business inquiry.</p>\r\n\r\n<p>The estimate {ESTIMATE_REF} is attached with this email.<br />\r\nEstimate Overview:<br />\r\nEstimate # : {ESTIMATE_REF}<br />\r\nAmount: {CURRENCY} {AMOUNT}<br />\r\n<br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{ESTIMATE_LINK}\">View Estimate</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (21, 'en', 'ticket_staff_email', 'New Ticket [TICKET_CODE]', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">New Ticket</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Ticket #{TICKET_CODE} has been created by the client.</p>\r\n<p>You may view the ticket by clicking on the following link <br><br>  Client Email : {REPORTER_EMAIL}<br><br> <big><b><a href=\"{TICKET_LINK}\">View Ticket</a></b></big> <br><br>Regards<br><br>{SITE_NAME}</p>\r\n</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (22, 'en', 'ticket_client_email', 'Ticket [TICKET_CODE] Opened', '<p>Ticket Opened</p>\r\n\r\n<p>Hello {CLIENT_EMAIL},</p>\r\n\r\n<p>Your ticket has been opened with us.<br />\r\n<br />\r\nTicket # {TICKET_CODE}<br />\r\nStatus : Open<br />\r\n<br />\r\nClick on the below link to see the ticket details and post additional comments.<br />\r\n<br />\r\n<big><strong><a href=\"{TICKET_LINK}\">View Ticket</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (23, 'en', 'ticket_reply_email', 'Ticket [TICKET_CODE] Response', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Ticket Response</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>A new response has been added to Ticket #{TICKET_CODE}<br><br> Ticket : #{TICKET_CODE} <br>Status : {TICKET_STATUS} <br><br></p>\r\nTo see the response and post additional comments, click on the link below.<br><br>         <big><b><a href=\"{TICKET_LINK}\">View Reply</a> </b></big><br><br>          Note: Do not reply to this email as this email is not monitored.<br><br>     Regards<br>The {SITE_NAME} Team<br></div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (24, 'en', 'ticket_closed_email', 'Ticket [TICKET_CODE] Closed', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Ticket Closed</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\">Hi {REPORTER_EMAIL}<br><br>Ticket #{TICKET_CODE} has been closed by {STAFF_USERNAME} <br><br>          Ticket : #{TICKET_CODE} <br>     Status : {TICKET_STATUS}<br><br>Replies : {NO_OF_REPLIES}<br><br>          To see the responses or open the ticket, click on the link below.<br><br>          <big><b><a href=\"{TICKET_LINK}\">View Ticket</a></b></big> <br><br>          Note: Do not reply to this email as this email is not monitored.<br><br>    Regards<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (26, 'en', 'task_updated', 'Task updated', '<div style=\"height: 7px; background-color: #535353;\"></div>\r\n<div style=\"background-color:#E8E8E8; margin:0px; padding:55px 20px 40px 20px; font-family:Open Sans, Helvetica, sans-serif; font-size:12px; color:#535353;\"><div style=\"text-align:center; font-size:24px; font-weight:bold; color:#535353;\">Task updated</div>\r\n<div style=\"border-radius: 5px 5px 5px 5px; padding:20px; margin-top:45px; background-color:#FFFFFF; font-family:Open Sans, Helvetica, sans-serif; font-size:13px;\"><p>Hi there,</p>\r\n<p>{TASK_NAME} in {PROJECT_TITLE} has been updated by {ASSIGNED_BY}.</p>\r\n<p>You can view this project by logging in to the portal using the link below.</p>\r\n-----------------------------------<br><big><b><a href=\"{PROJECT_URL}\">View Project</a></b></big><br><br>Regards<br>The {SITE_NAME} Team</div>\r\n</div>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (27, 'en', 'quotations_form', 'Your Quotation Request', '<p>QUOTATION</p>\r\n\r\n<p><strong>Hello {CLIENT}</strong><br />\r\n&nbsp;</p>\r\n\r\n<p>Thank you for you for filling in our Quotation Request Form.<br />\r\n<br />\r\nPlease find below are our quotation:</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table cellpadding=\"8\" style=\"width:100%\">\r\n  <tbody>\r\n    <tr>\r\n      <td>Quotation Date</td>\r\n      <td><strong>{DATE}</strong></td>\r\n    </tr>\r\n    <tr>\r\n      <td>Our Quotation</td>\r\n      <td><strong>{CURRENCY} {AMOUNT}</strong></td>\r\n    </tr>\r\n    <tr>\r\n      <td>Addtitional Comments</td>\r\n      <td><strong>{NOTES}</strong></td>\r\n    </tr>\r\n  </tbody>\r\n</table>\r\n\r\n<p><br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{QUOTATION LINK}\">View Quotation</a></strong></big></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nThank you and we look forward to working with you.<br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (28, 'en', 'client_notification', 'New project created', '<p>Hello, <strong>{CLIENT_NAME}</strong>,<br />\r\nwe have created a new project with your account.<br />\r\n<br />\r\nProject name : <strong>{PROJECT_NAME}</strong><br />\r\nYou can login to see the status of your project by using this link:<br />\r\n<big><a href=\"{PROJECT_LINK}\"><strong>View Project</strong></a></big></p>\r\n\r\n<p><br />\r\nBest Regards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (29, 'en', 'assigned_project', 'Assigned Project', '<p>Hi There,</p>\r\n\r\n<p>A<strong> {PROJECT_NAME}</strong> has been assigned by <strong>{ASSIGNED_BY} </strong>to you.You can view this project by logging in to the portal using the link below:<br />\r\n<big><a href=\"{PROJECT_URL}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\nBest Regards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (30, 'en', 'complete_projects', 'Project Completed', '<p>Hi <strong>{CLIENT_NAME}</strong>,</p>\r\n\r\n<p>Project : <strong>{PROJECT_NAME}</strong> &nbsp;has been completed.<br />\r\nYou can view the project by logging into your portal Account:<br />\r\n<big><a href=\"{PROJECT_LINK}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (31, 'en', 'project_comments', 'New Project Comment Received', '<p>Hi There,</p>\r\n\r\n<p>A new comment has been posted by <strong>{POSTED_BY}</strong> to project <strong>{PROJECT_NAME}</strong>.</p>\r\n\r\n<p>You can view the comment using the link below:<br />\r\n<big><a href=\"{COMMENT_URL}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\n<em>{COMMENT_MESSAGE}</em><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (32, 'en', 'project_attachment', 'New Project  Attachment', '<p>Hi There,</p>\r\n\r\n<p>A new file has been uploaded by <strong>{UPLOADED_BY}</strong> to project <strong>{PROJECT_NAME}</strong>.<br />\r\nYou can view the Project using the link below:<br />\r\n<big><a href=\"{PROJECT_URL}\"><strong>View Project</strong></a></big><br />\r\n<br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (33, 'en', 'responsible_milestone', 'Responsible for a Milestone', '<p>Hi There,</p>\r\n\r\n<p>You are a responsible&nbsp;for a project milestone&nbsp;<strong>{MILESTONE_NAME}</strong>&nbsp; assigned to you by <strong>{ASSIGNED_BY}</strong> in project <strong>{PROJECT_NAME}</strong>.</p>\r\n\r\n<p>You can view this Milestone&nbsp;by logging in to the portal using the link below:<br />\r\n<big><strong><a href=\"{PROJECT_URL}\">View Project</a></strong></big><br />\r\n<br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (34, 'en', 'task_assigned', 'Task assigned', '<p>Hi there,</p>\r\n\r\n<p>A new task <strong>{TASK_NAME}</strong> &nbsp;has been assigned to you by <strong>{ASSIGNED_BY}</strong>.</p>\r\n\r\n<p>You can view this task by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{TASK_URL}\">View Task</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (35, 'en', 'tasks_comments', 'New Task Comment Received', '<p>Hi There,</p>\r\n\r\n<p>A new comment has been posted by <strong>{POSTED_BY}</strong> to <strong>{TASK_NAME}</strong>.</p>\r\n\r\n<p>You can view the comment using the link below:<br />\r\n<big><strong><a href=\"{COMMENT_URL}\">View Comment</a></strong></big><br />\r\n<br />\r\n<em>{COMMENT_MESSAGE}</em><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (36, 'en', 'tasks_attachment', 'New Tasks Attachment', '<p>Hi There,</p>\r\n\r\n<p>A new file has been uploaded by <strong>{UPLOADED_BY} </strong>to Task <strong>{TASK_NAME}</strong>.<br />\r\nYou can view the Task&nbsp;using the link below:</p>\r\n\r\n<p><br />\r\n<big><a href=\"{TASK_URL}\"><strong>View Task</strong></a></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (37, 'en', 'tasks_updated', 'Task updated', '<p>Hi there,</p>\r\n\r\n<p><strong>{TASK_NAME}</strong> has been updated by <strong>{ASSIGNED_BY}</strong>.</p>\r\n\r\n<p>You can view this Task by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{TASK_URL}\">View Task</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (38, 'en', 'goal_not_achieve', 'Not Achieve Goal', '<p><strong>Unfortunately!</strong> We failed to achieve goal!</p>\r\n\r\n<p><strong>Here is a Goal Details</strong></p>\r\n\r\n<p>Goal Type :&nbsp;<strong>{Goal_Type}</strong><br />\r\nTarget Achievement:&nbsp;<strong>{achievement}</strong><br />\r\nTotal Achievement:&nbsp;<strong>{total_achievement}</strong><br />\r\nStart Date:&nbsp;<strong>{start_date}</strong><br />\r\nEnd Date:&nbsp;<strong>{End_date}</strong><br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (39, 'en', 'goal_achieve', 'Achieve Goal', '<p><strong>Congratulation!</strong> We achieved new goal.</p>\r\n\r\n<p><strong>Here is a Goal Details</strong></p>\r\n\r\n<p>Goal Type :<strong>{Goal_Type}</strong><br />\r\nTarget Achievement:<strong>{achievement}</strong><br />\r\nTotal Achievement:<strong>{total_achievement}</strong><br />\r\nStart Date:<strong>{start_date}</strong><br />\r\nEnd Date:<strong>{End_date}</strong><br />\r\n&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (40, 'en', 'leave_request_email', 'A Leave Request from you', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong> &nbsp;Want to leave from you.</p>\r\n\r\n<p>You can view this leave request by logging in to the portal using the link below<br />\r\n<big><strong><a href=\"{APPLICATION_LINK}\">View Application</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (41, 'en', 'leave_approve_email', 'Your leave request has been approved', '<h1>Your leave request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong> Your leave request from <strong>{START_DATE}</strong> to <strong>{END_DATE}</strong> has been approved by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (42, 'en', 'leave_reject_email', 'Your leave request has been Rejected', '<h1>Your leave request has been Rejected</h1>\r\n\r\n<p><strong>Unfortunately !</strong>&nbsp;Your leave request from&nbsp;<strong>{START_DATE}</strong>&nbsp;to&nbsp;<strong>{END_DATE}</strong>&nbsp;has been Rejected by your company management.</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (43, 'en', 'overtime_request_email', 'Overtime Request', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong>&nbsp;&nbsp;to do an overtime.<br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (44, 'en', 'overtime_approved_email', 'Your overtime request has been approved', '<h1>Your leave request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong>&nbsp;Your overtime&nbsp;request at&nbsp;<strong>{DATE}</strong>&nbsp;and&nbsp;<strong>{HOUR}</strong>&nbsp;has been approved by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (45, 'en', 'overtime_reject_email', 'Your Overtime request has been Rejected', '<h1>Your leave request has been Rejected</h1>\r\n\r\n<p><strong>Unfortunately&nbsp;!</strong>&nbsp;Your overtime&nbsp;request at&nbsp;<strong>{DATE}</strong>&nbsp;and&nbsp;<strong>{HOUR}</strong>&nbsp;has been Rejected by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (46, 'en', 'wellcome_email', 'Welcome Email ', '<p>Hello <strong>{NAME}</strong>,</p>\r\n\r\n<p>Welcome to <strong>{COMPANY_NAME}</strong> .Thanks for joining <strong>{COMPANY_NAME}</strong>.</p>\r\n\r\n<p>We just wanted to say welcome.</p>\r\n\r\n<p>Please contact us if you need any help.</p>\r\n\r\n<p>Click here to view your profile: <strong>{COMPANY_URL}</strong></p>\r\n\r\n<p><br />\r\nHave fun!<br />\r\nThe <strong>{COMPANY_NAME}</strong> Team.</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (47, 'en', 'payslip_generated_email', 'Payslip generated', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>Your payslip generated for the month <strong>{MONTH_YEAR} .</strong></p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (48, 'en', 'advance_salary_email', 'Advance Salary Reqeust', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong>&nbsp;&nbsp;Want to Advance Salary from you.</p>\r\n\r\n<p>You can view this Advance Salary by logging in to the portal using the link below.<br />\r\n<br />\r\n<big><strong><a href=\"{LINK}\">View Advance Salary</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (49, 'en', 'advance_salary_approve_email', 'Your advance salary request has been approved', '<h1>Your advance salary request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong>&nbsp;Your advance salary&nbsp;requested &nbsp;<strong>{AMOUNT}</strong>&nbsp;has been approved by your company management.</p>\r\n\r\n<p>This advance amount will deduct the next <strong>{DEDUCT_MOTNH}</strong> .</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (50, 'en', 'advance_salary_reject_email', 'Your advance salary request has been Rejected', '<h1>Your advance salary request has been Rejected</h1>\r\n\r\n<p><strong>Unfortunately !</strong>&nbsp;Your advance salary requested&nbsp;<strong>{AMOUNT}</strong>&nbsp;has been Rejected by your company management.</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (51, 'en', 'award_email', 'Award Received', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>You have been&nbsp;awarded <strong>{AWARD_NAME} </strong>for this<strong> {MONTH} .</strong></p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (52, 'en', 'new_job_application_email', 'New job application submitted', '<p>Hi there,</p>\r\n\r\n<p>&nbsp;<strong>{NAME}&nbsp;</strong>has submitted the job application</p>\r\n\r\n<p>Please find below are job application Details:</p>\r\n\r\n<table cellpadding=\"8\" style=\"width:100%\">\r\n  <tbody>\r\n    <tr>\r\n      <td>Job Title</td>\r\n      <td><strong>{JOB_TITLE}</strong></td>\r\n    </tr>\r\n    <tr>\r\n      <td>Email</td>\r\n      <td><strong>{EMAIL}</strong></td>\r\n    </tr>\r\n    <tr>\r\n      <td>Mobile</td>\r\n      <td><strong>{MOBILE}</strong></td>\r\n    </tr>\r\n    <tr>\r\n      <td>Cover Latter</td>\r\n      <td><strong>{COVER_LETTER}</strong></td>\r\n    </tr>\r\n  </tbody>\r\n</table>\r\n\r\n<p><br />\r\nYou can view the Job Application online at:<br />\r\n<br />\r\n<big><strong><a href=\"{LINK}\">View Job Application</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (53, 'en', 'new_notice_published', 'New Notice published', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>New Notice Published&nbsp;<strong>{TITLE}</strong></p>\r\n\r\n<p><br />\r\nYou can view the Notice online at:<br />\r\n<br />\r\n<big><strong><a href=\"{LINK}\">View Notice</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (54, 'en', 'new_training_email', 'Training  Assigned ', '<p>Hi there,</p>\r\n\r\n<p>A new Training  &nbsp;<strong>{TRAINING_NAME}</strong>&nbsp;&nbsp;has been assigned to you by&nbsp;<strong>{ASSIGNED_BY}</strong>.</p>\r\n\r\n<p>You can view this Training  by logging in to the portal using the link below.</p>\r\n\r\n<p><br />\r\n<big><strong><a href=\"{LINK}\">View Training</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (55, 'en', 'performance_appraisal_email', 'New Performance Appraisal', '');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (56, 'en', 'expense_request_email', 'A New Expense Request have been Recieved', '<p>Hi there,</p>\r\n\r\n<p><strong>{NAME}</strong> &nbsp;Create a New Expense The Amount is <strong>{AMOUNT}</strong></p>\r\n\r\n<p>You can view this expense by logging in to the portal using the link below.<br />\r\n<br />\r\n<big><strong><a href=\"{URL}\">View Expense</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards,<br />\r\n<br />\r\nThe <strong>{SITE_NAME}</strong> Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (57, 'en', 'expense_approved_email', 'Expense Approved', '<p>Dear&nbsp;<strong>{NAME} ,</strong></p>\r\n\r\n<h1>Your Expense request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong>&nbsp;Your Expense request from&nbsp;<strong>{AMOUNT}</strong>&nbsp;has been approved by your company management.</p>\r\n\r\n<p>Please Contact&nbsp;with our Accountant for collect the amount.</p>\r\n\r\n<p><br />\r\nRegards,<br />\r\n<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (58, 'en', 'expense_paid_email', 'Expense have been Paid', '<p>Hi there,</p>\r\n\r\n<p>The&nbsp;<strong>{NAME}</strong>&nbsp;expense&nbsp;<strong>{AMOUNT}&nbsp;</strong>has been paid by <strong>{PAID_BY}.</strong></p>\r\n\r\n<p>You can view this expense by logging in to the portal using the link below.<br />\r\n<br />\r\n<big><strong><a href=\"{URL}\">View Expense</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards,<br />\r\n<br />\r\nThe&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (59, 'en', 'auto_close_ticket', 'Ticket Auto Closed', '<p>Ticket Closed</p>\r\n\r\n<p>Hello <strong>{REPORTER_EMAIL}</strong>,</p>\r\n\r\n<p>Ticket&nbsp;<strong>{SUBJECT}</strong>&nbsp;has been auto closed due to inactivity.&nbsp;<br />\r\n<br />\r\nTicket # <strong>{TICKET_CODE}</strong><br />\r\nStatus : &nbsp;<strong>{TICKET_STATUS}</strong><br />\r\n<br />\r\nTo see the responses or open the ticket, click on the link below:ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¾Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€šÃ‚Â¦ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Â ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡Ãƒâ€šÃ‚Â¬ÃƒÆ’Ã¢â‚¬Â¦Ãƒâ€šÃ‚Â¡ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¹<br />\r\n<br />\r\n<big><strong><a href=\"{TICKET_LINK}\">View Ticket</a></strong></big><br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe <strong>{SITE_NAME}</strong> Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (60, 'en', 'proposal_email', 'New Proposal', '<p>Proposal <strong>{PROPOSAL_REF}</strong></p> <p>Hi <strong>{CLIENT}</strong></p> <p>Thanks for your business inquiry.</p> <p>The Proposal <strong>{PROPOSAL_REF} </strong>is attached with this email.<br /> Proposal&nbsp;Overview:<br /> Proposal&nbsp;# :<strong> {PROPOSAL_REF}</strong><br /> Amount: <strong>{CURRENCY} {AMOUNT}</strong><br /> <br /> You can view the estimate online at:<br /> <big><strong><a href=\"{PROPOSAL_LINK}\">View Proposal</a></strong></big><br /> <br /> Best Regards,<br /> The <strong>{SITE_NAME}</strong> Team</p> ');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (61, 'en', 'project_overdue_email', 'Project Overdue Notice', '<p>Project Overdue</p>\r\n\r\n<p><strong>Hello {CLIENT}</strong></p>\r\n\r\n<p>This is the notice that your project overdue.&nbsp;<br />\r\n<br />\r\nProject name : <strong>{PROJECT_NAME}</strong><br />\r\nDue date : <strong>{DUE_DATE}</strong><br />\r\nYou can login to see the status of your project by using this link:<br />\r\n<big><a href=\"{PROJECT_LINK}\"><strong>View Project</strong></a></big></p>\r\n\r\n<p><br />\r\nBest Regards<br />\r\nThe {SITE_NAME} Team</p>\r\n\r\n<p>&nbsp;</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (62, 'en', 'estimate_overdue_email', 'Estimate Overdue Notice', '<p>Estimate {ESTIMATE_REF}</p>\r\n\r\n<p>Hi {CLIENT}</p>\r\n\r\n<p>This is the notice that your Estimate&nbsp;overdue.&nbsp;ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹<br />\r\n<br />\r\nEstimate Overview:<br />\r\nEstimate # : {ESTIMATE_REF}<br />\r\nAmount: {DUE_DATE}<br />\r\nAmount: {CURRENCY} {AMOUNT}<br />\r\n<br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{ESTIMATE_LINK}\">View Estimate</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe {SITE_NAME} Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (63, 'en', 'proposal_overdue_email', 'New Estimate', '<p>Proposal&nbsp;<strong>{PROPOSAL_REF}</strong></p>\r\n\r\n<p>Hi&nbsp;<strong>{CLIENT}</strong></p>\r\n\r\n<p>This is the notice that your Proposal&nbsp;overdue.&nbsp;<br />\r\n<br />\r\nProposal&nbsp;Overview:<br />\r\nProposal&nbsp;# :<strong>&nbsp;{PROPOSAL_REF}</strong><br />\r\nDue Date: <strong>{DUE_DATE}</strong>ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¹<br />\r\nAmount:&nbsp;<strong>{CURRENCY} {AMOUNT}</strong><br />\r\n<br />\r\nYou can view the estimate online at:<br />\r\n<big><strong><a href=\"{PROPOSAL_LINK}\">View Proposal</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (64, 'en', 'call_for_interview', 'You have an interview offer!!!', '<p>Hello&nbsp;<strong>{NAME}</strong>,</p>\r\n\r\n<p>You have an interview offer for you.please see the details.&nbsp;<br />\r\n<br />\r\n<strong>Job Summary</strong>:<br />\r\nJob Title # :<strong>&nbsp;{JOB_TITLE}</strong><br />\r\nDesignation # :<strong>&nbsp;{DESIGNATION}</strong><br />\r\nInterview Date: <strong>{DATE}</strong></p>\r\n\r\n<p><strong>Postal Address</strong><br />\r\nPO Box 16122 Collins Street West<br />\r\nVictoria 8007 Australia<br />\r\n121 King Street, Melbourne<br />\r\nVictoria 3000 Australia &ndash;&nbsp;<a href=\"https://www.google.com.au/maps/place/Envato/@-37.8173306,144.9534631,17z/data=!3m1!4b1!4m2!3m1!1s0x6ad65d4c2b349649:0xb6899234e561db11\" target=\"_blank\">Map</a></p>\r\n\r\n<p><br />\r\nYou can view the circular details online at:<br />\r\n<big><strong><a href=\"{LINK}\">View Job Circular</a></strong></big><br />\r\n<br />\r\nBest Regards,<br />\r\nThe&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (65, 'en', 'ticket_reopened_email', 'Ticket [SUBJECT] reopened', '<p>Ticket re-opened</p>\r\n\r\n<p>Hi {RECIPIENT},</p>\r\n\r\n<p>Ticket&nbsp;<strong>{SUBJECT}</strong>&nbsp;was re-opened by&nbsp;<strong>{USER}</strong>.<br />\r\nStatus :&nbsp;Open<br />\r\nClick on the below link to see the ticket details and post replies:&nbsp;<br />\r\n<a href=\"{TICKET_LINK}\"><strong>View Ticket</strong></a><br />\r\n<br />\r\n<br />\r\nBest Regards,<br />\r\n{SITE_NAME}</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (66, 'en', 'deposit_email', 'A deposit have been Received', '<p>Hi there,</p> <p>The&nbsp;<strong>{NAME}</strong>&nbsp;of deposit&nbsp;<strong>{AMOUNT}&nbsp;</strong>has been Deposit into <strong>{ACCOUNT}</strong> the new balance is <strong>{BALANCE}</strong></p> <p>You can view this deposit by logging in to the portal using the link below.<br /> <br /> <big><strong><a href=\"{URL}\">View Deposit</a></strong></big><br /> <br /> <br /> Regards,<br /> <br /> The&nbsp;<strong>{SITE_NAME}</strong>&nbsp;Team</p>');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (67, 'en', 'clock_in_email', 'The {NAME} Just clock in', '<p>Hi there,</p>\r\n\r\n<p>TheÃ‚Â <strong>{NAME}</strong> justÃ‚Â Clock In by using The IP. The IP is:Ã‚Â <strong>{IP}</strong> and the time is: Ã‚Â <strong>{TIME}</strong><strong> </strong></p>\r\n\r\n<p>You can view this attendance by logging in to the portal using the link below.<br>\r\n<br>\r\n<big><strong><a href=\"{URL}\">View Details</a></strong></big><br>\r\n<br>\r\n<br>\r\nRegards,<br>\r\n<br>\r\nTheÃ‚Â <strong>{SITE_NAME}</strong>Ã‚Â Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (68, 'en', 'trying_clock_email', 'The {NAME} Trying to clock', '<p>Hi there,</p>\r\n\r\n<p>TheÃ‚Â <strong>{NAME} </strong> Trying to clockÃ‚Â in by Unknown IP.The IP is: <strong>{IP}</strong> and the time is: <strong>{TIME}</strong></p>\r\n\r\n<p>You can view this IP by logging in to the portal using the link below.<br>\r\n<br>\r\n<big><strong><a href=\"{URL}\">View Details</a></strong></big><br>\r\n<br>\r\n<br>\r\nRegards,<br>\r\n<br>\r\nTheÃ‚Â <strong>{SITE_NAME}</strong>Ã‚Â Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (69, 'en', 'clock_out_email', 'The {NAME} Just clock Out', '<p>Hi there,</p>\r\n\r\n<p>TheÃ‚Â <strong>{NAME}</strong>Ã‚Â justÃ‚Â Clock Out by using The IP. The IP is:Ã‚Â <strong>{IP}</strong>Ã‚Â and the time is: Ã‚Â <strong>{TIME}</strong></p>\r\n\r\n<p>You can view this attendance by logging in to the portal using the link below.<br>\r\n<br>\r\n<big><strong><a href=\"{URL}\">View Details</a></strong></big><br>\r\n<br>\r\n<br>\r\nRegards,<br>\r\n<br>\r\nTheÃ‚Â <strong>{SITE_NAME}</strong>Ã‚Â Team</p>\r\n');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (70, 'en', 'invoice_item_refund_request', 'A new Refunded request recived for Invoice {REF}', '<p><strong>Hello </strong><br> <br> A new item refunded request received for Invoice {REF}.<br> <br> You can view the invoice online at:<br> <big><strong><a href=\"{LINK}\">View Refund Stock </a></strong></big><br> <br> Best Regards<br> <br> The {SITE_NAME} Team</p> ');
INSERT INTO `tbl_email_templates` (`email_templates_id`, `code`, `email_group`, `subject`, `template_body`) VALUES (71, 'en', 'credit_note_email', 'New Credit Note', '<p>Credit Note {credit_note_REF}</p> <p>Hi {CLIENT}</p> <p>Thanks for your business inquiry.</p> <p>The Credit Note {credit_note_REF} is attached with this email.<br /> Credit Note Overview:<br /> Credit Note # : {credit_note_REF}<br /> Amount: {CURRENCY} {AMOUNT}<br /> <br /> You can view the Credit Note online at:<br /> <big><strong><a href=\"{credit_note_LINK}\">View Credit Note</a></strong></big><br /> <br /> Best Regards,<br /> The {SITE_NAME} Team</p> ');


#
# TABLE STRUCTURE FOR: tbl_employee_award
#

DROP TABLE IF EXISTS `tbl_employee_award`;

CREATE TABLE `tbl_employee_award` (
  `employee_award_id` int NOT NULL AUTO_INCREMENT,
  `award_name` varchar(100) NOT NULL,
  `user_id` int DEFAULT NULL,
  `gift_item` varchar(300) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `award_amount` int DEFAULT NULL,
  `award_date` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `view_status` tinyint(1) DEFAULT '2' COMMENT '1=Read 2=Unread',
  `given_date` date DEFAULT NULL,
  PRIMARY KEY (`employee_award_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_employee_bank
#

DROP TABLE IF EXISTS `tbl_employee_bank`;

CREATE TABLE `tbl_employee_bank` (
  `employee_bank_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `bank_name` varchar(300) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `account_name` varchar(300) NOT NULL,
  `account_number` varchar(300) NOT NULL,
  `routing_number` varchar(50) DEFAULT NULL,
  `type_of_account` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`employee_bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (1, 6, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915013563211106', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (2, 8, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211108', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (3, 9, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915018003211109', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (4, 10, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012883211110', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (5, 12, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211111', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (6, 13, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211112', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (7, 14, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211113', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (8, 15, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211114', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (9, 16, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211115', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (10, 17, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211116', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (11, 18, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211117', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (12, 19, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211118', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (13, 20, 'RAK BANK', '', 'SALARY ACCOUNT', '0000915012313211119', '804020101', NULL);
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (14, 25, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012312159982', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (15, 26, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012312159990', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (16, 23, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012312160021', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (17, 24, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562160025', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (18, 75, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562276183', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (19, 29, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945018002276184', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (20, 30, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945014042276185', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (21, 31, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882276186', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (22, 32, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012312276188', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (23, 33, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562276189', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (24, 34, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882276190', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (25, 36, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882276192', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (26, 38, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882349789', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (27, 39, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562349870', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (28, 40, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562349872', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (29, 43, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882349875', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (30, 41, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882378617', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (31, 42, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882378622', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (32, 47, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882378809', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (33, 46, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882378812', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (34, 66, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882708196', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (35, 67, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882708273', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (36, 68, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882708275', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (37, 69, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562708203', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (38, 70, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882708286', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (39, 71, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945623562629071', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (40, 72, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945622882629058', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (41, 73, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945622882629030', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (42, 74, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945622882629024', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (43, 62, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945622882629008', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (44, 61, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945622882628983', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (45, 60, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882494508', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (46, 59, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882494505', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (47, 35, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562448721', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (48, 37, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882448723', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (49, 44, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882378816', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (50, 45, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882448724', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (51, 48, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945011082424381', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (52, 49, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945011082424392', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (53, 50, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945018002424402', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (54, 51, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882424438', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (55, 52, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945018002448727', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (56, 53, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945011082424455', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (57, 54, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882494490', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (58, 55, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882494492', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (59, 56, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945012882494500', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (60, 57, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562494501', '804020101', 'savings');
INSERT INTO `tbl_employee_bank` (`employee_bank_id`, `user_id`, `bank_name`, `branch_name`, `account_name`, `account_number`, `routing_number`, `type_of_account`) VALUES (61, 58, 'RAK BANK', '', 'SALARY ACCOUNT', '0000945013562494503', '804020101', 'savings');


#
# TABLE STRUCTURE FOR: tbl_employee_document
#

DROP TABLE IF EXISTS `tbl_employee_document`;

CREATE TABLE `tbl_employee_document` (
  `document_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `resume` text,
  `resume_path` text,
  `resume_filename` text,
  `offer_letter` text,
  `offer_letter_filename` text,
  `offer_letter_path` text,
  `joining_letter` text,
  `joining_letter_filename` text,
  `joining_letter_path` text,
  `contract_paper` text,
  `contract_paper_filename` text,
  `contract_paper_path` text,
  `id_proff` text,
  `id_proff_filename` text,
  `id_proff_path` text,
  `other_document` text,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (1, 17, NULL, NULL, NULL, 'uploads/ADISU_TESHOME_mb_contract.pdf', 'ADISU_TESHOME_mb_contract.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ADISU_TESHOME_mb_contract.pdf', 'uploads/ADISU_TESHOME_st_contract.pdf', 'ADISU_TESHOME_st_contract.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ADISU_TESHOME_st_contract.pdf', 'uploads/ADISU_TESHOME_evisa.pdf', 'ADISU_TESHOME_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ADISU_TESHOME_evisa.pdf', 'uploads/EMIRATES_ADISU.pdf', 'EMIRATES_ADISU.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ADISU.pdf', '[{\"fileName\":\"eResidency_ADISU_TESHOME.pdf\",\"path\":\"uploads\\/eResidency_ADISU_TESHOME.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/eResidency_ADISU_TESHOME.pdf\",\"ext\":\".pdf\",\"size\":1326.13,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (2, 18, NULL, NULL, NULL, 'uploads/EFREM_ZEMACHU_MB_CONTRACT.pdf', 'EFREM_ZEMACHU_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EFREM_ZEMACHU_MB_CONTRACT.pdf', 'uploads/EFREM_ZEMACHU_ST_CONTRACT.pdf', 'EFREM_ZEMACHU_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EFREM_ZEMACHU_ST_CONTRACT.pdf', 'uploads/EFREM_ZEMACHU_e_visa.pdf', 'EFREM_ZEMACHU_e_visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EFREM_ZEMACHU_e_visa.pdf', NULL, NULL, NULL, '[{\"fileName\":\"EFREM_LABOUR_CARD.jpeg\",\"path\":\"uploads\\/EFREM_LABOUR_CARD.jpeg\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EFREM_LABOUR_CARD.jpeg\",\"ext\":\".jpeg\",\"size\":115.92,\"is_image\":true,\"image_width\":945,\"image_height\":591}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (3, 19, NULL, NULL, NULL, 'uploads/AJAIB_HAMDA_MB_CONTRACT.pdf', 'AJAIB_HAMDA_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AJAIB_HAMDA_MB_CONTRACT.pdf', 'uploads/AJAIB_HAMDA_ST_CONTRACT.pdf', 'AJAIB_HAMDA_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AJAIB_HAMDA_ST_CONTRACT.pdf', 'uploads/AJAIB_HAMDA_GENEMO_-_Evisa.pdf', 'AJAIB_HAMDA_GENEMO_-_Evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AJAIB_HAMDA_GENEMO_-_Evisa.pdf', 'uploads/EMIRATES_AJAIB.pdf', 'EMIRATES_AJAIB.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_AJAIB.pdf', '[{\"fileName\":\"eResidency_AJAIB_HAMDA.pdf\",\"path\":\"uploads\\/eResidency_AJAIB_HAMDA.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/eResidency_AJAIB_HAMDA.pdf\",\"ext\":\".pdf\",\"size\":1323.23,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (4, 20, NULL, NULL, NULL, 'uploads/ABDULJEBAR_AMANO_Mb_contract.pdf', 'ABDULJEBAR_AMANO_Mb_contract.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ABDULJEBAR_AMANO_Mb_contract.pdf', 'uploads/ABDULJEBAR_AMANO_st_contract.pdf', 'ABDULJEBAR_AMANO_st_contract.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ABDULJEBAR_AMANO_st_contract.pdf', 'uploads/ABDULJEBAR_AMANO_evisa.pdf', 'ABDULJEBAR_AMANO_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ABDULJEBAR_AMANO_evisa.pdf', 'uploads/EMIRATES_ABDULJEBAR_AMANO_DELCHA.pdf', 'EMIRATES_ABDULJEBAR_AMANO_DELCHA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ABDULJEBAR_AMANO_DELCHA.pdf', '[{\"fileName\":\"eResidency_ABDULJEBAR_page-0001.jpg\",\"path\":\"uploads\\/eResidency_ABDULJEBAR_page-0001.jpg\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/eResidency_ABDULJEBAR_page-0001.jpg\",\"ext\":\".jpg\",\"size\":2152.79,\"is_image\":true,\"image_width\":2480,\"image_height\":3509}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (5, 23, NULL, NULL, NULL, 'uploads/HAJI_HUSEN_KUSU_MB_CONTRACT.pdf', 'HAJI_HUSEN_KUSU_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/HAJI_HUSEN_KUSU_MB_CONTRACT.pdf', 'uploads/HAJI_HUSEN_KUSU_ST_CONTRACT.pdf', 'HAJI_HUSEN_KUSU_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/HAJI_HUSEN_KUSU_ST_CONTRACT.pdf', 'uploads/HAJI_HUSEN_KUSU_Evisa.pdf', 'HAJI_HUSEN_KUSU_Evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/HAJI_HUSEN_KUSU_Evisa.pdf', 'uploads/EMIRATES_HAJI_HUSEN.pdf', 'EMIRATES_HAJI_HUSEN.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_HAJI_HUSEN.pdf', '[{\"fileName\":\"EResidenceHAJI_HUSEN.pdf\",\"path\":\"uploads\\/EResidenceHAJI_HUSEN.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidenceHAJI_HUSEN.pdf\",\"ext\":\".pdf\",\"size\":1348.66,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (6, 24, NULL, NULL, NULL, 'uploads/JAINULABUDEEN_MB_CONTRACT.pdf', 'JAINULABUDEEN_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JAINULABUDEEN_MB_CONTRACT.pdf', 'uploads/JAINULABUDEEN_Medical.pdf', 'JAINULABUDEEN_Medical.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JAINULABUDEEN_Medical.pdf', 'uploads/JAINULABUDEEN_evisa.pdf', 'JAINULABUDEEN_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JAINULABUDEEN_evisa.pdf', 'uploads/EMIRATES_JAINULABUDEEN_AHIYA.pdf', 'EMIRATES_JAINULABUDEEN_AHIYA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_JAINULABUDEEN_AHIYA.pdf', '[{\"fileName\":\"EResidenceJAINULABUDEEN.pdf\",\"path\":\"uploads\\/EResidenceJAINULABUDEEN.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidenceJAINULABUDEEN.pdf\",\"ext\":\".pdf\",\"size\":1313.11,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (7, 25, NULL, NULL, NULL, 'uploads/MURTEDA_MUKTAR_MB_CONTRACT.pdf', 'MURTEDA_MUKTAR_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/MURTEDA_MUKTAR_MB_CONTRACT.pdf', 'uploads/MURTEDA_MUKTAR_MB_CONTRACT.pdf', 'MURTEDA_MUKTAR_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/MURTEDA_MUKTAR_MB_CONTRACT.pdf', 'uploads/MURTEDA_MUKTAR_evisa.pdf', 'MURTEDA_MUKTAR_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/MURTEDA_MUKTAR_evisa.pdf', 'uploads/EMIRATES_ID.pdf', 'EMIRATES_ID.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID.pdf', '[{\"fileName\":\"MURTEDA_MUKTAR_EResidence.pdf\",\"path\":\"uploads\\/MURTEDA_MUKTAR_EResidence.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/MURTEDA_MUKTAR_EResidence.pdf\",\"ext\":\".pdf\",\"size\":1315.44,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (8, 26, NULL, NULL, NULL, 'uploads/GUTAMA_LENCHO_MB_CONTRACT.pdf', 'GUTAMA_LENCHO_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/GUTAMA_LENCHO_MB_CONTRACT.pdf', 'uploads/GUTAMA_LENCHO_MEDICAL.pdf', 'GUTAMA_LENCHO_MEDICAL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/GUTAMA_LENCHO_MEDICAL.pdf', 'uploads/GUTAMA_LENCHO_evisa.pdf', 'GUTAMA_LENCHO_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/GUTAMA_LENCHO_evisa.pdf', 'uploads/EMIRATES_ID.pdf', 'EMIRATES_ID.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID.pdf', '[{\"fileName\":\"GUTAMA_LENCHO_EResidence.pdf\",\"path\":\"uploads\\/GUTAMA_LENCHO_EResidence.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/GUTAMA_LENCHO_EResidence.pdf\",\"ext\":\".pdf\",\"size\":1316.77,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (9, 6, NULL, NULL, NULL, 'uploads/KARTHIK_MB_CONTRACT.pdf', 'KARTHIK_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIK_MB_CONTRACT.pdf', 'uploads/KARTHIK_ST_CONTRACT.pdf', 'KARTHIK_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIK_ST_CONTRACT.pdf', 'uploads/KARTHIK_VENKATAPATHY_evisa.pdf', 'KARTHIK_VENKATAPATHY_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIK_VENKATAPATHY_evisa.pdf', 'uploads/KARTHIK_EMIRATES_ID.pdf', 'KARTHIK_EMIRATES_ID.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIK_EMIRATES_ID.pdf', '[{\"fileName\":\"ESTAMPING_KARTHIK_VENKATAPATHY.pdf\",\"path\":\"uploads\\/ESTAMPING_KARTHIK_VENKATAPATHY.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/ESTAMPING_KARTHIK_VENKATAPATHY.pdf\",\"ext\":\".pdf\",\"size\":1346.65,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (10, 8, NULL, NULL, NULL, 'uploads/MOL.pdf', 'MOL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/MOL.pdf', 'uploads/EQ2232998_VISA.pdf', 'EQ2232998_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EQ2232998_VISA.pdf', 'uploads/EQ2232998_VISA.pdf', 'EQ2232998_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EQ2232998_VISA.pdf', 'uploads/YAHYA_EMIRATES.pdf', 'YAHYA_EMIRATES.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/YAHYA_EMIRATES.pdf', '[{\"fileName\":\"EResidence_YAHYA_MUZEMIL.pdf\",\"path\":\"uploads\\/EResidence_YAHYA_MUZEMIL.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidence_YAHYA_MUZEMIL.pdf\",\"ext\":\".pdf\",\"size\":1335.79,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (11, 9, NULL, NULL, NULL, 'uploads/3.pdf', '3.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/3.pdf', 'uploads/Signed_MOL.pdf', 'Signed_MOL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/Signed_MOL.pdf', 'uploads/VISA_-_JOEL.pdf', 'VISA_-_JOEL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/VISA_-_JOEL.pdf', 'uploads/EMIRATES_JOEL.pdf', 'EMIRATES_JOEL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_JOEL.pdf', '[{\"fileName\":\"EResidence20120252640615.pdf\",\"path\":\"uploads\\/EResidence20120252640615.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidence20120252640615.pdf\",\"ext\":\".pdf\",\"size\":1306.6,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (12, 10, NULL, NULL, NULL, 'uploads/MOL.pdf', 'MOL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/MOL.pdf', 'uploads/ERIC_VISA.pdf', 'ERIC_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ERIC_VISA.pdf', 'uploads/ERIC_VISA.pdf', 'ERIC_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ERIC_VISA.pdf', 'uploads/EMIRATES_ERIC.pdf', 'EMIRATES_ERIC.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ERIC.pdf', '[{\"fileName\":\"EResidenceERIC_AIDOO.pdf\",\"path\":\"uploads\\/EResidenceERIC_AIDOO.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidenceERIC_AIDOO.pdf\",\"ext\":\".pdf\",\"size\":1344.99,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (13, 12, NULL, NULL, NULL, 'uploads/AYASH_JEMAL_MB_CONTRACT.pdf', 'AYASH_JEMAL_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AYASH_JEMAL_MB_CONTRACT.pdf', 'uploads/AYASH_JAMAL_e_visa.pdf', 'AYASH_JAMAL_e_visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AYASH_JAMAL_e_visa.pdf', 'uploads/AYASH_JAMAL_e_visa.pdf', 'AYASH_JAMAL_e_visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AYASH_JAMAL_e_visa.pdf', 'uploads/EMIRATES_AYASH.pdf', 'EMIRATES_AYASH.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_AYASH.pdf', '[{\"fileName\":\"EResidenceAYASH_JEMAL.pdf\",\"path\":\"uploads\\/EResidenceAYASH_JEMAL.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidenceAYASH_JEMAL.pdf\",\"ext\":\".pdf\",\"size\":1321.21,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (14, 13, NULL, NULL, NULL, 'uploads/ABDURAHMAN_SHUKARI_MB_CONTRACT.pdf', 'ABDURAHMAN_SHUKARI_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ABDURAHMAN_SHUKARI_MB_CONTRACT.pdf', 'uploads/ABDURAHMAN_TICKET.pdf', 'ABDURAHMAN_TICKET.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ABDURAHMAN_TICKET.pdf', 'uploads/ABDURAHMAN_evisa.pdf', 'ABDURAHMAN_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ABDURAHMAN_evisa.pdf', 'uploads/EMIRATES_ABDURAHMAN.pdf', 'EMIRATES_ABDURAHMAN.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ABDURAHMAN.pdf', '[{\"fileName\":\"EResidenceABDURAHMAN_SHUKARI.pdf\",\"path\":\"uploads\\/EResidenceABDURAHMAN_SHUKARI.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidenceABDURAHMAN_SHUKARI.pdf\",\"ext\":\".pdf\",\"size\":1338.25,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (15, 14, NULL, NULL, NULL, 'uploads/JEMAL_HASSEN_MB_CONTRACT.pdf', 'JEMAL_HASSEN_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JEMAL_HASSEN_MB_CONTRACT.pdf', 'uploads/JEMAL_HASSEN_ST_CONTRACT.pdf', 'JEMAL_HASSEN_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JEMAL_HASSEN_ST_CONTRACT.pdf', 'uploads/__JEMAL_HASSEN_evisa.pdf', '__JEMAL_HASSEN_evisa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/__JEMAL_HASSEN_evisa.pdf', 'uploads/EMIRATES_JEMAL.pdf', 'EMIRATES_JEMAL.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_JEMAL.pdf', '[{\"fileName\":\"eResidency_JEMAL_HASSEN.pdf\",\"path\":\"uploads\\/eResidency_JEMAL_HASSEN.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/eResidency_JEMAL_HASSEN.pdf\",\"ext\":\".pdf\",\"size\":1317.72,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (16, 15, 'uploads/UMER_HUSSEN_FILE.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/UMER_HUSSEN_FILE.pdf', 'UMER_HUSSEN_FILE.pdf', 'uploads/UMER_HUSSEN_ST_CONTRACT.pdf', 'UMER_HUSSEN_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/UMER_HUSSEN_ST_CONTRACT.pdf', 'uploads/UMER_HUSSEN_MB_CONTRACT.pdf', 'UMER_HUSSEN_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/UMER_HUSSEN_MB_CONTRACT.pdf', NULL, NULL, NULL, 'uploads/PP.jpg', 'PP.jpg', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PP.jpg', '[{\"fileName\":\"EMIRATES_UMER.pdf\",\"path\":\"uploads\\/EMIRATES_UMER.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_UMER.pdf\",\"ext\":\".pdf\",\"size\":186.11,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (17, 16, 'uploads/DIRIBA_GOSA_FILE.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/DIRIBA_GOSA_FILE.pdf', 'DIRIBA_GOSA_FILE.pdf', 'uploads/DIRIBA_GOSA_MB_CONTRACT.pdf', 'DIRIBA_GOSA_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/DIRIBA_GOSA_MB_CONTRACT.pdf', 'uploads/DIRIBA_GOSA_ST_CONTRACT.pdf', 'DIRIBA_GOSA_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/DIRIBA_GOSA_ST_CONTRACT.pdf', 'uploads/DIRIBA_GOSA_MB_CONTRACT.pdf', 'DIRIBA_GOSA_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/DIRIBA_GOSA_MB_CONTRACT.pdf', 'uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102182041712025523364321.pdf', 'EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102182041712025523364321.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102182041712025523364321.pdf', '[{\"fileName\":\"PP.jpg\",\"path\":\"uploads\\/PP.jpg\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/PP.jpg\",\"ext\":\".jpg\",\"size\":208.85,\"is_image\":true,\"image_width\":909,\"image_height\":1280}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (18, 75, 'uploads/PASSPORT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PASSPORT.pdf', 'PASSPORT.pdf', 'uploads/AFZAL_BABU_MB_CONTRACT.pdf', 'AFZAL_BABU_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AFZAL_BABU_MB_CONTRACT.pdf', 'uploads/AFZAL_BABU_ST_CONTRACT.pdf', 'AFZAL_BABU_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AFZAL_BABU_ST_CONTRACT.pdf', 'uploads/AFZAL_BABU_VISA.pdf', 'AFZAL_BABU_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AFZAL_BABU_VISA.pdf', 'uploads/AFZAL_BABU_VISA.pdf', 'AFZAL_BABU_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AFZAL_BABU_VISA.pdf', '[{\"fileName\":\"EResidence20220252268817.pdf\",\"path\":\"uploads\\/EResidence20220252268817.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EResidence20220252268817.pdf\",\"ext\":\".pdf\",\"size\":1318.21,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (19, 29, 'uploads/VISA_ANANIOUS_RONNY_BYAMAZIMA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/VISA_ANANIOUS_RONNY_BYAMAZIMA.pdf', 'VISA_ANANIOUS_RONNY_BYAMAZIMA.pdf', 'uploads/ANANIOUS_RONNY_MB_CONTRACT.pdf', 'ANANIOUS_RONNY_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ANANIOUS_RONNY_MB_CONTRACT.pdf', 'uploads/ANANIOUS_RONNY_ST_CONTRACT.pdf', 'ANANIOUS_RONNY_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ANANIOUS_RONNY_ST_CONTRACT.pdf', 'uploads/ANANIOUS_RONNY_ST_CONTRACT.pdf', 'ANANIOUS_RONNY_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ANANIOUS_RONNY_ST_CONTRACT.pdf', 'uploads/EResidence_ANANIOUS.pdf', 'EResidence_ANANIOUS.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EResidence_ANANIOUS.pdf', '[{\"fileName\":\"VISA_ANANIOUS_RONNY_BYAMAZIMA.pdf\",\"path\":\"uploads\\/VISA_ANANIOUS_RONNY_BYAMAZIMA.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/VISA_ANANIOUS_RONNY_BYAMAZIMA.pdf\",\"ext\":\".pdf\",\"size\":593.3,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (20, 30, 'uploads/JOSEPH_GAKURU_FILE.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JOSEPH_GAKURU_FILE.pdf', 'JOSEPH_GAKURU_FILE.pdf', 'uploads/JOSEPH_GAKURU_MB_CONTRACT.pdf', 'JOSEPH_GAKURU_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JOSEPH_GAKURU_MB_CONTRACT.pdf', 'uploads/JOSEPH_GAKURU_ST_CONTRACT.pdf', 'JOSEPH_GAKURU_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JOSEPH_GAKURU_ST_CONTRACT.pdf', 'uploads/JOSEPH_GAKURU_MB_CONTRACT.pdf', 'JOSEPH_GAKURU_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/JOSEPH_GAKURU_MB_CONTRACT.pdf', 'uploads/Joseph_Gakuru_Emirates_ID_.pdf', 'Joseph_Gakuru_Emirates_ID_.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/Joseph_Gakuru_Emirates_ID_.pdf', '[{\"fileName\":\"JOSEPH_GAKURU_GITONGA_DOCUMENTS.pdf\",\"path\":\"uploads\\/JOSEPH_GAKURU_GITONGA_DOCUMENTS.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/JOSEPH_GAKURU_GITONGA_DOCUMENTS.pdf\",\"ext\":\".pdf\",\"size\":4595.07,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (21, 31, 'uploads/SOLOMON_GANDAA_FILE_-_WELDER.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/SOLOMON_GANDAA_FILE_-_WELDER.pdf', 'SOLOMON_GANDAA_FILE_-_WELDER.pdf', 'uploads/SOLOMON_GANDAA_ST_CONTRACT.pdf', 'SOLOMON_GANDAA_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/SOLOMON_GANDAA_ST_CONTRACT.pdf', 'uploads/SOLOMON_GANDAA_ST_CONTRACT.pdf', 'SOLOMON_GANDAA_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/SOLOMON_GANDAA_ST_CONTRACT.pdf', 'uploads/SOLOMON_GANDAA_ST_CONTRACT.pdf', 'SOLOMON_GANDAA_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/SOLOMON_GANDAA_ST_CONTRACT.pdf', 'uploads/NEW_EMIRATES_ID_SERVICES_Solomon_Gandaa.pdf', 'NEW_EMIRATES_ID_SERVICES_Solomon_Gandaa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/NEW_EMIRATES_ID_SERVICES_Solomon_Gandaa.pdf', '[{\"fileName\":\"EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102400097412025530688241.pdf\",\"path\":\"uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102400097412025530688241.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102400097412025530688241.pdf\",\"ext\":\".pdf\",\"size\":878.29,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (22, 32, 'uploads/AWOL_SIRAJ_AHMED_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AWOL_SIRAJ_AHMED_VISA.pdf', 'AWOL_SIRAJ_AHMED_VISA.pdf', 'uploads/AWOL_SIRAJ_ST_CONTRACT.pdf', 'AWOL_SIRAJ_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AWOL_SIRAJ_ST_CONTRACT.pdf', 'uploads/AWOL_SIRAJ_AHMED_VISA.pdf', 'AWOL_SIRAJ_AHMED_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AWOL_SIRAJ_AHMED_VISA.pdf', 'uploads/AWOL_SIRAJ_MB_CONTRACT.pdf', 'AWOL_SIRAJ_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/AWOL_SIRAJ_MB_CONTRACT.pdf', 'uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102524177702025533685799.pdf', 'EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102524177702025533685799.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102524177702025533685799.pdf', '[{\"fileName\":\"eResidency_AWOL_SIRAJ.pdf\",\"path\":\"uploads\\/eResidency_AWOL_SIRAJ.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/eResidency_AWOL_SIRAJ.pdf\",\"ext\":\".pdf\",\"size\":1334.86,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (23, 33, 'uploads/CHINNAIYAN_MANIKKAM_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/CHINNAIYAN_MANIKKAM_VISA.pdf', 'CHINNAIYAN_MANIKKAM_VISA.pdf', 'uploads/CHINNAIYAN_MANIKKAM_ST_CONTRACT.pdf', 'CHINNAIYAN_MANIKKAM_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/CHINNAIYAN_MANIKKAM_ST_CONTRACT.pdf', 'uploads/CHINNAIYAN_MANIKKAM_MB_CONTRACT.pdf', 'CHINNAIYAN_MANIKKAM_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/CHINNAIYAN_MANIKKAM_MB_CONTRACT.pdf', 'uploads/CHINNAIYAN_MANIKKAM_ST_CONTRACT.pdf', 'CHINNAIYAN_MANIKKAM_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/CHINNAIYAN_MANIKKAM_ST_CONTRACT.pdf', 'uploads/Chinnaiyan_Emirates_ID.pdf', 'Chinnaiyan_Emirates_ID.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/Chinnaiyan_Emirates_ID.pdf', '[{\"fileName\":\"EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102621359552025535368606.pdf\",\"path\":\"uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102621359552025535368606.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102621359552025535368606.pdf\",\"ext\":\".pdf\",\"size\":886.97,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (24, 34, 'uploads/ISAAC_HAYFORD_FILE.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_HAYFORD_FILE.pdf', 'ISAAC_HAYFORD_FILE.pdf', 'uploads/ISAAC_HAYFORD_MB_CONTRACT.pdf', 'ISAAC_HAYFORD_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_HAYFORD_MB_CONTRACT.pdf', 'uploads/ISAAC_HAYFORD_ST_CONTRACT.pdf', 'ISAAC_HAYFORD_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_HAYFORD_ST_CONTRACT.pdf', 'uploads/ISAAC_HAYFORD_ST_CONTRACT.pdf', 'ISAAC_HAYFORD_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_HAYFORD_ST_CONTRACT.pdf', 'uploads/eResidency_ISSAC_HAYFORD.pdf', 'eResidency_ISSAC_HAYFORD.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/eResidency_ISSAC_HAYFORD.pdf', '[{\"fileName\":\"EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102911113252025533686827.pdf\",\"path\":\"uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102911113252025533686827.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102911113252025533686827.pdf\",\"ext\":\".pdf\",\"size\":872.38,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (25, 36, 'uploads/OFFER_LETTER_RICHMOND_OFORI.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/OFFER_LETTER_RICHMOND_OFORI.pdf', 'OFFER_LETTER_RICHMOND_OFORI.pdf', 'uploads/OFFER_LETTER_RICHMOND_OFORI.pdf', 'OFFER_LETTER_RICHMOND_OFORI.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/OFFER_LETTER_RICHMOND_OFORI.pdf', 'uploads/RICHMOND_OFORI_MB_CONTRACT.pdf', 'RICHMOND_OFORI_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/RICHMOND_OFORI_MB_CONTRACT.pdf', 'uploads/RICHMOND_OFORI_ST_CONTRACT.pdf', 'RICHMOND_OFORI_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/RICHMOND_OFORI_ST_CONTRACT.pdf', 'uploads/EResidence20220252725143.pdf', 'EResidence20220252725143.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EResidence20220252725143.pdf', '[{\"fileName\":\"EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102470642352025545186785.pdf\",\"path\":\"uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102470642352025545186785.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102470642352025545186785.pdf\",\"ext\":\".pdf\",\"size\":878.48,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (26, 38, 'uploads/PRINCE_OSEI_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PRINCE_OSEI_VISA.pdf', 'PRINCE_OSEI_VISA.pdf', 'uploads/PRINCE_OSEI_ST_CONTRACT.pdf', 'PRINCE_OSEI_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PRINCE_OSEI_ST_CONTRACT.pdf', 'uploads/PRINCE_OSEI_MB_CONTRACT.pdf', 'PRINCE_OSEI_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PRINCE_OSEI_MB_CONTRACT.pdf', 'uploads/PRINCE_OSEI_MB_CONTRACT.pdf', 'PRINCE_OSEI_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PRINCE_OSEI_MB_CONTRACT.pdf', 'uploads/PRINCE_OSEI_EResidence.pdf', 'PRINCE_OSEI_EResidence.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PRINCE_OSEI_EResidence.pdf', '[{\"fileName\":\"EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102500922852025536966320.pdf\",\"path\":\"uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102500922852025536966320.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102500922852025536966320.pdf\",\"ext\":\".pdf\",\"size\":877.73,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (27, 39, 'uploads/KARTHIKEYAN_SELVARAJ_-_STEEL_FIXER.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIKEYAN_SELVARAJ_-_STEEL_FIXER.pdf', 'KARTHIKEYAN_SELVARAJ_-_STEEL_FIXER.pdf', 'uploads/KARTHIKEYAN_SELVARAJ_ST_CONTRACT.pdf', 'KARTHIKEYAN_SELVARAJ_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIKEYAN_SELVARAJ_ST_CONTRACT.pdf', 'uploads/KARTHIKEYAN_SELVARAJ_MB_CONTRACT.pdf', 'KARTHIKEYAN_SELVARAJ_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIKEYAN_SELVARAJ_MB_CONTRACT.pdf', 'uploads/KARTHIKEYAN_SELVARAJ_MB_CONTRACT.pdf', 'KARTHIKEYAN_SELVARAJ_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIKEYAN_SELVARAJ_MB_CONTRACT.pdf', 'uploads/KARTHIKEYAN_SELVARAJ_EID.pdf', 'KARTHIKEYAN_SELVARAJ_EID.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/KARTHIKEYAN_SELVARAJ_EID.pdf', '[{\"fileName\":\"EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102439935062025545186336.pdf\",\"path\":\"uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102439935062025545186336.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102439935062025545186336.pdf\",\"ext\":\".pdf\",\"size\":882.32,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (28, 40, 'uploads/PANJAVARNAM_THIRUMURUGAN_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/PANJAVARNAM_THIRUMURUGAN_VISA.pdf', 'PANJAVARNAM_THIRUMURUGAN_VISA.pdf', 'uploads/THIRUMURUGAN_ST_CONTRACT.pdf', 'THIRUMURUGAN_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/THIRUMURUGAN_ST_CONTRACT.pdf', 'uploads/THIRUMURUGAN_MB_CONTRACT.pdf', 'THIRUMURUGAN_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/THIRUMURUGAN_MB_CONTRACT.pdf', 'uploads/THIRUMURUGAN_MB_CONTRACT.pdf', 'THIRUMURUGAN_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/THIRUMURUGAN_MB_CONTRACT.pdf', 'uploads/EResidence20220252841539.pdf', 'EResidence20220252841539.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EResidence20220252841539.pdf', '[{\"fileName\":\"THIRUMURUGAN_PANJAVARNAM_-_MASON.pdf\",\"path\":\"uploads\\/THIRUMURUGAN_PANJAVARNAM_-_MASON.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/THIRUMURUGAN_PANJAVARNAM_-_MASON.pdf\",\"ext\":\".pdf\",\"size\":3371.95,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (29, 43, 'uploads/ISAAC_OPOKU_-_HELPER.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_OPOKU_-_HELPER.pdf', 'ISAAC_OPOKU_-_HELPER.pdf', 'uploads/ISAAC_OPOKU_MB_ST.pdf', 'ISAAC_OPOKU_MB_ST.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_OPOKU_MB_ST.pdf', 'uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102188698402025545192610.pdf', 'EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102188698402025545192610.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102188698402025545192610.pdf', 'uploads/ISAAC_OPOKU_MB_ST.pdf', 'ISAAC_OPOKU_MB_ST.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ISAAC_OPOKU_MB_ST.pdf', 'uploads/EResidence_ISAAC_OPOKU.pdf', 'EResidence_ISAAC_OPOKU.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EResidence_ISAAC_OPOKU.pdf', '[{\"fileName\":\"ISSAC_OPOKU_VISA.pdf\",\"path\":\"uploads\\/ISSAC_OPOKU_VISA.pdf\",\"fullPath\":\"\\/home\\/samandth\\/public_html\\/hayatjadidagroups.com\\/erp\\/uploads\\/ISSAC_OPOKU_VISA.pdf\",\"ext\":\".pdf\",\"size\":607.2,\"is_image\":false,\"image_width\":\"\",\"image_height\":\"\"}]');
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (30, 41, 'uploads/FRANK_OSEI_-e_Residance_Visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/FRANK_OSEI_-e_Residance_Visa.pdf', 'FRANK_OSEI_-e_Residance_Visa.pdf', 'uploads/FRANK_OSEI_-e_Residance_Visa.pdf', 'FRANK_OSEI_-e_Residance_Visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/FRANK_OSEI_-e_Residance_Visa.pdf', 'uploads/OFF_CONTRACT_FRANK_OSEI.pdf', 'OFF_CONTRACT_FRANK_OSEI.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/OFF_CONTRACT_FRANK_OSEI.pdf', 'uploads/ST_FRANK_OSEI.pdf', 'ST_FRANK_OSEI.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ST_FRANK_OSEI.pdf', 'uploads/FRANK_OSEI_-e_Residance_Visa.pdf', 'FRANK_OSEI_-e_Residance_Visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/FRANK_OSEI_-e_Residance_Visa.pdf', NULL);
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (31, 42, 'uploads/EMMANUEL_ACKAH_EID.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_EID.pdf', 'EMMANUEL_ACKAH_EID.pdf', 'uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'EMMANUEL_ACKAH_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'EMMANUEL_ACKAH_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'EMMANUEL_ACKAH_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'uploads/EMMANUEL_ACKAH_VISA.pdf', 'EMMANUEL_ACKAH_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_VISA.pdf', NULL);
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (32, 47, 'uploads/EMMANUEL_ACKAH_VISA.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_VISA.pdf', 'EMMANUEL_ACKAH_VISA.pdf', 'uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'EMMANUEL_ACKAH_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'uploads/EResidence_EMMANUEL_ACKAH.pdf', 'EResidence_EMMANUEL_ACKAH.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EResidence_EMMANUEL_ACKAH.pdf', 'uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'EMMANUEL_ACKAH_MB_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMMANUEL_ACKAH_MB_CONTRACT.pdf', 'uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102179667022025545188578.pdf', 'EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102179667022025545188578.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102179667022025545188578.pdf', NULL);
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (33, 46, 'uploads/VISA_COLLINS_BOYE.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/VISA_COLLINS_BOYE.pdf', 'VISA_COLLINS_BOYE.pdf', 'uploads/COLLINS_BOYE_-e_Residance_Visa.pdf', 'COLLINS_BOYE_-e_Residance_Visa.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/COLLINS_BOYE_-e_Residance_Visa.pdf', 'uploads/COLLINS_BOYE_ST_CONTRACT.pdf', 'COLLINS_BOYE_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/COLLINS_BOYE_ST_CONTRACT.pdf', 'uploads/COLLINS_BOYE_ST_CONTRACT.pdf', 'COLLINS_BOYE_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/COLLINS_BOYE_ST_CONTRACT.pdf', 'uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102975353332025545188430.pdf', 'EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102975353332025545188430.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/EMIRATES_ID_SERVICES_-_EMIRATES_ID_FOR_RESIDENT_-_EMIRATES_ID_FOR_RESIDENT_-_ISSUE_NEW_EMIRATES_ID___0102975353332025545188430.pdf', NULL);
INSERT INTO `tbl_employee_document` (`document_id`, `user_id`, `resume`, `resume_path`, `resume_filename`, `offer_letter`, `offer_letter_filename`, `offer_letter_path`, `joining_letter`, `joining_letter_filename`, `joining_letter_path`, `contract_paper`, `contract_paper_filename`, `contract_paper_path`, `id_proff`, `id_proff_filename`, `id_proff_path`, `other_document`) VALUES (34, 66, 'uploads/ALEX_FILE.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ALEX_FILE.pdf', 'ALEX_FILE.pdf', 'uploads/ALEX_OPOKU_ST_CONTRACT.pdf', 'ALEX_OPOKU_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ALEX_OPOKU_ST_CONTRACT.pdf', 'uploads/ALEX_OPOKU_OFR_LTR_PAY.pdf', 'ALEX_OPOKU_OFR_LTR_PAY.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ALEX_OPOKU_OFR_LTR_PAY.pdf', 'uploads/ALEX_OPOKU_ST_CONTRACT.pdf', 'ALEX_OPOKU_ST_CONTRACT.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/ALEX_OPOKU_ST_CONTRACT.pdf', 'uploads/e_visa_ALEX_OPOKU.pdf', 'e_visa_ALEX_OPOKU.pdf', '/home/samandth/public_html/hayatjadidagroups.com/erp/uploads/e_visa_ALEX_OPOKU.pdf', NULL);


#
# TABLE STRUCTURE FOR: tbl_employee_payroll
#

DROP TABLE IF EXISTS `tbl_employee_payroll`;

CREATE TABLE `tbl_employee_payroll` (
  `payroll_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `salary_template_id` int DEFAULT NULL,
  `hourly_rate_id` int DEFAULT NULL,
  PRIMARY KEY (`payroll_id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (1, 45, 2, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (2, 32, 2, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (3, 33, 2, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (4, 51, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (5, 53, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (6, 54, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (7, 56, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (8, 42, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (9, 43, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (10, 46, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (11, 47, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (12, 48, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (13, 50, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (14, 55, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (15, 60, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (16, 8, 2, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (17, 30, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (18, 31, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (19, 41, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (20, 44, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (21, 49, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (22, 59, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (23, 34, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (24, 39, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (25, 58, 2, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (26, 57, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (27, 6, 3, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (28, 9, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (29, 10, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (30, 12, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (31, 13, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (32, 14, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (33, 15, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (34, 16, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (35, 17, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (36, 18, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (37, 19, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (38, 20, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (39, 23, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (40, 24, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (41, 25, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (42, 26, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (43, 35, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (44, 66, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (45, 70, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (46, 71, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (47, 72, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (48, 73, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (49, 74, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (50, 75, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (51, 29, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (52, 36, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (53, 37, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (54, 38, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (55, 40, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (56, 52, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (57, 61, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (58, 62, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (59, 64, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (60, 65, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (61, 67, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (62, 68, NULL, NULL);
INSERT INTO `tbl_employee_payroll` (`payroll_id`, `user_id`, `salary_template_id`, `hourly_rate_id`) VALUES (63, 69, NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_estimate_items
#

DROP TABLE IF EXISTS `tbl_estimate_items`;

CREATE TABLE `tbl_estimate_items` (
  `estimate_items_id` int NOT NULL AUTO_INCREMENT,
  `estimates_id` int NOT NULL,
  `saved_items_id` int DEFAULT '0',
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `item_tax_total` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unit` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `order` int DEFAULT '0',
  PRIMARY KEY (`estimate_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_estimates
#

DROP TABLE IF EXISTS `tbl_estimates`;

CREATE TABLE `tbl_estimates` (
  `estimates_id` int NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `project_id` int DEFAULT '0',
  `estimate_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `estimate_month` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `estimate_year` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `due_date` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `alert_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `currency` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `discount_percent` int DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `tax` int NOT NULL DEFAULT '0',
  `total_tax` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Pending',
  `date_sent` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `est_deleted` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emailed` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `show_client` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `invoiced` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `invoices_id` int NOT NULL DEFAULT '0',
  `warehouse_id` int DEFAULT NULL,
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `client_visible` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `discount_type` enum('none','before_tax','after_tax') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'none',
  `user_id` int NOT NULL DEFAULT '0' COMMENT 'sales agent',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `tags` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`estimates_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_expense_category
#

DROP TABLE IF EXISTS `tbl_expense_category`;

CREATE TABLE `tbl_expense_category` (
  `expense_category_id` int NOT NULL AUTO_INCREMENT,
  `expense_category` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`expense_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_files
#

DROP TABLE IF EXISTS `tbl_files`;

CREATE TABLE `tbl_files` (
  `files_id` int NOT NULL AUTO_INCREMENT,
  `project_id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `uploaded_by` int NOT NULL,
  `date_posted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`files_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_form
#

DROP TABLE IF EXISTS `tbl_form`;

CREATE TABLE `tbl_form` (
  `form_id` int NOT NULL AUTO_INCREMENT,
  `form_name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tbl_name` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `table_id` varchar(110) DEFAULT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (1, 'deposit', 'tbl_transactions', 'transactions_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (2, 'expense', 'tbl_transactions', 'transactions_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (3, 'tasks', 'tbl_task', 'task_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (4, 'project', 'tbl_project', 'project_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (5, 'leads', 'tbl_leads', 'leads_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (6, 'bugs', 'tbl_bug', 'bug_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (7, 'tickets', 'tbl_tickets', 'tickets_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (8, 'opportunities', 'tbl_opportunities', 'opportunities_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (9, 'invoice', 'tbl_invoices', 'invoices_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (10, 'estimates', 'tbl_estimates', 'estimates_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (11, 'proposal', 'tbl_proposals', 'proposals_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (12, 'client', 'tbl_client', 'client_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (13, 'users', 'tbl_account_details', 'account_details_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (14, 'job_circular', 'tbl_job_circular', 'job_circular_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (15, 'training', 'tbl_training', 'training_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (16, 'announcements', 'tbl_announcements', 'announcements_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (17, 'leave_management', 'tbl_leave_application', 'leave_application_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (18, 'items', 'tbl_saved_items', 'saved_items_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (19, 'supplier', 'tbl_suppliers', 'supplier_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (20, 'purchases', 'tbl_purchases', 'purchase_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (21, 'Account', 'tbl_accounts', 'account_id');
INSERT INTO `tbl_form` (`form_id`, `form_name`, `tbl_name`, `table_id`) VALUES (22, 'credit_note', 'tbl_credit_note', 'credit_note_id');


#
# TABLE STRUCTURE FOR: tbl_goal_tracking
#

DROP TABLE IF EXISTS `tbl_goal_tracking`;

CREATE TABLE `tbl_goal_tracking` (
  `goal_tracking_id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(200) NOT NULL,
  `goal_type_id` int NOT NULL,
  `achievement` int NOT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `account_id` int DEFAULT '0',
  `description` mediumtext NOT NULL,
  `notify_goal_achive` varchar(5) DEFAULT NULL,
  `notify_goal_not_achive` varchar(5) DEFAULT NULL,
  `permission` mediumtext,
  `email_send` varchar(5) NOT NULL DEFAULT 'no',
  PRIMARY KEY (`goal_tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_goal_type
#

DROP TABLE IF EXISTS `tbl_goal_type`;

CREATE TABLE `tbl_goal_type` (
  `goal_type_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(200) NOT NULL,
  `description` mediumtext NOT NULL,
  `tbl_name` varchar(200) NOT NULL,
  `query` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`goal_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (1, 'achive_total_income', 'to get total income report from this start and end date and notify user. ', 'tbl_transactions', 'Income');
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (2, 'achive_total_income_by_bank', 'to get total income report from this start and end date and notify user. ', 'tbl_transactions', 'Income');
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (3, 'achieve_total_expense', 'to get total expense report from this start and end date and notify user. ', 'tbl_transactions', 'Expense');
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (4, 'achive_total_expense_by_bank', 'to get total expense report from this start and end date and notify user. ', 'tbl_transactions', 'Expense');
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (5, 'make_invoice', 'to get targeted invoice from this start and end date and notify user. ', 'tbl_invoices', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (6, 'make_estimate', 'to get targeted estimate from this start and end date and notify user.', 'tbl_estimates', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (7, 'goal_payment', 'to get total payment report from this start and end date and notify user. ', 'tbl_payments', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (8, 'task_done', 'to get total done tasks report from this start and end date and notify user. ', 'tbl_task', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (9, 'resolved_bugs', 'to get total resolve bugs report from this start and end date and notify user. ', 'tbl_bug', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (10, 'convert_leads_to_client', 'to get total Convert leads to client report from this start and end date and notify user. ', 'tbl_client', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (11, 'direct_client', 'to get total client report from this start and end date and notify user. ', 'tbl_client', NULL);
INSERT INTO `tbl_goal_type` (`goal_type_id`, `type_name`, `description`, `tbl_name`, `query`) VALUES (12, 'complete_project_goal', 'to get total complete project report from this start and end date and notify user. ', 'tbl_project', NULL);


#
# TABLE STRUCTURE FOR: tbl_holiday
#

DROP TABLE IF EXISTS `tbl_holiday`;

CREATE TABLE `tbl_holiday` (
  `holiday_id` int NOT NULL AUTO_INCREMENT,
  `event_name` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `color` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`holiday_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_hourly_rate
#

DROP TABLE IF EXISTS `tbl_hourly_rate`;

CREATE TABLE `tbl_hourly_rate` (
  `hourly_rate_id` int NOT NULL AUTO_INCREMENT,
  `hourly_grade` varchar(200) NOT NULL,
  `hourly_rate` varchar(50) NOT NULL,
  PRIMARY KEY (`hourly_rate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_hourly_rate` (`hourly_rate_id`, `hourly_grade`, `hourly_rate`) VALUES (1, '4.5', '4.5');


#
# TABLE STRUCTURE FOR: tbl_inbox
#

DROP TABLE IF EXISTS `tbl_inbox`;

CREATE TABLE `tbl_inbox` (
  `inbox_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `to` varchar(100) NOT NULL,
  `from` varchar(100) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message_body` text NOT NULL,
  `attach_file` text,
  `attach_file_path` text,
  `attach_filename` text,
  `message_time` datetime NOT NULL,
  `view_status` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1=Read 2=Unread',
  `favourites` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0= no 1=yes',
  `notify_me` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=on 0=off',
  `deleted` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`inbox_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_income_category
#

DROP TABLE IF EXISTS `tbl_income_category`;

CREATE TABLE `tbl_income_category` (
  `income_category_id` int NOT NULL AUTO_INCREMENT,
  `income_category` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  PRIMARY KEY (`income_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_invoices
#

DROP TABLE IF EXISTS `tbl_invoices`;

CREATE TABLE `tbl_invoices` (
  `invoices_id` int NOT NULL AUTO_INCREMENT,
  `recur_start_date` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `recur_end_date` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `reference_no` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `client_id` int NOT NULL,
  `project_id` int DEFAULT '0',
  `invoice_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `invoice_month` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `invoice_year` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `due_date` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `alert_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `tax` decimal(10,2) NOT NULL DEFAULT '0.00',
  `total_tax` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `discount_percent` int DEFAULT NULL,
  `recurring` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `recuring_frequency` int NOT NULL DEFAULT '31',
  `recur_frequency` varchar(12) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `recur_next_date` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `currency` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'USD',
  `status` enum('Cancelled','Unpaid','Paid','draft','partially_paid') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Unpaid',
  `archived` int DEFAULT '0',
  `date_sent` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `inv_deleted` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `emailed` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `show_client` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Yes',
  `viewed` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `allow_paypal` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Yes',
  `allow_stripe` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Yes',
  `allow_2checkout` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Yes',
  `allow_authorize_net` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `allow_ccavenue` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `allow_braintree` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `allow_mollie` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `allow_payumoney` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `allow_tappayment` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Yes',
  `allow_razorpay` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `client_visible` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `discount_type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'none',
  `user_id` int NOT NULL DEFAULT '0' COMMENT 'sales agent',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `warehouse_id` int DEFAULT NULL,
  `tags` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`invoices_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_item_history
#

DROP TABLE IF EXISTS `tbl_item_history`;

CREATE TABLE `tbl_item_history` (
  `item_history_id` int NOT NULL AUTO_INCREMENT,
  `stock_id` int NOT NULL,
  `inventory` int NOT NULL,
  `purchase_date` date NOT NULL,
  PRIMARY KEY (`item_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_items
#

DROP TABLE IF EXISTS `tbl_items`;

CREATE TABLE `tbl_items` (
  `items_id` int NOT NULL AUTO_INCREMENT,
  `invoices_id` int NOT NULL,
  `item_tax_rate` decimal(18,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_tax_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `quantity` decimal(18,2) DEFAULT '0.00',
  `total_cost` decimal(18,2) DEFAULT '0.00',
  `item_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `unit_cost` decimal(18,2) DEFAULT '0.00',
  `order` int DEFAULT '0',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unit` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `saved_items_id` int DEFAULT '0',
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_job_appliactions
#

DROP TABLE IF EXISTS `tbl_job_appliactions`;

CREATE TABLE `tbl_job_appliactions` (
  `job_appliactions_id` int NOT NULL AUTO_INCREMENT,
  `job_circular_id` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `cover_letter` text NOT NULL,
  `resume` text NOT NULL,
  `application_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=pending 1=accept 2 = reject',
  `apply_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `send_email` varchar(20) DEFAULT NULL,
  `interview_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`job_appliactions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_job_circular
#

DROP TABLE IF EXISTS `tbl_job_circular`;

CREATE TABLE `tbl_job_circular` (
  `job_circular_id` int NOT NULL AUTO_INCREMENT,
  `job_title` varchar(200) NOT NULL,
  `designations_id` int NOT NULL,
  `vacancy_no` varchar(50) NOT NULL,
  `posted_date` date NOT NULL,
  `employment_type` enum('contractual','full_time','part_time') NOT NULL DEFAULT 'full_time',
  `experience` varchar(200) DEFAULT NULL,
  `age` varchar(200) DEFAULT NULL,
  `salary_range` varchar(200) DEFAULT NULL,
  `last_date` date NOT NULL,
  `description` text NOT NULL,
  `status` enum('published','unpublished') NOT NULL DEFAULT 'unpublished' COMMENT '1=publish 2=unpublish',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permission` text,
  PRIMARY KEY (`job_circular_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_job_circular` (`job_circular_id`, `job_title`, `designations_id`, `vacancy_no`, `posted_date`, `employment_type`, `experience`, `age`, `salary_range`, `last_date`, `description`, `status`, `created_date`, `permission`) VALUES (1, 'Mason Worker', 9, '100', '2025-11-07', 'full_time', '1 to 2 year', '30 to 45', '1500', '2025-11-14', '', 'published', '2025-11-07 19:49:31', 'all');


#
# TABLE STRUCTURE FOR: tbl_kb_category
#

DROP TABLE IF EXISTS `tbl_kb_category`;

CREATE TABLE `tbl_kb_category` (
  `kb_category_id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `description` longtext,
  `type` varchar(50) NOT NULL,
  `sort` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kb_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_knowledgebase
#

DROP TABLE IF EXISTS `tbl_knowledgebase`;

CREATE TABLE `tbl_knowledgebase` (
  `kb_id` int NOT NULL AUTO_INCREMENT,
  `kb_category_id` int NOT NULL,
  `title` text,
  `slug` text,
  `description` text,
  `attachments` text,
  `for_all` enum('Yes','No') DEFAULT 'No',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `total_view` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sort` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`kb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_languages
#

DROP TABLE IF EXISTS `tbl_languages`;

CREATE TABLE `tbl_languages` (
  `code` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `name` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `icon` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `active` int DEFAULT '0',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ar', 'arabic', 'ae', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('cs', 'czech', 'cs', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('da', 'danish', 'dk', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('de', 'german', 'de', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('el', 'greek', 'gr', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('en', 'english', 'us', 1);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('es', 'spanish', 'es', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('fr', 'french', 'fr', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('gu', 'gujarati', 'in', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('hi', 'hindi', 'in', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('id', 'indonesian', 'id', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('it', 'italian', 'it', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ja', 'japanese', 'jp', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('nl', 'dutch', 'nl', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('no', 'norwegian', 'no', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('pl', 'polish', 'pl', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('pt', 'portuguese', 'pt', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ro', 'romanian', 'ro', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('ru', 'russian', 'ru', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('tr', 'turkish', 'tr', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('vi', 'vietnamese', 'vn', 0);
INSERT INTO `tbl_languages` (`code`, `name`, `icon`, `active`) VALUES ('zh', 'chinese', 'cn', 0);


#
# TABLE STRUCTURE FOR: tbl_lead_form
#

DROP TABLE IF EXISTS `tbl_lead_form`;

CREATE TABLE `tbl_lead_form` (
  `lead_form_id` int NOT NULL AUTO_INCREMENT,
  `form_key` varchar(32) NOT NULL,
  `form_name` varchar(200) NOT NULL,
  `lead_status_id` int NOT NULL,
  `lead_source_id` int NOT NULL,
  `language` varchar(40) DEFAULT NULL,
  `form_recaptcha` int NOT NULL DEFAULT '0',
  `submit_btn_text` varchar(40) DEFAULT NULL,
  `submit_btn_msg` text,
  `allow_duplicate` int NOT NULL DEFAULT '1',
  `track_duplicate_field` varchar(100) DEFAULT NULL,
  `form_data` mediumtext,
  `notify_lead_imported` int NOT NULL DEFAULT '1',
  `permission` text,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lead_form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_lead_source
#

DROP TABLE IF EXISTS `tbl_lead_source`;

CREATE TABLE `tbl_lead_source` (
  `lead_source_id` int NOT NULL AUTO_INCREMENT,
  `lead_source` varchar(100) NOT NULL,
  PRIMARY KEY (`lead_source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_lead_source` (`lead_source_id`, `lead_source`) VALUES (1, 'Just Dial');
INSERT INTO `tbl_lead_source` (`lead_source_id`, `lead_source`) VALUES (2, 'Google ');


#
# TABLE STRUCTURE FOR: tbl_lead_status
#

DROP TABLE IF EXISTS `tbl_lead_status`;

CREATE TABLE `tbl_lead_status` (
  `lead_status_id` int NOT NULL AUTO_INCREMENT,
  `lead_status` varchar(50) NOT NULL,
  `lead_type` varchar(20) DEFAULT NULL,
  `order_no` int DEFAULT NULL,
  PRIMARY KEY (`lead_status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_lead_status` (`lead_status_id`, `lead_status`, `lead_type`, `order_no`) VALUES (1, 'Open', 'open', 1);


#
# TABLE STRUCTURE FOR: tbl_leads
#

DROP TABLE IF EXISTS `tbl_leads`;

CREATE TABLE `tbl_leads` (
  `leads_id` int NOT NULL AUTO_INCREMENT,
  `lead_name` varchar(50) NOT NULL,
  `client_id` int DEFAULT NULL,
  `organization` varchar(50) NOT NULL,
  `lead_status_id` int DEFAULT NULL,
  `lead_source_id` int DEFAULT NULL,
  `imported_from_email` tinyint(1) DEFAULT '0',
  `email_integration_uid` varchar(30) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `country` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `contact_name` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  `facebook` varchar(32) NOT NULL,
  `language` varchar(100) DEFAULT NULL,
  `notes` text NOT NULL,
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_contact` timestamp NULL DEFAULT NULL,
  `skype` varchar(200) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `permission` text,
  `converted_client_id` int NOT NULL DEFAULT '0',
  `index_no` int DEFAULT '0',
  `tags` text,
  `from_form_id` int DEFAULT NULL,
  PRIMARY KEY (`leads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_leads` (`leads_id`, `lead_name`, `client_id`, `organization`, `lead_status_id`, `lead_source_id`, `imported_from_email`, `email_integration_uid`, `company_name`, `address`, `country`, `state`, `city`, `contact_name`, `title`, `email`, `phone`, `mobile`, `facebook`, `language`, `notes`, `created_time`, `last_contact`, `skype`, `twitter`, `permission`, `converted_client_id`, `index_no`, `tags`, `from_form_id`) VALUES (1, 'Welder', NULL, 'PCC Group of Company', 1, 2, 0, NULL, NULL, '', 'United Arab Emirates', '', '', 'Shaji', NULL, 'accounts@hayatjadidagroups.com', '(+91) 903538319.+918925705723', '987456331', '', 'english', '', '2025-11-07 19:46:53', '2025-11-07 19:45:00', '', '', 'all', 0, 1, '', NULL);


#
# TABLE STRUCTURE FOR: tbl_leads_notes
#

DROP TABLE IF EXISTS `tbl_leads_notes`;

CREATE TABLE `tbl_leads_notes` (
  `notes_id` int NOT NULL AUTO_INCREMENT,
  `leads_id` int DEFAULT NULL,
  `notes` text,
  `contacted_indicator` varchar(50) DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_contact` timestamp NULL DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  PRIMARY KEY (`notes_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_leave_application
#

DROP TABLE IF EXISTS `tbl_leave_application`;

CREATE TABLE `tbl_leave_application` (
  `leave_application_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `leave_category_id` int NOT NULL,
  `reason` text NOT NULL,
  `leave_type` enum('single_day','multiple_days','hours') NOT NULL DEFAULT 'single_day',
  `hours` varchar(20) DEFAULT NULL,
  `leave_start_date` date NOT NULL,
  `leave_end_date` date DEFAULT NULL,
  `application_status` int NOT NULL DEFAULT '1' COMMENT '1=pending,2=accepted 3=rejected',
  `view_status` tinyint(1) NOT NULL DEFAULT '2',
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `attachment` text,
  `comments` text,
  `approve_by` int DEFAULT NULL,
  PRIMARY KEY (`leave_application_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_leave_application` (`leave_application_id`, `user_id`, `leave_category_id`, `reason`, `leave_type`, `hours`, `leave_start_date`, `leave_end_date`, `application_status`, `view_status`, `application_date`, `attachment`, `comments`, `approve_by`) VALUES (1, 8, 2, 'outstation', 'single_day', NULL, '2026-02-25', NULL, 2, 2, '2026-02-23 10:45:39', NULL, 'ok please come back fast', 5);


#
# TABLE STRUCTURE FOR: tbl_leave_category
#

DROP TABLE IF EXISTS `tbl_leave_category`;

CREATE TABLE `tbl_leave_category` (
  `leave_category_id` int NOT NULL AUTO_INCREMENT,
  `leave_category` varchar(100) NOT NULL,
  `leave_quota` int NOT NULL,
  PRIMARY KEY (`leave_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_leave_category` (`leave_category_id`, `leave_category`, `leave_quota`) VALUES (1, 'SICK', 2);
INSERT INTO `tbl_leave_category` (`leave_category_id`, `leave_category`, `leave_quota`) VALUES (2, 'HOLIDAY', 1);
INSERT INTO `tbl_leave_category` (`leave_category_id`, `leave_category`, `leave_quota`) VALUES (3, 'FESTIVAL', 5);


#
# TABLE STRUCTURE FOR: tbl_locales
#

DROP TABLE IF EXISTS `tbl_locales`;

CREATE TABLE `tbl_locales` (
  `locale` varchar(10) NOT NULL,
  `code` varchar(10) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `name` varchar(250) NOT NULL DEFAULT '',
  `icon` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('aa_DJ', 'aa', 'afar', 'Afar (Djibouti)', 'dj');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('aa_ER', 'aa', 'afar', 'Afar (Eritrea)', 'dj');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('aa_ET', 'aa', 'afar', 'Afar (Ethiopia)', 'dj');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('af_ZA', 'af', 'afrikaans', 'Afrikaans (South Africa)', 'za');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('am_ET', 'am', 'amharic', 'Amharic (Ethiopia)', 'et');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('an_ES', 'an', 'aragonese', 'Aragonese (Spain)', 'es');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_AE', 'ar', 'arabic', 'Arabic (United Arab Emirates)', 'es');
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_BH', 'ar', 'arabic', 'Arabic (Bahrain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_DZ', 'ar', 'arabic', 'Arabic (Algeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_EG', 'ar', 'arabic', 'Arabic (Egypt)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_IN', 'ar', 'arabic', 'Arabic (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_IQ', 'ar', 'arabic', 'Arabic (Iraq)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_JO', 'ar', 'arabic', 'Arabic (Jordan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_KW', 'ar', 'arabic', 'Arabic (Kuwait)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_LB', 'ar', 'arabic', 'Arabic (Lebanon)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_LY', 'ar', 'arabic', 'Arabic (Libya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_MA', 'ar', 'arabic', 'Arabic (Morocco)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_OM', 'ar', 'arabic', 'Arabic (Oman)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_QA', 'ar', 'arabic', 'Arabic (Qatar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_SA', 'ar', 'arabic', 'Arabic (Saudi Arabia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_SD', 'ar', 'arabic', 'Arabic (Sudan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_SY', 'ar', 'arabic', 'Arabic (Syria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_TN', 'ar', 'arabic', 'Arabic (Tunisia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ar_YE', 'ar', 'arabic', 'Arabic (Yemen)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ast_ES', 'ast', 'asturian', 'Asturian (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('as_IN', 'as', 'assamese', 'Assamese (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('az_AZ', 'az', 'azerbaijani', 'Azerbaijani (Azerbaijan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('az_TR', 'az', 'azerbaijani', 'Azerbaijani (Turkey)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bem_ZM', 'bem', 'bemba', 'Bemba (Zambia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ber_DZ', 'ber', 'berber', 'Berber (Algeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ber_MA', 'ber', 'berber', 'Berber (Morocco)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('be_BY', 'be', 'belarusian', 'Belarusian (Belarus)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bg_BG', 'bg', 'bulgarian', 'Bulgarian (Bulgaria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bn_BD', 'bn', 'bengali', 'Bengali (Bangladesh)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bn_IN', 'bn', 'bengali', 'Bengali (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bo_CN', 'bo', 'tibetan', 'Tibetan (China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bo_IN', 'bo', 'tibetan', 'Tibetan (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('br_FR', 'br', 'breton', 'Breton (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('bs_BA', 'bs', 'bosnian', 'Bosnian (Bosnia and Herzegovina)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('byn_ER', 'byn', 'blin', 'Blin (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_AD', 'ca', 'catalan', 'Catalan (Andorra)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_ES', 'ca', 'catalan', 'Catalan (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_FR', 'ca', 'catalan', 'Catalan (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ca_IT', 'ca', 'catalan', 'Catalan (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('crh_UA', 'crh', 'crimean turkish', 'Crimean Turkish (Ukraine)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('csb_PL', 'csb', 'kashubian', 'Kashubian (Poland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('cs_CZ', 'cs', 'czech', 'Czech (Czech Republic)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('cv_RU', 'cv', 'chuvash', 'Chuvash (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('cy_GB', 'cy', 'welsh', 'Welsh (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('da_DK', 'da', 'danish', 'Danish (Denmark)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_AT', 'de', 'german', 'German (Austria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_BE', 'de', 'german', 'German (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_CH', 'de', 'german', 'German (Switzerland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_DE', 'de', 'german', 'German (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_LI', 'de', 'german', 'German (Liechtenstein)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('de_LU', 'de', 'german', 'German (Luxembourg)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('dv_MV', 'dv', 'divehi', 'Divehi (Maldives)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('dz_BT', 'dz', 'dzongkha', 'Dzongkha (Bhutan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ee_GH', 'ee', 'ewe', 'Ewe (Ghana)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('el_CY', 'el', 'greek', 'Greek (Cyprus)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('el_GR', 'el', 'greek', 'Greek (Greece)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_AG', 'en', 'english', 'English (Antigua and Barbuda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_AS', 'en', 'english', 'English (American Samoa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_AU', 'en', 'english', 'English (Australia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_BW', 'en', 'english', 'English (Botswana)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_CA', 'en', 'english', 'English (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_DK', 'en', 'english', 'English (Denmark)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_GB', 'en', 'english', 'English (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_GU', 'en', 'english', 'English (Guam)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_HK', 'en', 'english', 'English (Hong Kong SAR China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_IE', 'en', 'english', 'English (Ireland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_IN', 'en', 'english', 'English (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_JM', 'en', 'english', 'English (Jamaica)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_MH', 'en', 'english', 'English (Marshall Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_MP', 'en', 'english', 'English (Northern Mariana Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_MU', 'en', 'english', 'English (Mauritius)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_NG', 'en', 'english', 'English (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_NZ', 'en', 'english', 'English (New Zealand)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_PH', 'en', 'english', 'English (Philippines)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_SG', 'en', 'english', 'English (Singapore)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_TT', 'en', 'english', 'English (Trinidad and Tobago)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_US', 'en', 'english', 'English (United States)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_VI', 'en', 'english', 'English (Virgin Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_ZA', 'en', 'english', 'English (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_ZM', 'en', 'english', 'English (Zambia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('en_ZW', 'en', 'english', 'English (Zimbabwe)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('eo', 'eo', 'esperanto', 'Esperanto', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_AR', 'es', 'spanish', 'Spanish (Argentina)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_BO', 'es', 'spanish', 'Spanish (Bolivia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_CL', 'es', 'spanish', 'Spanish (Chile)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_CO', 'es', 'spanish', 'Spanish (Colombia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_CR', 'es', 'spanish', 'Spanish (Costa Rica)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_DO', 'es', 'spanish', 'Spanish (Dominican Republic)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_EC', 'es', 'spanish', 'Spanish (Ecuador)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_ES', 'es', 'spanish', 'Spanish (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_GT', 'es', 'spanish', 'Spanish (Guatemala)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_HN', 'es', 'spanish', 'Spanish (Honduras)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_MX', 'es', 'spanish', 'Spanish (Mexico)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_NI', 'es', 'spanish', 'Spanish (Nicaragua)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PA', 'es', 'spanish', 'Spanish (Panama)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PE', 'es', 'spanish', 'Spanish (Peru)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PR', 'es', 'spanish', 'Spanish (Puerto Rico)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_PY', 'es', 'spanish', 'Spanish (Paraguay)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_SV', 'es', 'spanish', 'Spanish (El Salvador)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_US', 'es', 'spanish', 'Spanish (United States)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_UY', 'es', 'spanish', 'Spanish (Uruguay)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('es_VE', 'es', 'spanish', 'Spanish (Venezuela)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('et_EE', 'et', 'estonian', 'Estonian (Estonia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('eu_ES', 'eu', 'basque', 'Basque (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('eu_FR', 'eu', 'basque', 'Basque (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fa_AF', 'fa', 'persian', 'Persian (Afghanistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fa_IR', 'fa', 'persian', 'Persian (Iran)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ff_SN', 'ff', 'fulah', 'Fulah (Senegal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fil_PH', 'fil', 'filipino', 'Filipino (Philippines)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fi_FI', 'fi', 'finnish', 'Finnish (Finland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fo_FO', 'fo', 'faroese', 'Faroese (Faroe Islands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BE', 'fr', 'french', 'French (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BF', 'fr', 'french', 'French (Burkina Faso)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BI', 'fr', 'french', 'French (Burundi)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_BJ', 'fr', 'french', 'French (Benin)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CA', 'fr', 'french', 'French (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CF', 'fr', 'french', 'French (Central African Republic)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CG', 'fr', 'french', 'French (Congo)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CH', 'fr', 'french', 'French (Switzerland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_CM', 'fr', 'french', 'French (Cameroon)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_FR', 'fr', 'french', 'French (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GA', 'fr', 'french', 'French (Gabon)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GN', 'fr', 'french', 'French (Guinea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GP', 'fr', 'french', 'French (Guadeloupe)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_GQ', 'fr', 'french', 'French (Equatorial Guinea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_KM', 'fr', 'french', 'French (Comoros)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_LU', 'fr', 'french', 'French (Luxembourg)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_MC', 'fr', 'french', 'French (Monaco)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_MG', 'fr', 'french', 'French (Madagascar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_ML', 'fr', 'french', 'French (Mali)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_MQ', 'fr', 'french', 'French (Martinique)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_NE', 'fr', 'french', 'French (Niger)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_SN', 'fr', 'french', 'French (Senegal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_TD', 'fr', 'french', 'French (Chad)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fr_TG', 'fr', 'french', 'French (Togo)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fur_IT', 'fur', 'friulian', 'Friulian (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fy_DE', 'fy', 'western frisian', 'Western Frisian (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('fy_NL', 'fy', 'western frisian', 'Western Frisian (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ga_IE', 'ga', 'irish', 'Irish (Ireland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gd_GB', 'gd', 'scottish gaelic', 'Scottish Gaelic (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gez_ER', 'gez', 'geez', 'Geez (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gez_ET', 'gez', 'geez', 'Geez (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gl_ES', 'gl', 'galician', 'Galician (Spain)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gu_IN', 'gu', 'gujarati', 'Gujarati (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('gv_GB', 'gv', 'manx', 'Manx (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ha_NG', 'ha', 'hausa', 'Hausa (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('he_IL', 'he', 'hebrew', 'Hebrew (Israel)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hi_IN', 'hi', 'hindi', 'Hindi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hr_HR', 'hr', 'croatian', 'Croatian (Croatia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hsb_DE', 'hsb', 'upper sorbian', 'Upper Sorbian (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ht_HT', 'ht', 'haitian', 'Haitian (Haiti)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hu_HU', 'hu', 'hungarian', 'Hungarian (Hungary)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('hy_AM', 'hy', 'armenian', 'Armenian (Armenia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ia', 'ia', 'interlingua', 'Interlingua', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('id_ID', 'id', 'indonesian', 'Indonesian (Indonesia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ig_NG', 'ig', 'igbo', 'Igbo (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ik_CA', 'ik', 'inupiaq', 'Inupiaq (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('is_IS', 'is', 'icelandic', 'Icelandic (Iceland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('it_CH', 'it', 'italian', 'Italian (Switzerland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('it_IT', 'it', 'italian', 'Italian (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('iu_CA', 'iu', 'inuktitut', 'Inuktitut (Canada)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ja_JP', 'ja', 'japanese', 'Japanese (Japan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ka_GE', 'ka', 'georgian', 'Georgian (Georgia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kk_KZ', 'kk', 'kazakh', 'Kazakh (Kazakhstan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kl_GL', 'kl', 'kalaallisut', 'Kalaallisut (Greenland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('km_KH', 'km', 'khmer', 'Khmer (Cambodia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kn_IN', 'kn', 'kannada', 'Kannada (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kok_IN', 'kok', 'konkani', 'Konkani (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ko_KR', 'ko', 'korean', 'Korean (South Korea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ks_IN', 'ks', 'kashmiri', 'Kashmiri (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ku_TR', 'ku', 'kurdish', 'Kurdish (Turkey)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('kw_GB', 'kw', 'cornish', 'Cornish (United Kingdom)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ky_KG', 'ky', 'kirghiz', 'Kirghiz (Kyrgyzstan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lg_UG', 'lg', 'ganda', 'Ganda (Uganda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('li_BE', 'li', 'limburgish', 'Limburgish (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('li_NL', 'li', 'limburgish', 'Limburgish (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lo_LA', 'lo', 'lao', 'Lao (Laos)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lt_LT', 'lt', 'lithuanian', 'Lithuanian (Lithuania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('lv_LV', 'lv', 'latvian', 'Latvian (Latvia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mai_IN', 'mai', 'maithili', 'Maithili (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mg_MG', 'mg', 'malagasy', 'Malagasy (Madagascar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mi_NZ', 'mi', 'maori', 'Maori (New Zealand)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mk_MK', 'mk', 'macedonian', 'Macedonian (Macedonia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ml_IN', 'ml', 'malayalam', 'Malayalam (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mn_MN', 'mn', 'mongolian', 'Mongolian (Mongolia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mr_IN', 'mr', 'marathi', 'Marathi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ms_BN', 'ms', 'malay', 'Malay (Brunei)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ms_MY', 'ms', 'malay', 'Malay (Malaysia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('mt_MT', 'mt', 'maltese', 'Maltese (Malta)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('my_MM', 'my', 'burmese', 'Burmese (Myanmar)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('naq_NA', 'naq', 'namibia', 'Namibia', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nb_NO', 'nb', 'norwegian bokm?l', 'Norwegian Bokm?l (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nds_DE', 'nds', 'low german', 'Low German (Germany)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nds_NL', 'nds', 'low german', 'Low German (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ne_NP', 'ne', 'nepali', 'Nepali (Nepal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nl_AW', 'nl', 'dutch', 'Dutch (Aruba)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nl_BE', 'nl', 'dutch', 'Dutch (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nl_NL', 'nl', 'dutch', 'Dutch (Netherlands)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nn_NO', 'nn', 'norwegian nynorsk', 'Norwegian Nynorsk (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('no_NO', 'no', 'norwegian', 'Norwegian (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nr_ZA', 'nr', 'south ndebele', 'South Ndebele (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('nso_ZA', 'nso', 'northern sotho', 'Northern Sotho (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('oc_FR', 'oc', 'occitan', 'Occitan (France)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('om_ET', 'om', 'oromo', 'Oromo (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('om_KE', 'om', 'oromo', 'Oromo (Kenya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('or_IN', 'or', 'oriya', 'Oriya (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('os_RU', 'os', 'ossetic', 'Ossetic (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pap_AN', 'pap', 'papiamento', 'Papiamento (Netherlands Antilles)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pa_IN', 'pa', 'punjabi', 'Punjabi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pa_PK', 'pa', 'punjabi', 'Punjabi (Pakistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pl_PL', 'pl', 'polish', 'Polish (Poland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ps_AF', 'ps', 'pashto', 'Pashto (Afghanistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pt_BR', 'pt', 'portuguese', 'Portuguese (Brazil)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pt_GW', 'pt', 'portuguese', 'Portuguese (Guinea-Bissau)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('pt_PT', 'pt', 'portuguese', 'Portuguese (Portugal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ro_MD', 'ro', 'romanian', 'Romanian (Moldova)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ro_RO', 'ro', 'romanian', 'Romanian (Romania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ru_RU', 'ru', 'russian', 'Russian (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ru_UA', 'ru', 'russian', 'Russian (Ukraine)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('rw_RW', 'rw', 'kinyarwanda', 'Kinyarwanda (Rwanda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sa_IN', 'sa', 'sanskrit', 'Sanskrit (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sc_IT', 'sc', 'sardinian', 'Sardinian (Italy)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sd_IN', 'sd', 'sindhi', 'Sindhi (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('seh_MZ', 'seh', 'sena', 'Sena (Mozambique)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('se_NO', 'se', 'northern sami', 'Northern Sami (Norway)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sid_ET', 'sid', 'sidamo', 'Sidamo (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('si_LK', 'si', 'sinhala', 'Sinhala (Sri Lanka)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sk_SK', 'sk', 'slovak', 'Slovak (Slovakia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sl_SI', 'sl', 'slovenian', 'Slovenian (Slovenia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sn_ZW', 'sn', 'shona', 'Shona (Zimbabwe)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_DJ', 'so', 'somali', 'Somali (Djibouti)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_ET', 'so', 'somali', 'Somali (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_KE', 'so', 'somali', 'Somali (Kenya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('so_SO', 'so', 'somali', 'Somali (Somalia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sq_AL', 'sq', 'albanian', 'Albanian (Albania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sq_MK', 'sq', 'albanian', 'Albanian (Macedonia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sr_BA', 'sr', 'serbian', 'Serbian (Bosnia and Herzegovina)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sr_ME', 'sr', 'serbian', 'Serbian (Montenegro)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sr_RS', 'sr', 'serbian', 'Serbian (Serbia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ss_ZA', 'ss', 'swati', 'Swati (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('st_ZA', 'st', 'southern sotho', 'Southern Sotho (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sv_FI', 'sv', 'swedish', 'Swedish (Finland)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sv_SE', 'sv', 'swedish', 'Swedish (Sweden)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sw_KE', 'sw', 'swahili', 'Swahili (Kenya)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('sw_TZ', 'sw', 'swahili', 'Swahili (Tanzania)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ta_IN', 'ta', 'tamil', 'Tamil (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('teo_UG', 'teo', 'teso', 'Teso (Uganda)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('te_IN', 'te', 'telugu', 'Telugu (India)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tg_TJ', 'tg', 'tajik', 'Tajik (Tajikistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('th_TH', 'th', 'thai', 'Thai (Thailand)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tig_ER', 'tig', 'tigre', 'Tigre (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ti_ER', 'ti', 'tigrinya', 'Tigrinya (Eritrea)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ti_ET', 'ti', 'tigrinya', 'Tigrinya (Ethiopia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tk_TM', 'tk', 'turkmen', 'Turkmen (Turkmenistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tl_PH', 'tl', 'tagalog', 'Tagalog (Philippines)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tn_ZA', 'tn', 'tswana', 'Tswana (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('to_TO', 'to', 'tongan', 'Tongan (Tonga)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tr_CY', 'tr', 'turkish', 'Turkish (Cyprus)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tr_TR', 'tr', 'turkish', 'Turkish (Turkey)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ts_ZA', 'ts', 'tsonga', 'Tsonga (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('tt_RU', 'tt', 'tatar', 'Tatar (Russia)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ug_CN', 'ug', 'uighur', 'Uighur (China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('uk_UA', 'uk', 'ukrainian', 'Ukrainian (Ukraine)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ur_PK', 'ur', 'urdu', 'Urdu (Pakistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('uz_UZ', 'uz', 'uzbek', 'Uzbek (Uzbekistan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('ve_ZA', 've', 'venda', 'Venda (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('vi_VN', 'vi', 'vietnamese', 'Vietnamese (Vietnam)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('wa_BE', 'wa', 'walloon', 'Walloon (Belgium)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('wo_SN', 'wo', 'wolof', 'Wolof (Senegal)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('xh_ZA', 'xh', 'xhosa', 'Xhosa (South Africa)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('yi_US', 'yi', 'yiddish', 'Yiddish (United States)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('yo_NG', 'yo', 'yoruba', 'Yoruba (Nigeria)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_CN', 'zh', 'chinese', 'Chinese (China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_HK', 'zh', 'chinese', 'Chinese (Hong Kong SAR China)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_SG', 'zh', 'chinese', 'Chinese (Singapore)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zh_TW', 'zh', 'chinese', 'Chinese (Taiwan)', NULL);
INSERT INTO `tbl_locales` (`locale`, `code`, `language`, `name`, `icon`) VALUES ('zu_ZA', 'zu', 'zulu', 'Zulu (South Africa)', NULL);


#
# TABLE STRUCTURE FOR: tbl_manufacturer
#

DROP TABLE IF EXISTS `tbl_manufacturer`;

CREATE TABLE `tbl_manufacturer` (
  `manufacturer_id` int NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`manufacturer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_menu
#

DROP TABLE IF EXISTS `tbl_menu`;

CREATE TABLE `tbl_menu` (
  `menu_id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `parent` int NOT NULL DEFAULT '0',
  `sort` int NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` tinyint(1) DEFAULT '1' COMMENT '1= active 0=inactive',
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (1, 'dashboard', 'admin/dashboard', 'fa fa-dashboard', 0, 0, '2017-04-22 19:39:36', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (2, 'calendar', 'admin/calendar', 'fa fa-calendar', 0, 1, '2017-04-23 13:57:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (4, 'client', 'admin/client/manage_client', 'fa fa-users', 0, 13, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (5, 'mailbox', 'admin/mailbox', 'fa fa-envelope-o', 0, 2, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (6, 'tickets', 'admin/tickets', 'fa fa-ticket', 0, 10, '2018-06-08 07:39:39', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (12, 'sales', '#', 'fa fa-shopping-cart', 0, 9, '2017-06-10 08:02:58', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (13, 'invoice', 'admin/invoice/manage_invoice', 'fa fa-circle-o', 12, 0, '2017-04-23 13:57:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (14, 'estimates', 'admin/estimates', 'fa fa-circle-o', 12, 1, '2017-06-10 08:02:05', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (15, 'payments_received', 'admin/invoice/all_payments', 'fa fa-circle-o', 12, 3, '2017-04-23 13:57:24', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (16, 'tax_rates', 'admin/invoice/tax_rates', 'fa fa-circle-o', 12, 5, '2018-01-07 01:05:16', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (21, 'quotations', '#', 'fa fa-paste', 12, 7, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (22, 'quotations_list', 'admin/quotations', 'fa fa-circle-o', 21, 0, '2017-05-18 10:49:03', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (23, 'quotations_form', 'admin/quotations/quotations_form', 'fa fa-circle-o', 21, 1, '2016-05-30 02:50:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (24, 'user', 'admin/user/user_list', 'fa fa-users', 0, 25, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (25, 'settings', 'admin/settings', 'fa fa-cogs', 0, 26, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (26, 'database_backup', 'admin/settings/database_backup', 'fa fa-database', 0, 27, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (29, 'transactions_menu', '#', 'fa fa-building-o', 0, 12, '2018-05-13 06:27:58', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (30, 'deposit', 'admin/transactions/deposit', 'fa fa-circle-o', 29, 1, '2018-05-13 06:28:33', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (31, 'expense', 'admin/transactions/expense', 'fa fa-circle-o', 29, 0, '2018-05-13 06:28:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (32, 'transfer', 'admin/transactions/transfer', 'fa fa-circle-o', 29, 2, '2018-05-13 06:28:40', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (33, 'transactions_report', 'admin/transactions/transactions_report', 'fa fa-circle-o', 29, 3, '2018-05-13 06:28:44', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (34, 'balance_sheet', 'admin/transactions/balance_sheet', 'fa fa-circle-o', 29, 5, '2018-05-13 06:28:47', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (36, 'bank_cash', 'admin/account/manage_account', 'fa fa-money', 29, 6, '2018-05-13 06:28:51', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (39, 'items', 'admin/items/items_list', 'fa fa-cube', 150, 0, '2019-05-04 12:49:50', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (42, 'report', '#', 'fa fa-bar-chart', 0, 24, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (43, 'account_statement', 'admin/report/account_statement', 'fa fa-circle-o', 146, 0, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (44, 'income_report', 'admin/report/income_report', 'fa fa-circle-o', 146, 2, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (45, 'expense_report', 'admin/report/expense_report', 'fa fa-circle-o', 146, 1, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (46, 'income_expense', 'admin/report/income_expense', 'fa fa-circle-o', 146, 3, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (47, 'date_wise_report', 'admin/report/date_wise_report', 'fa fa-circle-o', 146, 4, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (48, 'all_income', 'admin/report/all_income', 'fa fa-circle-o', 146, 6, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (49, 'all_expense', 'admin/report/all_expense', 'fa fa-circle-o', 146, 7, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (50, 'all_transaction', 'admin/report/all_transaction', 'fa fa-circle-o', 146, 8, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (51, 'recurring_invoice', 'admin/invoice/recurring_invoice', 'fa fa-circle-o', 12, 2, '2017-06-10 08:02:05', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (52, 'transfer_report', 'admin/transactions/transfer_report', 'fa fa-circle-o', 29, 4, '2018-05-13 06:28:59', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (53, 'report_by_month', 'admin/report/report_by_month', 'fa fa-circle-o', 146, 5, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (54, 'tasks', 'admin/tasks/all_task', 'fa fa-tasks', 0, 5, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (55, 'leads', 'admin/leads', 'fa fa-rocket', 0, 8, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (56, 'opportunities', 'admin/opportunities', 'fa fa-filter', 0, 7, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (57, 'projects', 'admin/projects', 'fa fa-folder-open-o', 0, 4, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (58, 'bugs', 'admin/bugs', 'fa fa-bug', 0, 6, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (59, 'project', '#', 'fa fa-folder-open-o', 42, 2, '2018-01-07 01:09:39', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (60, 'tasks_report', 'admin/report/tasks_report', 'fa fa-circle-o', 42, 3, '2018-01-07 01:09:39', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (61, 'bugs_report', 'admin/report/bugs_report', 'fa fa-circle-o', 42, 4, '2018-01-07 01:09:39', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (62, 'tickets_report', 'admin/report/tickets_report', 'fa fa-circle-o', 42, 5, '2018-01-07 01:09:39', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (63, 'client_report', 'admin/report/client_report', 'fa fa-circle-o', 42, 6, '2018-01-07 01:09:40', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (66, 'tasks_assignment', 'admin/report/tasks_assignment', 'fa fa-dot-circle-o', 59, 0, '2016-05-30 02:55:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (67, 'bugs_assignment', 'admin/report/bugs_assignment', 'fa fa-dot-circle-o', 59, 1, '2016-05-30 02:55:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (68, 'project_report', 'admin/report/project_report', 'fa fa-dot-circle-o', 59, 2, '2016-05-30 02:55:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (69, 'goal_tracking', 'admin/goal_tracking', 'fa fa-shield', 73, 1, '2017-06-10 08:05:47', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (70, 'departments', 'admin/departments', 'fa fa-user-secret', 0, 14, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (71, 'holiday', 'admin/holiday', 'fa fa-calendar-plus-o', 73, 0, '2017-06-10 08:05:47', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (72, 'leave_management', 'admin/leave_management', 'fa fa-plane', 0, 20, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (73, 'utilities', '#', 'fa fa-gift', 0, 23, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (74, 'overtime', 'admin/utilities/overtime', 'fa fa-clock-o', 89, 9, '2017-06-10 08:04:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (75, 'office_stock', '#', 'fa fa-codepen', 0, 15, '2019-05-01 10:22:56', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (76, 'stock_category', 'admin/stock/stock_category', 'fa fa-sliders', 75, 0, '2016-05-30 02:50:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (77, 'manage_stock', '#', 'fa fa-archive', 75, 2, '2017-04-26 10:11:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (78, 'assign_stock', '#', 'fa fa-align-left', 75, 3, '2017-04-26 10:11:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (79, 'stock_report', 'admin/stock/report', 'fa fa-line-chart', 75, 4, '2017-04-25 12:48:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (81, 'stock_list', 'admin/stock/stock_list', 'fa fa-stack-exchange', 75, 1, '2017-04-26 10:11:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (82, 'assign_stock', 'admin/stock/assign_stock', 'fa fa-align-left', 78, 0, '2016-05-30 02:55:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (83, 'assign_stock_report', 'admin/stock/assign_stock_report', 'fa fa-bar-chart', 78, 1, '2016-05-30 02:55:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (84, 'stock_history', 'admin/stock/stock_history', 'fa fa-file-text-o', 77, 0, '2016-05-30 02:55:02', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (85, 'performance', '#', 'fa fa-dribbble', 0, 19, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (86, 'performance_indicator', 'admin/performance/performance_indicator', 'fa fa-random', 85, 0, '2016-05-30 02:50:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (87, 'performance_report', 'admin/performance/performance_report', 'fa fa-calendar-o', 85, 2, '2016-05-30 02:50:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (88, 'give_appraisal', 'admin/performance/give_performance_appraisal', 'fa fa-plus', 85, 1, '2016-05-30 02:50:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (89, 'payroll', '#', 'fa fa-usd', 0, 18, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (90, 'manage_salary_details', 'admin/payroll/manage_salary_details', 'fa fa-usd', 89, 2, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (91, 'employee_salary_list', 'admin/payroll/employee_salary_list', 'fa fa-user-secret', 89, 3, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (92, 'make_payment', 'admin/payroll/make_payment', 'fa fa-tasks', 89, 4, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (93, 'generate_payslip', 'admin/payroll/generate_payslip', 'fa fa-list-ul', 89, 5, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (94, 'salary_template', 'admin/payroll/salary_template', 'fa fa-money', 89, 0, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (95, 'hourly_rate', 'admin/payroll/hourly_rate', 'fa fa-clock-o', 89, 1, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (96, 'payroll_summary', 'admin/payroll/payroll_summary', 'fa fa-camera-retro', 89, 6, '2017-04-23 02:06:37', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (97, 'provident_fund', 'admin/payroll/provident_fund', 'fa fa-briefcase', 89, 8, '2017-06-10 08:04:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (98, 'advance_salary', 'admin/payroll/advance_salary', 'fa fa-cc-mastercard', 89, 7, '2017-06-10 08:04:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (99, 'employee_award', 'admin/award', 'fa fa-trophy', 89, 10, '2017-06-10 08:05:47', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (100, 'announcements', 'admin/announcements', 'fa fa-bullhorn icon', 0, 22, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (101, 'training', 'admin/training', 'fa fa-suitcase', 0, 21, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (102, 'job_circular', '#', 'fa fa-globe', 0, 17, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (103, 'jobs_posted', 'admin/job_circular/jobs_posted', 'fa fa-ticket', 102, 0, '2016-05-30 02:50:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (104, 'jobs_applications', 'admin/job_circular/jobs_applications', 'fa fa-compass', 102, 1, '2016-05-30 02:50:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (105, 'attendance', '#', 'fa fa-file-text', 0, 16, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (106, 'timechange_request', 'admin/attendance/timechange_request', 'fa fa-calendar-o', 105, 1, '2016-05-30 02:50:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (107, 'attendance_report', 'admin/attendance/attendance_report', 'fa fa-file-text', 105, 2, '2016-05-30 02:50:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (108, 'time_history', 'admin/attendance/time_history', 'fa fa-clock-o', 105, 0, '2016-05-30 02:50:21', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (109, 'pull-down', '', '', 0, 0, '2016-05-31 06:43:20', 0);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (110, 'filemanager', 'admin/filemanager', 'fa fa-file', 0, 3, '2017-06-10 08:16:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (111, 'company_details', 'admin/settings', 'fa fa-fw fa-info-circle', 25, 1, '2017-04-25 11:08:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (112, 'system_settings', 'admin/settings/system', 'fa fa-fw fa-desktop', 25, 2, '2017-04-25 11:08:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (113, 'email_settings', 'admin/settings/email', 'fa fa-fw fa-envelope', 25, 3, '2017-04-25 11:08:46', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (114, 'email_templates', 'admin/settings/templates', 'fa fa-fw fa-pencil-square', 25, 5, '2021-07-30 00:18:08', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (115, 'email_integration', 'admin/settings/email_integration', 'fa fa-fw fa-envelope-o', 25, 6, '2021-07-30 00:18:08', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (116, 'payment_settings', 'admin/settings/payments', 'fa fa-fw fa-dollar', 25, 7, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (117, 'invoice_settings', 'admin/settings/invoice', 'fa fa-fw fa-money', 25, 8, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (118, 'estimate_settings', 'admin/settings/estimate', 'fa fa-fw fa-file-o', 25, 10, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (119, 'tickets_leads_settings', 'admin/settings/tickets', 'fa fa-fw fa-ticket', 25, 14, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (120, 'theme_settings', 'admin/settings/theme', 'fa fa-fw fa-code', 25, 20, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (121, 'working_days', 'admin/settings/working_days', 'fa fa-fw fa-calendar', 25, 22, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (122, 'leave_category', 'admin/settings/leave_category', 'fa fa-fw fa-pagelines', 25, 23, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (123, 'income_category', 'admin/settings/income_category', 'fa fa-fw fa-certificate', 25, 24, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (124, 'expense_category', 'admin/settings/expense_category', 'fa fa-fw fa-tasks', 25, 25, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (125, 'customer_group', 'admin/settings/customer_group', 'fa fa-fw fa-users', 25, 26, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (127, 'lead_status', 'admin/settings/lead_status', 'fa fa-fw fa-list-ul', 25, 16, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (128, 'lead_source', 'admin/settings/lead_source', 'fa fa-fw fa-arrow-down', 25, 17, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (129, 'opportunities_state_reason', 'admin/settings/opportunities_state_reason', 'fa fa-fw fa-dot-circle-o', 25, 19, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (130, 'custom_field', 'admin/settings/custom_field', 'fa fa-fw fa-star-o', 25, 28, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (131, 'payment_method', 'admin/settings/payment_method', 'fa fa-fw fa-money', 25, 29, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (132, 'cronjob', 'admin/settings/cronjob', 'fa fa-fw fa-contao', 25, 31, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (133, 'menu_allocation', 'admin/settings/menu_allocation', 'fa fa-fw fa fa-compass', 25, 32, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (134, 'notification', 'admin/settings/notification', 'fa fa-fw fa-bell-o', 25, 33, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (135, 'email_notification', 'admin/settings/email_notification', 'fa fa-fw fa-bell-o', 25, 34, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (136, 'database_backup', 'admin/settings/database_backup', 'fa fa-fw fa-database', 25, 35, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (137, 'translations', 'admin/settings/translations', 'fa fa-fw fa-language', 25, 36, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (138, 'system_update', 'admin/settings/system_update', 'fa fa-fw fa-pencil-square-o', 25, 37, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (139, 'private_chat', 'chat/conversations', 'fa fa-envelope', 0, 28, '2018-01-07 01:05:18', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (140, 'proposals', 'admin/proposals', 'fa fa-circle-o', 12, 4, '2018-01-07 01:05:16', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (141, 'knowledgebase', '#', 'fa fa-question-circle', 0, 11, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (142, 'categories', 'admin/knowledgebase/categories', 'fa fa-circle-o', 141, 2, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (143, 'articles', 'admin/knowledgebase/articles', 'fa fa-circle-o', 141, 1, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (144, 'knowledgebase', 'admin/knowledgebase', 'fa fa-circle-o', 141, 0, '2018-01-07 01:05:17', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (145, 'dashboard_settings', 'admin/settings/dashboard', 'fa fa-fw fa-dashboard', 25, 21, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (146, 'transactions_reports', '#', 'fa fa-building-o', 42, 1, '2018-05-13 06:29:51', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (147, 'sales', 'admin/report/sales_report', 'fa fa-shopping-cart', 42, 0, '2018-01-06 19:12:23', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (148, 'mark_attendance', 'admin/mark_attendance', 'fa fa-file-text', 105, 2, '2018-03-07 00:45:25', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (149, 'allowed_ip', 'admin/settings/allowed_ip', 'fa fa-server', 25, 27, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (150, 'stock', '#', 'icon-layers', 0, 8, '2019-05-01 12:10:52', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (151, 'supplier', 'admin/supplier', 'icon-briefcase', 150, 1, '2019-05-01 12:10:52', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (152, 'purchase', 'admin/purchase', 'icon-handbag', 150, 2, '2019-05-01 12:10:52', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (153, 'return_stock', 'admin/return_stock', 'icon-share-alt', 150, 3, '2019-05-05 10:19:30', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (154, 'purchase_payment', 'admin/purchase/all_payments', 'icon-credit-card', 150, 4, '2019-05-05 07:53:11', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (155, 'purchase_settings', 'admin/settings/purchase', 'fa-fw icon-handbag', 25, 12, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (156, 'credit_note', 'admin/credit_note', 'fa fa-circle-o', 12, 1, '2017-06-09 20:32:05', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (157, 'credit_note_settings', 'admin/settings/credit_note', 'fa fa-fw fa-money', 25, 9, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (158, 'proposals_settings', 'admin/settings/proposals', 'fa fa-fw fa-leaf', 25, 11, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (159, 'projects_settings', 'admin/settings/projects', 'fa fa-fw fa-folder-open-o', 25, 13, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (160, 'tags', 'admin/settings/tags', 'fa fa-fw fa-tags', 25, 30, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (161, 'lead_form', 'admin/leads/all_lead_form', 'fa fa-fw fa-rocket', 25, 18, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (162, 'transactions_settings', 'admin/settings/transactions', 'fa fa-fw fa-building-o', 25, 15, '2021-07-30 00:18:09', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (163, 'sms_settings', 'admin/settings/sms_settings', 'fa fa-fw fa-envelope', 25, 4, '2021-07-30 00:18:08', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (164, 'pos_sales', 'admin/invoice/pos_sales', 'fa fa-circle-o', 12, 0, '2021-10-15 18:53:10', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (186, 'warehouse', 'admin/warehouse/manage', 'fa fa-building-o', 150, 3, '2021-10-18 03:24:24', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (187, 'transferItem', 'admin/items/transferItem', 'fa fa-circle-o', 150, 4, '2021-10-14 05:56:08', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (203, 'award_setting', 'admin/settings/award', 'fa fa-star', 25, 30, '2022-01-18 23:51:40', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (204, 'award_rule_setting', 'admin/settings/award_rule_settingh', 'fa fa-star', 25, 31, '2022-01-19 03:53:50', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (205, 'award_program_settings', 'admin/settings/award_program_settings', 'fa fa-cog', 25, 32, '2022-01-20 03:17:30', 2);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (206, 'client_award_points', 'admin/invoice/client_awards', 'fa fa-circle-o', 12, 10, '2022-01-20 19:39:41', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (207, 'best_selling_product', 'admin/best_selling', 'fa fa-circle-o', 12, 11, '2022-01-21 00:43:52', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (209, 'warning', 'admin/warning', 'fa fa-warning', 0, 3, '2022-08-07 06:47:01', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (210, 'promotion', 'admin/promotion', 'fa fa-arrow-circle-up', 0, 4, '2022-08-07 06:49:28', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (211, 'termination', 'admin/termination', 'fa fa-eraser', 0, 5, '2022-08-07 06:50:45', 1);
INSERT INTO `tbl_menu` (`menu_id`, `label`, `link`, `icon`, `parent`, `sort`, `time`, `status`) VALUES (212, 'resignation', 'admin/resignation', 'fa fa-scissors', 0, 6, '2022-08-07 06:54:31', 1);


#
# TABLE STRUCTURE FOR: tbl_mettings
#

DROP TABLE IF EXISTS `tbl_mettings`;

CREATE TABLE `tbl_mettings` (
  `mettings_id` int NOT NULL AUTO_INCREMENT,
  `leads_id` int DEFAULT NULL,
  `opportunities_id` int DEFAULT NULL,
  `meeting_subject` varchar(200) NOT NULL,
  `attendees` varchar(300) NOT NULL,
  `user_id` int NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  `start_date` varchar(100) NOT NULL,
  `end_date` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `description` mediumtext NOT NULL,
  PRIMARY KEY (`mettings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_migrations
#

DROP TABLE IF EXISTS `tbl_migrations`;

CREATE TABLE `tbl_migrations` (
  `version` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_migrations` (`version`) VALUES ('604');


#
# TABLE STRUCTURE FOR: tbl_milestones
#

DROP TABLE IF EXISTS `tbl_milestones`;

CREATE TABLE `tbl_milestones` (
  `milestones_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `milestone_name` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `client_visible` text,
  PRIMARY KEY (`milestones_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_modules
#

DROP TABLE IF EXISTS `tbl_modules`;

CREATE TABLE `tbl_modules` (
  `module_id` int NOT NULL AUTO_INCREMENT,
  `module_name` varchar(55) NOT NULL,
  `installed_version` varchar(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_notes
#

DROP TABLE IF EXISTS `tbl_notes`;

CREATE TABLE `tbl_notes` (
  `notes_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `is_client` enum('Yes','No') NOT NULL DEFAULT 'No',
  `notes` mediumtext,
  `added_by` int NOT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_notifications
#

DROP TABLE IF EXISTS `tbl_notifications`;

CREATE TABLE `tbl_notifications` (
  `notifications_id` int NOT NULL AUTO_INCREMENT,
  `read` int NOT NULL DEFAULT '0',
  `read_inline` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `from_user_id` int NOT NULL DEFAULT '0',
  `to_user_id` int NOT NULL DEFAULT '0',
  `name` varchar(200) DEFAULT NULL,
  `link` text,
  `icon` varchar(200) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`notifications_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (1, 1, 0, '2025-11-07 19:46:53', 'not_save_leads', 5, 6, 'HAYAT JADIDA GROUPS', 'admin/leads/leads_details/1', NULL, 'lead Welder');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (2, 0, 0, '2026-02-23 10:44:30', 'not_leave_request', 0, 8, NULL, 'admin/leave_management/index/view_details/1', 'clock-o', 'By YAHYA MUZEMIL HUSENN');
INSERT INTO `tbl_notifications` (`notifications_id`, `read`, `read_inline`, `date`, `description`, `from_user_id`, `to_user_id`, `name`, `link`, `icon`, `value`) VALUES (3, 0, 0, '2026-02-23 10:46:10', 'not_leave_request_approve', 0, 8, NULL, 'admin/leave_management/index/view_details/1', 'clock-o', 'By HAYAT MANPOWER.AE');


#
# TABLE STRUCTURE FOR: tbl_offence_category
#

DROP TABLE IF EXISTS `tbl_offence_category`;

CREATE TABLE `tbl_offence_category` (
  `offence_id` int NOT NULL AUTO_INCREMENT,
  `offence_category` varchar(100) NOT NULL,
  PRIMARY KEY (`offence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_online_payment
#

DROP TABLE IF EXISTS `tbl_online_payment`;

CREATE TABLE `tbl_online_payment` (
  `online_payment_id` int NOT NULL AUTO_INCREMENT,
  `gateway_name` varchar(20) NOT NULL,
  `icon` text NOT NULL,
  `field_1` varchar(100) DEFAULT NULL,
  `field_2` varchar(100) DEFAULT NULL,
  `field_3` varchar(100) DEFAULT NULL,
  `field_4` varchar(100) DEFAULT NULL,
  `field_5` varchar(100) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL,
  `modal` enum('Yes','No') DEFAULT NULL,
  PRIMARY KEY (`online_payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (1, 'paypal', 'asset/images/payment_logo/paypal.png', 'paypal_api_username', 'paypal_api_password|password', 'api_signature', 'paypal_live|checkbox', '', 'payment/paypal', 'Yes');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (2, 'Stripe', 'asset/images/payment_logo/stripe.jpg', 'stripe_private_key', 'stripe_public_key', NULL, NULL, NULL, 'payment/stripe', 'Yes');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (3, '2checkout', 'asset/images/payment_logo/2checkout.jpg', '2checkout_live|checkbox', '2checkout_publishable_key', '2checkout_private_key', '2checkout_seller_id', NULL, 'payment/checkout', 'No');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (4, 'Authorize.net', 'asset/images/payment_logo/Authorizenet.png', 'aim_api_login_id', 'aim_authorize_transaction_key', 'aim_authorize_live|checkbox', '', '', 'payment/authorize', 'No');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (5, 'CCAvenue', 'asset/images/payment_logo/CCAvenue.jpg', 'ccavenue_merchant_id', 'ccavenue_key', 'ccavenue_access_code', 'ccavenue_enable_test_mode|checkbox', '', 'payment/ccavenue', 'No');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (6, 'Braintree', 'asset/images/payment_logo/Braintree.png', 'braintree_merchant_id', 'braintree_private_key', 'braintree_public_key', 'braintree_live_or_sandbox|checkbox', '', 'payment/braintree', 'No');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (7, 'Mollie', 'asset/images/payment_logo/ideal_mollie.png', 'mollie_api_key', 'mollie_partner_id', NULL, NULL, NULL, 'payment/mollie', 'Yes');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (8, 'PayUmoney', 'asset/images/payment_logo/payumoney.jpg', 'payumoney_key', 'payumoney_salt', 'payumoney_enable_test_mode|checkbox', '', NULL, 'payment/payumoney', 'No');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (9, 'Razorpay', 'asset/images/payment_logo/razorpay.png', 'razorpay_key', NULL, NULL, NULL, NULL, 'payment/razorpay', 'Yes');
INSERT INTO `tbl_online_payment` (`online_payment_id`, `gateway_name`, `icon`, `field_1`, `field_2`, `field_3`, `field_4`, `field_5`, `link`, `modal`) VALUES (10, 'TapPayment', 'asset/images/payment_logo/tappayment.jpg', 'tap_api_key', 'tap_user_name', 'tap_password|password', 'tap_merchantID', '', 'payment/TapPayment', 'Yes');


#
# TABLE STRUCTURE FOR: tbl_opportunities
#

DROP TABLE IF EXISTS `tbl_opportunities`;

CREATE TABLE `tbl_opportunities` (
  `opportunities_id` int NOT NULL AUTO_INCREMENT,
  `opportunity_name` varchar(100) NOT NULL,
  `stages` varchar(20) NOT NULL,
  `probability` varchar(20) NOT NULL,
  `close_date` varchar(20) NOT NULL,
  `opportunities_state_reason_id` int NOT NULL,
  `expected_revenue` varchar(300) DEFAULT NULL,
  `new_link` varchar(20) NOT NULL,
  `next_action` varchar(100) NOT NULL,
  `next_action_date` varchar(20) NOT NULL,
  `notes` text,
  `permission` text,
  PRIMARY KEY (`opportunities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_opportunities_state_reason
#

DROP TABLE IF EXISTS `tbl_opportunities_state_reason`;

CREATE TABLE `tbl_opportunities_state_reason` (
  `opportunities_state_reason_id` int NOT NULL AUTO_INCREMENT,
  `opportunities_state` varchar(20) NOT NULL,
  `opportunities_state_reason` varchar(100) NOT NULL,
  PRIMARY KEY (`opportunities_state_reason_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_outgoing_emails
#

DROP TABLE IF EXISTS `tbl_outgoing_emails`;

CREATE TABLE `tbl_outgoing_emails` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `sent_to` varchar(64) DEFAULT NULL,
  `sent_from` varchar(64) DEFAULT NULL,
  `subject` text,
  `message` longtext,
  `date_sent` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `delivered` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_outgoing_emails` (`id`, `sent_to`, `sent_from`, `subject`, `message`, `date_sent`, `delivered`) VALUES (1, 'demo@demo.com', 'admin@hayatjadidagroups.com hayatjadidagroups', 'Welcome Email ', '<p>Hello <strong>demo</strong>,</p>\r\n\r\n<p>Welcome to <strong>hayatjadidagroups</strong> .Thanks for joining <strong>hayatjadidagroups</strong>.</p>\r\n\r\n<p>We just wanted to say welcome.</p>\r\n\r\n<p>Please contact us if you need any help.</p>\r\n\r\n<p>Click here to view your profile: <strong>http://hayatjadidagroups.com/erp/</strong></p>\r\n\r\n<p><br />\r\nHave fun!<br />\r\nThe <strong>hayatjadidagroups</strong> Team.</p>\r\n', '2025-11-02 21:05:47', 0);
INSERT INTO `tbl_outgoing_emails` (`id`, `sent_to`, `sent_from`, `subject`, `message`, `date_sent`, `delivered`) VALUES (2, 'jain@hayat.com', 'admin@hayatjadidagroups.com hayatjadidagroups', 'Welcome Email ', '<p>Hello <strong>JAINULABUDEEN AHIYA</strong>,</p>\r\n\r\n<p>Welcome to <strong>hayatjadidagroups</strong> .Thanks for joining <strong>hayatjadidagroups</strong>.</p>\r\n\r\n<p>We just wanted to say welcome.</p>\r\n\r\n<p>Please contact us if you need any help.</p>\r\n\r\n<p>Click here to view your profile: <strong>https://hayatjadidagroups.com/erp/</strong></p>\r\n\r\n<p><br />\r\nHave fun!<br />\r\nThe <strong>hayatjadidagroups</strong> Team.</p>\r\n', '2026-01-21 18:45:44', 0);
INSERT INTO `tbl_outgoing_emails` (`id`, `sent_to`, `sent_from`, `subject`, `message`, `date_sent`, `delivered`) VALUES (3, 'yahya@hayatjadidagroups.com', 'admin@hayatjadidagroups.com hayatjadidagroups', 'A Leave Request from you', '<p>Hi there,</p>\r\n\r\n<p><strong>YAHYA MUZEMIL HUSENN</strong> &nbsp;Want to leave from you.</p>\r\n\r\n<p>You can view this leave request by logging in to the portal using the link below<br />\r\n<big><strong><a href=\"https://hayatjadidagroups.com/erp/admin/leave_management/index/view_details/1\">View Application</a></strong></big><br />\r\n<br />\r\n<br />\r\nRegards<br />\r\n<br />\r\nThe hayatjadidagroups Team</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', '2026-02-23 10:44:30', 0);
INSERT INTO `tbl_outgoing_emails` (`id`, `sent_to`, `sent_from`, `subject`, `message`, `date_sent`, `delivered`) VALUES (4, 'yahya@hayatjadidagroups.com', 'admin@hayatjadidagroups.com hayatjadidagroups', 'Your leave request has been approved', '<h1>Your leave request has been approved</h1>\r\n\r\n<p><strong>Congratulations!</strong> Your leave request from <strong>2026-02-25</strong> to <strong></strong> has been approved by your company management.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><br />\r\nRegards<br />\r\n<br />\r\nThe hayatjadidagroups Team</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n', '2026-02-23 10:46:10', 0);


#
# TABLE STRUCTURE FOR: tbl_overtime
#

DROP TABLE IF EXISTS `tbl_overtime`;

CREATE TABLE `tbl_overtime` (
  `overtime_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `overtime_date` date NOT NULL,
  `overtime_hours` varchar(20) NOT NULL,
  `notes` text,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`overtime_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_payment_methods
#

DROP TABLE IF EXISTS `tbl_payment_methods`;

CREATE TABLE `tbl_payment_methods` (
  `payment_methods_id` int NOT NULL AUTO_INCREMENT,
  `method_name` varchar(64) NOT NULL DEFAULT 'Paypal',
  PRIMARY KEY (`payment_methods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (1, 'Online');
INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (2, 'PayPal');
INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (3, 'Payoneer');
INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (4, 'Bank Transfer');
INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (5, 'Cash ');
INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (9, 'by hand');
INSERT INTO `tbl_payment_methods` (`payment_methods_id`, `method_name`) VALUES (14, 'ASE');


#
# TABLE STRUCTURE FOR: tbl_payments
#

DROP TABLE IF EXISTS `tbl_payments`;

CREATE TABLE `tbl_payments` (
  `payments_id` int NOT NULL AUTO_INCREMENT,
  `invoices_id` int NOT NULL,
  `trans_id` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payer_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_method` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `amount` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `currency` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `notes` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_date` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `month_paid` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `year_paid` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `paid_by` int NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_id` int NOT NULL DEFAULT '0' COMMENT 'account_id means tracking deposit from which account',
  PRIMARY KEY (`payments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_penalty_category
#

DROP TABLE IF EXISTS `tbl_penalty_category`;

CREATE TABLE `tbl_penalty_category` (
  `penalty_id` int NOT NULL AUTO_INCREMENT,
  `penalty_type` varchar(100) NOT NULL,
  `fine_amount` int NOT NULL,
  `penalty_days` varchar(10) NOT NULL,
  PRIMARY KEY (`penalty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_performance_apprisal
#

DROP TABLE IF EXISTS `tbl_performance_apprisal`;

CREATE TABLE `tbl_performance_apprisal` (
  `performance_appraisal_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `general_remarks` text NOT NULL,
  `appraisal_month` varchar(100) NOT NULL,
  `customer_experiece_management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `marketing` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `administration` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `presentation_skill` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `quality_of_work` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `efficiency` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `integrity` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `professionalism` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `team_work` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `critical_thinking` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `conflict_management` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `attendance` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  `ability_to_meed_deadline` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 (S) = Satisfactory, 2 (U) = Unsatisfactory, 3 (N) = Needs Improvement',
  PRIMARY KEY (`performance_appraisal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_performance_indicator
#

DROP TABLE IF EXISTS `tbl_performance_indicator`;

CREATE TABLE `tbl_performance_indicator` (
  `performance_indicator_id` int NOT NULL AUTO_INCREMENT,
  `designations_id` int NOT NULL,
  `customer_experiece_management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `marketing` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `management` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `administration` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `presentation_skill` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `quality_of_work` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `efficiency` tinyint(1) DEFAULT NULL COMMENT 'Technical - 1 = Beginner, 2 = Intermediate, 3 = Advanced, 4 = Expert / Leader',
  `integrity` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `professionalism` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `team_work` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `critical_thinking` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `conflict_management` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `attendance` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  `ability_to_meed_deadline` tinyint(1) DEFAULT NULL COMMENT 'Behavioural - 1 = Beginner, 2 = Intermediate, 3 = Advanced',
  PRIMARY KEY (`performance_indicator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_pinaction
#

DROP TABLE IF EXISTS `tbl_pinaction`;

CREATE TABLE `tbl_pinaction` (
  `pinaction_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `module_id` int NOT NULL,
  `module_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pinaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_priorities
#

DROP TABLE IF EXISTS `tbl_priorities`;

CREATE TABLE `tbl_priorities` (
  `priority` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_priorities` (`priority`) VALUES ('High');
INSERT INTO `tbl_priorities` (`priority`) VALUES ('medium');
INSERT INTO `tbl_priorities` (`priority`) VALUES ('low');


#
# TABLE STRUCTURE FOR: tbl_priority
#

DROP TABLE IF EXISTS `tbl_priority`;

CREATE TABLE `tbl_priority` (
  `priority_id` int NOT NULL AUTO_INCREMENT,
  `priority` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`priority_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (1, 'High');
INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (2, 'Medium');
INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (3, 'Low');
INSERT INTO `tbl_priority` (`priority_id`, `priority`) VALUES (4, 'ok');


#
# TABLE STRUCTURE FOR: tbl_private_chat
#

DROP TABLE IF EXISTS `tbl_private_chat`;

CREATE TABLE `tbl_private_chat` (
  `private_chat_id` int NOT NULL AUTO_INCREMENT,
  `chat_title` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` int NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`private_chat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_private_chat_messages
#

DROP TABLE IF EXISTS `tbl_private_chat_messages`;

CREATE TABLE `tbl_private_chat_messages` (
  `private_chat_messages_id` int NOT NULL AUTO_INCREMENT,
  `private_chat_id` int NOT NULL,
  `user_id` int NOT NULL,
  `message` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `message_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`private_chat_messages_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_private_chat_users
#

DROP TABLE IF EXISTS `tbl_private_chat_users`;

CREATE TABLE `tbl_private_chat_users` (
  `private_chat_users_id` int NOT NULL AUTO_INCREMENT,
  `private_chat_id` int NOT NULL,
  `user_id` int NOT NULL,
  `to_user_id` int NOT NULL,
  `active` int NOT NULL COMMENT '0 == minimize chat,1 == open chat and  2 == close chat ',
  `unread` int NOT NULL,
  `title` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `deleted` int NOT NULL DEFAULT '0' COMMENT 'keep last message id',
  PRIMARY KEY (`private_chat_users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_project
#

DROP TABLE IF EXISTS `tbl_project`;

CREATE TABLE `tbl_project` (
  `project_id` int NOT NULL AUTO_INCREMENT,
  `project_no` varchar(100) DEFAULT NULL,
  `project_name` varchar(100) NOT NULL,
  `category_id` int DEFAULT NULL,
  `client_id` text,
  `progress` varchar(50) NOT NULL,
  `calculate_progress` varchar(50) DEFAULT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `alert_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `project_cost` decimal(18,2) NOT NULL DEFAULT '0.00',
  `demo_url` varchar(100) NOT NULL,
  `project_status` varchar(20) NOT NULL,
  `description` text,
  `notify_client` enum('Yes','No') NOT NULL,
  `timer_status` enum('on','off') DEFAULT NULL,
  `timer_started_by` int DEFAULT NULL,
  `start_time` int DEFAULT NULL,
  `logged_time` int DEFAULT NULL,
  `permission` text,
  `notes` text,
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `hourly_rate` varchar(200) DEFAULT NULL,
  `fixed_rate` varchar(200) DEFAULT NULL,
  `project_settings` text,
  `with_tasks` enum('yes','no') NOT NULL DEFAULT 'no',
  `estimate_hours` varchar(50) DEFAULT NULL,
  `billing_type` varchar(50) DEFAULT NULL,
  `tags` text,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_project` (`project_id`, `project_no`, `project_name`, `category_id`, `client_id`, `progress`, `calculate_progress`, `start_date`, `end_date`, `alert_overdue`, `project_cost`, `demo_url`, `project_status`, `description`, `notify_client`, `timer_status`, `timer_started_by`, `start_time`, `logged_time`, `permission`, `notes`, `created_time`, `hourly_rate`, `fixed_rate`, `project_settings`, `with_tasks`, `estimate_hours`, `billing_type`, `tags`) VALUES (1, '0001', 'Construction Civil Unskilled', 5, '2', '0', NULL, '2025-10-01', '2026-10-31', 0, '8.00', '', 'started', 'unskilled 8 AED per hours', 'Yes', NULL, NULL, NULL, NULL, 'all', NULL, '2025-11-07 19:40:54', '8', NULL, '[\"show_team_members\",\"show_milestones\",\"show_project_tasks\",\"show_project_attachments\",\"show_timesheets\",\"show_project_bugs\",\"show_project_history\",\"show_project_calendar\",\"show_project_comments\",\"show_gantt_chart\",\"show_project_hours\",\"comment_on_project_tasks\",\"show_project_tasks_attachments\",\"show_tasks_hours\",\"show_finance_overview\",\"show_staff_finance_overview\"]', 'no', '0:00', 'project_hours', '');
INSERT INTO `tbl_project` (`project_id`, `project_no`, `project_name`, `category_id`, `client_id`, `progress`, `calculate_progress`, `start_date`, `end_date`, `alert_overdue`, `project_cost`, `demo_url`, `project_status`, `description`, `notify_client`, `timer_status`, `timer_started_by`, `start_time`, `logged_time`, `permission`, `notes`, `created_time`, `hourly_rate`, `fixed_rate`, `project_settings`, `with_tasks`, `estimate_hours`, `billing_type`, `tags`) VALUES (2, '0002', 'Construction Civil Skilled', 4, '2', '0', 'through_project_hours', '2025-10-01', '2026-10-31', 0, '9.50', '', 'started', 'Skilled Labour 9.50 AED per hour&nbsp;', 'Yes', NULL, NULL, NULL, NULL, 'all', NULL, '2025-11-07 19:42:17', '9.50', NULL, '[\"show_team_members\",\"show_milestones\",\"show_project_tasks\",\"show_project_attachments\",\"show_timesheets\",\"show_project_bugs\",\"show_project_history\",\"show_project_calendar\",\"show_project_comments\",\"show_gantt_chart\",\"show_project_hours\",\"comment_on_project_tasks\",\"show_project_tasks_attachments\",\"show_tasks_hours\",\"show_finance_overview\",\"show_staff_finance_overview\"]', 'no', '4000:00', 'project_hours', '');


#
# TABLE STRUCTURE FOR: tbl_project_settings
#

DROP TABLE IF EXISTS `tbl_project_settings`;

CREATE TABLE `tbl_project_settings` (
  `settings_id` int NOT NULL AUTO_INCREMENT,
  `settings` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (1, 'show_team_members', 'view team members');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (2, 'show_milestones', 'view project milestones');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (5, 'show_project_tasks', 'view project tasks');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (6, 'show_project_attachments', 'view project attachments');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (7, 'show_timesheets', 'view project timesheets');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (8, 'show_project_bugs', 'view project bugs');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (9, 'show_project_history', 'view project history');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (10, 'show_project_calendar', 'view project calendars');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (11, 'show_project_comments', 'view project comments');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (13, 'show_gantt_chart', 'view Gantt chart');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (14, 'show_project_hours', 'view project hours');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (15, 'comment_on_project_tasks', 'access To comment on project tasks');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (16, 'show_project_tasks_attachments', 'view task attachments');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (20, 'show_tasks_hours', 'show_tasks_hours');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (21, 'show_finance_overview', 'show_finance_overview');
INSERT INTO `tbl_project_settings` (`settings_id`, `settings`, `description`) VALUES (22, 'show_staff_finance_overview', 'admin and staff can see the price');


#
# TABLE STRUCTURE FOR: tbl_promotions
#

DROP TABLE IF EXISTS `tbl_promotions`;

CREATE TABLE `tbl_promotions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `designation_id` int NOT NULL,
  `from_designations` int NOT NULL,
  `promotion_title` varchar(190) NOT NULL,
  `promotion_date` date NOT NULL,
  `description` varchar(190) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_proposals
#

DROP TABLE IF EXISTS `tbl_proposals`;

CREATE TABLE `tbl_proposals` (
  `proposals_id` int NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `subject` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `module` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `module_id` int DEFAULT '0',
  `proposal_date` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `proposal_month` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `proposal_year` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `due_date` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `alert_overdue` tinyint(1) DEFAULT '0',
  `currency` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `notes` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `tax` int NOT NULL DEFAULT '0',
  `total_tax` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'draft',
  `date_sent` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `proposal_deleted` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `emailed` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `show_client` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'No',
  `convert` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'No',
  `convert_module` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `convert_module_id` int DEFAULT '0',
  `converted_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `discount_type` enum('none','before_tax','after_tax') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'none',
  `discount_percent` int NOT NULL DEFAULT '0',
  `discount_total` decimal(18,2) NOT NULL DEFAULT '0.00',
  `warehouse_id` int DEFAULT NULL,
  `user_id` int NOT NULL DEFAULT '0',
  `adjustment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `show_quantity_as` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `tags` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `allowed_cmments` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'Yes',
  PRIMARY KEY (`proposals_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_proposals_items
#

DROP TABLE IF EXISTS `tbl_proposals_items`;

CREATE TABLE `tbl_proposals_items` (
  `proposals_items_id` int NOT NULL AUTO_INCREMENT,
  `proposals_id` int NOT NULL,
  `saved_items_id` int DEFAULT '0',
  `item_name` varchar(150) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_tax_total` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order` int DEFAULT '0',
  `unit` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`proposals_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_purchase_items
#

DROP TABLE IF EXISTS `tbl_purchase_items`;

CREATE TABLE `tbl_purchase_items` (
  `items_id` int NOT NULL AUTO_INCREMENT,
  `purchase_id` int NOT NULL,
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `item_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `order` int DEFAULT '0',
  `date_saved` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `unit` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `saved_items_id` int DEFAULT '0',
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_purchase_payments
#

DROP TABLE IF EXISTS `tbl_purchase_payments`;

CREATE TABLE `tbl_purchase_payments` (
  `payments_id` int NOT NULL AUTO_INCREMENT,
  `purchase_id` int DEFAULT NULL,
  `trans_id` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_method` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `amount` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `currency` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `notes` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `month_paid` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `year_paid` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `paid_to` int NOT NULL,
  `paid_by` int DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_id` int NOT NULL DEFAULT '0' COMMENT 'account_id means tracking deduct from which account',
  PRIMARY KEY (`payments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_purchases
#

DROP TABLE IF EXISTS `tbl_purchases`;

CREATE TABLE `tbl_purchases` (
  `purchase_id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `update_stock` enum('Yes','No') DEFAULT 'Yes',
  `stock_updated` enum('Yes','No') NOT NULL DEFAULT 'No',
  `status` varchar(20) DEFAULT NULL,
  `emailed` enum('Yes','No') DEFAULT NULL,
  `date_sent` varchar(20) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `warehouse_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `discount_type` enum('none','before_tax','after_tax') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'none',
  `discount_percent` decimal(10,2) DEFAULT NULL,
  `adjustment` decimal(18,2) DEFAULT NULL,
  `discount_total` decimal(18,2) DEFAULT NULL,
  `show_quantity_as` varchar(10) DEFAULT NULL,
  `permission` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_tax` text,
  `tax` decimal(20,2) DEFAULT NULL,
  `notes` text,
  `tags` text,
  PRIMARY KEY (`purchase_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_quotation_details
#

DROP TABLE IF EXISTS `tbl_quotation_details`;

CREATE TABLE `tbl_quotation_details` (
  `quotation_details_id` int NOT NULL AUTO_INCREMENT,
  `quotations_id` int NOT NULL,
  `quotation_form_data` text,
  `quotation_data` text,
  PRIMARY KEY (`quotation_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_quotationforms
#

DROP TABLE IF EXISTS `tbl_quotationforms`;

CREATE TABLE `tbl_quotationforms` (
  `quotationforms_id` int NOT NULL AUTO_INCREMENT,
  `quotationforms_title` varchar(200) NOT NULL,
  `quotationforms_code` text NOT NULL,
  `quotationforms_status` varchar(20) NOT NULL DEFAULT 'enabled' COMMENT 'enabled/disabled',
  `quotations_created_by_id` int NOT NULL,
  `quotationforms_date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`quotationforms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_quotations
#

DROP TABLE IF EXISTS `tbl_quotations`;

CREATE TABLE `tbl_quotations` (
  `quotations_id` int NOT NULL AUTO_INCREMENT,
  `quotations_form_title` varchar(250) NOT NULL,
  `user_id` int DEFAULT NULL,
  `client_id` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(100) DEFAULT NULL,
  `quotations_amount` decimal(10,2) DEFAULT NULL,
  `notes` text,
  `reviewer_id` int DEFAULT NULL,
  `reviewed_date` date DEFAULT NULL,
  `quotations_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quotations_status` varchar(15) DEFAULT 'pending' COMMENT 'completed/pending',
  `is_convert` enum('Yes','No') NOT NULL DEFAULT 'No',
  `convert_module` varchar(20) DEFAULT NULL,
  `convert_module_id` int DEFAULT NULL,
  PRIMARY KEY (`quotations_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_reminders
#

DROP TABLE IF EXISTS `tbl_reminders`;

CREATE TABLE `tbl_reminders` (
  `reminder_id` int NOT NULL AUTO_INCREMENT,
  `description` text,
  `date` datetime NOT NULL,
  `notified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `module` varchar(200) NOT NULL,
  `module_id` int NOT NULL,
  `user_id` varchar(40) NOT NULL,
  `notify_by_email` enum('Yes','No') NOT NULL DEFAULT 'No',
  `created_by` int NOT NULL,
  PRIMARY KEY (`reminder_id`),
  KEY `rel_id` (`module`),
  KEY `rel_type` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_resignations
#

DROP TABLE IF EXISTS `tbl_resignations`;

CREATE TABLE `tbl_resignations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `notice_date` date NOT NULL,
  `resignation_date` date NOT NULL,
  `description` varchar(190) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_return_stock
#

DROP TABLE IF EXISTS `tbl_return_stock`;

CREATE TABLE `tbl_return_stock` (
  `return_stock_id` int NOT NULL AUTO_INCREMENT,
  `module` enum('client','supplier') DEFAULT NULL,
  `module_id` int DEFAULT NULL,
  `main_status` varchar(200) DEFAULT NULL,
  `invoices_id` int DEFAULT NULL,
  `warehouse_id` int DEFAULT NULL,
  `reference_no` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `total` decimal(20,2) DEFAULT NULL,
  `update_stock` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'Yes',
  `status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `emailed` enum('Yes','No') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `date_sent` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `return_stock_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `discount_type` enum('none','before_tax','after_tax') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'none',
  `discount_percent` decimal(10,2) DEFAULT NULL,
  `adjustment` decimal(18,2) DEFAULT NULL,
  `discount_total` decimal(18,2) DEFAULT NULL,
  `show_quantity_as` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `created` timestamp NOT NULL DEFAULT '2019-05-05 10:30:00',
  `total_tax` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `tax` decimal(20,2) DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  PRIMARY KEY (`return_stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_return_stock_items
#

DROP TABLE IF EXISTS `tbl_return_stock_items`;

CREATE TABLE `tbl_return_stock_items` (
  `items_id` int NOT NULL AUTO_INCREMENT,
  `return_stock_id` int NOT NULL,
  `invoice_items_id` int DEFAULT NULL,
  `item_tax_rate` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_tax_name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_tax_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `item_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `order` int DEFAULT '0',
  `date_saved` timestamp NOT NULL DEFAULT '2019-05-05 10:30:00',
  `unit` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `saved_items_id` int DEFAULT '0',
  PRIMARY KEY (`items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_return_stock_payments
#

DROP TABLE IF EXISTS `tbl_return_stock_payments`;

CREATE TABLE `tbl_return_stock_payments` (
  `payments_id` int NOT NULL AUTO_INCREMENT,
  `return_stock_id` int DEFAULT NULL,
  `trans_id` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_method` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `amount` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `currency` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'USD',
  `notes` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `month_paid` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `year_paid` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `module` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `paid_to` int DEFAULT NULL,
  `paid_by` int DEFAULT NULL,
  `created_date` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `account_id` int NOT NULL DEFAULT '0' COMMENT 'account_id means tracking deduct from which account',
  PRIMARY KEY (`payments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_salary_allowance
#

DROP TABLE IF EXISTS `tbl_salary_allowance`;

CREATE TABLE `tbl_salary_allowance` (
  `salary_allowance_id` int NOT NULL AUTO_INCREMENT,
  `salary_template_id` int NOT NULL,
  `allowance_label` varchar(200) NOT NULL,
  `allowance_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_allowance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_salary_allowance` (`salary_allowance_id`, `salary_template_id`, `allowance_label`, `allowance_value`) VALUES (3, 2, 'House Rent Allowance', '300');
INSERT INTO `tbl_salary_allowance` (`salary_allowance_id`, `salary_template_id`, `allowance_label`, `allowance_value`) VALUES (4, 2, 'Medical Allowance', '200');
INSERT INTO `tbl_salary_allowance` (`salary_allowance_id`, `salary_template_id`, `allowance_label`, `allowance_value`) VALUES (5, 3, 'House Rent Allowance', '200');
INSERT INTO `tbl_salary_allowance` (`salary_allowance_id`, `salary_template_id`, `allowance_label`, `allowance_value`) VALUES (6, 3, 'Medical Allowance', '200');


#
# TABLE STRUCTURE FOR: tbl_salary_deduction
#

DROP TABLE IF EXISTS `tbl_salary_deduction`;

CREATE TABLE `tbl_salary_deduction` (
  `salary_deduction_id` int NOT NULL AUTO_INCREMENT,
  `salary_template_id` int NOT NULL,
  `deduction_label` varchar(200) NOT NULL,
  `deduction_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_deduction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_salary_payment
#

DROP TABLE IF EXISTS `tbl_salary_payment`;

CREATE TABLE `tbl_salary_payment` (
  `salary_payment_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `payment_month` varchar(20) NOT NULL,
  `fine_deduction` varchar(200) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `comments` text,
  `paid_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deduct_from` int NOT NULL DEFAULT '0' COMMENT 'deduct from means tracking deduct from which account',
  PRIMARY KEY (`salary_payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_salary_payment_allowance
#

DROP TABLE IF EXISTS `tbl_salary_payment_allowance`;

CREATE TABLE `tbl_salary_payment_allowance` (
  `salary_payment_allowance_id` int NOT NULL AUTO_INCREMENT,
  `salary_payment_id` int NOT NULL,
  `salary_payment_allowance_label` varchar(200) NOT NULL,
  `salary_payment_allowance_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_payment_allowance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_salary_payment_deduction
#

DROP TABLE IF EXISTS `tbl_salary_payment_deduction`;

CREATE TABLE `tbl_salary_payment_deduction` (
  `salary_payment_deduction` int NOT NULL AUTO_INCREMENT,
  `salary_payment_id` int NOT NULL,
  `salary_payment_deduction_label` varchar(200) NOT NULL,
  `salary_payment_deduction_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_payment_deduction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_salary_payment_details
#

DROP TABLE IF EXISTS `tbl_salary_payment_details`;

CREATE TABLE `tbl_salary_payment_details` (
  `salary_payment_details_id` int NOT NULL AUTO_INCREMENT,
  `salary_payment_id` int NOT NULL,
  `salary_payment_details_label` varchar(200) NOT NULL,
  `salary_payment_details_value` varchar(200) NOT NULL,
  PRIMARY KEY (`salary_payment_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_salary_payslip
#

DROP TABLE IF EXISTS `tbl_salary_payslip`;

CREATE TABLE `tbl_salary_payslip` (
  `payslip_id` int NOT NULL AUTO_INCREMENT,
  `payslip_number` varchar(100) DEFAULT NULL,
  `salary_payment_id` int NOT NULL,
  `payslip_generate_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payslip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_salary_template
#

DROP TABLE IF EXISTS `tbl_salary_template`;

CREATE TABLE `tbl_salary_template` (
  `salary_template_id` int NOT NULL AUTO_INCREMENT,
  `salary_grade` varchar(200) NOT NULL,
  `basic_salary` varchar(200) NOT NULL,
  `overtime_salary` varchar(100) NOT NULL,
  PRIMARY KEY (`salary_template_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_salary_template` (`salary_template_id`, `salary_grade`, `basic_salary`, `overtime_salary`) VALUES (2, '1200', '700', '4.5');
INSERT INTO `tbl_salary_template` (`salary_template_id`, `salary_grade`, `basic_salary`, `overtime_salary`) VALUES (3, 'Admin - Manager', '1100', '');


#
# TABLE STRUCTURE FOR: tbl_saved_items
#

DROP TABLE IF EXISTS `tbl_saved_items`;

CREATE TABLE `tbl_saved_items` (
  `saved_items_id` int NOT NULL AUTO_INCREMENT,
  `item_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT 'Item Name',
  `code` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `manufacturer_id` int DEFAULT NULL,
  `barcode_symbology` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `upload_file` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `cost_price` decimal(20,2) NOT NULL DEFAULT '0.00',
  `item_desc` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `unit_cost` decimal(18,2) DEFAULT '0.00',
  `customer_group_id` int NOT NULL DEFAULT '0',
  `unit_type` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `tax_rates_id` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `item_tax_rate` decimal(18,2) DEFAULT '0.00',
  `item_tax_total` decimal(18,2) DEFAULT '0.00',
  `quantity` decimal(18,2) DEFAULT '0.00',
  `total_cost` decimal(18,2) DEFAULT '0.00',
  `hsn_code` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`saved_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_sent
#

DROP TABLE IF EXISTS `tbl_sent`;

CREATE TABLE `tbl_sent` (
  `sent_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `to` varchar(100) NOT NULL,
  `subject` varchar(300) NOT NULL,
  `message_body` text NOT NULL,
  `attach_file` text,
  `attach_file_path` text,
  `attach_filename` text,
  `message_time` datetime NOT NULL,
  `deleted` enum('Yes','No') NOT NULL DEFAULT 'No',
  PRIMARY KEY (`sent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_sessions
#

DROP TABLE IF EXISTS `tbl_sessions`;

CREATE TABLE `tbl_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18o8v11407frq9te60mbir1jgijtgl93', '5.31.213.51', 1772094668, '__ci_last_regenerate|i:1772094030;menu_active_id|a:2:{i:0;s:2:\"24\";i:1;s:1:\"0\";}url|s:19:\"admin/user/userList\";user_roll|a:10:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772087754;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6n86ju9fddtiteoaop78q9tjoqdnauig', '5.31.213.51', 1772087730, '__ci_last_regenerate|i:1772087558;menu_active_id|a:3:{i:0;s:2:\"94\";i:1;s:2:\"89\";i:2;s:1:\"0\";}url|s:32:\"admin/payroll/set_salary_details\";user_roll|a:154:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-05-18 10:49:03\";s:6:\"status\";s:1:\"1\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:4:\"user\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:17:\"transactions_menu\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2018-05-13 06:27:58\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:28:33\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-05-13 06:28:37\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-05-13 06:28:40\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-05-13 06:28:44\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-05-13 06:28:47\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-05-13 06:28:51\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-04 12:49:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-05-13 06:28:59\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:09:40\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2019-05-01 10:22:56\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-25 12:48:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-31 06:43:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"29\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"33\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"34\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"35\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"36\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"37\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:29:51\";s:6:\"status\";s:1:\"1\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 19:12:23\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-03-07 00:45:25\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:5:\"stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-05 10:19:30\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-05 07:53:11\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:11:\"credit_note\";s:4:\"link\";s:17:\"admin/credit_note\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-09 20:32:05\";s:6:\"status\";s:1:\"1\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"157\";s:5:\"label\";s:20:\"credit_note_settings\";s:4:\"link\";s:26:\"admin/settings/credit_note\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"proposals_settings\";s:4:\"link\";s:24:\"admin/settings/proposals\";s:4:\"icon\";s:16:\"fa fa-fw fa-leaf\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:17:\"projects_settings\";s:4:\"link\";s:23:\"admin/settings/projects\";s:4:\"icon\";s:25:\"fa fa-fw fa-folder-open-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:4:\"tags\";s:4:\"link\";s:19:\"admin/settings/tags\";s:4:\"icon\";s:16:\"fa fa-fw fa-tags\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"lead_form\";s:4:\"link\";s:25:\"admin/leads/all_lead_form\";s:4:\"icon\";s:18:\"fa fa-fw fa-rocket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:21:\"transactions_settings\";s:4:\"link\";s:27:\"admin/settings/transactions\";s:4:\"icon\";s:22:\"fa fa-fw fa-building-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:12:\"sms_settings\";s:4:\"link\";s:27:\"admin/settings/sms_settings\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:142;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"164\";s:5:\"label\";s:9:\"pos_sales\";s:4:\"link\";s:23:\"admin/invoice/pos_sales\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2021-10-15 18:53:10\";s:6:\"status\";s:1:\"1\";}i:143;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"186\";s:5:\"label\";s:9:\"warehouse\";s:4:\"link\";s:22:\"admin/warehouse/manage\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2021-10-18 03:24:24\";s:6:\"status\";s:1:\"1\";}i:144;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"187\";s:5:\"label\";s:12:\"transferItem\";s:4:\"link\";s:24:\"admin/items/transferItem\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-10-14 05:56:08\";s:6:\"status\";s:1:\"1\";}i:145;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"203\";s:5:\"label\";s:13:\"award_setting\";s:4:\"link\";s:20:\"admin/settings/award\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2022-01-18 23:51:40\";s:6:\"status\";s:1:\"2\";}i:146;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"204\";s:5:\"label\";s:18:\"award_rule_setting\";s:4:\"link\";s:34:\"admin/settings/award_rule_settingh\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2022-01-19 03:53:50\";s:6:\"status\";s:1:\"2\";}i:147;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"205\";s:5:\"label\";s:22:\"award_program_settings\";s:4:\"link\";s:37:\"admin/settings/award_program_settings\";s:4:\"icon\";s:9:\"fa fa-cog\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2022-01-20 03:17:30\";s:6:\"status\";s:1:\"2\";}i:148;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"206\";s:5:\"label\";s:19:\"client_award_points\";s:4:\"link\";s:27:\"admin/invoice/client_awards\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2022-01-20 19:39:41\";s:6:\"status\";s:1:\"1\";}i:149;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"207\";s:5:\"label\";s:20:\"best_selling_product\";s:4:\"link\";s:18:\"admin/best_selling\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2022-01-21 00:43:52\";s:6:\"status\";s:1:\"1\";}i:150;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"209\";s:5:\"label\";s:7:\"warning\";s:4:\"link\";s:13:\"admin/warning\";s:4:\"icon\";s:13:\"fa fa-warning\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2022-08-07 06:47:01\";s:6:\"status\";s:1:\"1\";}i:151;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"210\";s:5:\"label\";s:9:\"promotion\";s:4:\"link\";s:15:\"admin/promotion\";s:4:\"icon\";s:21:\"fa fa-arrow-circle-up\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2022-08-07 06:49:28\";s:6:\"status\";s:1:\"1\";}i:152;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"211\";s:5:\"label\";s:11:\"termination\";s:4:\"link\";s:17:\"admin/termination\";s:4:\"icon\";s:12:\"fa fa-eraser\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2022-08-07 06:50:45\";s:6:\"status\";s:1:\"1\";}i:153;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"212\";s:5:\"label\";s:11:\"resignation\";s:4:\"link\";s:17:\"admin/resignation\";s:4:\"icon\";s:14:\"fa fa-scissors\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2022-08-07 06:54:31\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772085113;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b1cfoj7njbas3t3ogc29unoidrc8n8lo', '5.31.213.51', 1772093710, '__ci_last_regenerate|i:1772093710;menu_active_id|a:3:{i:0;s:2:\"98\";i:1;s:2:\"89\";i:2;s:1:\"0\";}url|s:32:\"admin/payroll/add_advance_salary\";user_roll|a:154:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-05-18 10:49:03\";s:6:\"status\";s:1:\"1\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:4:\"user\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:17:\"transactions_menu\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2018-05-13 06:27:58\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:28:33\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-05-13 06:28:37\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-05-13 06:28:40\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-05-13 06:28:44\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-05-13 06:28:47\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-05-13 06:28:51\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-04 12:49:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-05-13 06:28:59\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:09:40\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2019-05-01 10:22:56\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-25 12:48:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-31 06:43:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"29\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"33\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"34\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"35\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"36\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"37\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:29:51\";s:6:\"status\";s:1:\"1\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 19:12:23\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-03-07 00:45:25\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:5:\"stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-05 10:19:30\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-05 07:53:11\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:11:\"credit_note\";s:4:\"link\";s:17:\"admin/credit_note\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-09 20:32:05\";s:6:\"status\";s:1:\"1\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"157\";s:5:\"label\";s:20:\"credit_note_settings\";s:4:\"link\";s:26:\"admin/settings/credit_note\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"proposals_settings\";s:4:\"link\";s:24:\"admin/settings/proposals\";s:4:\"icon\";s:16:\"fa fa-fw fa-leaf\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:17:\"projects_settings\";s:4:\"link\";s:23:\"admin/settings/projects\";s:4:\"icon\";s:25:\"fa fa-fw fa-folder-open-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:4:\"tags\";s:4:\"link\";s:19:\"admin/settings/tags\";s:4:\"icon\";s:16:\"fa fa-fw fa-tags\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"lead_form\";s:4:\"link\";s:25:\"admin/leads/all_lead_form\";s:4:\"icon\";s:18:\"fa fa-fw fa-rocket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:21:\"transactions_settings\";s:4:\"link\";s:27:\"admin/settings/transactions\";s:4:\"icon\";s:22:\"fa fa-fw fa-building-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:12:\"sms_settings\";s:4:\"link\";s:27:\"admin/settings/sms_settings\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:142;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"164\";s:5:\"label\";s:9:\"pos_sales\";s:4:\"link\";s:23:\"admin/invoice/pos_sales\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2021-10-15 18:53:10\";s:6:\"status\";s:1:\"1\";}i:143;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"186\";s:5:\"label\";s:9:\"warehouse\";s:4:\"link\";s:22:\"admin/warehouse/manage\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2021-10-18 03:24:24\";s:6:\"status\";s:1:\"1\";}i:144;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"187\";s:5:\"label\";s:12:\"transferItem\";s:4:\"link\";s:24:\"admin/items/transferItem\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-10-14 05:56:08\";s:6:\"status\";s:1:\"1\";}i:145;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"203\";s:5:\"label\";s:13:\"award_setting\";s:4:\"link\";s:20:\"admin/settings/award\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2022-01-18 23:51:40\";s:6:\"status\";s:1:\"2\";}i:146;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"204\";s:5:\"label\";s:18:\"award_rule_setting\";s:4:\"link\";s:34:\"admin/settings/award_rule_settingh\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2022-01-19 03:53:50\";s:6:\"status\";s:1:\"2\";}i:147;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"205\";s:5:\"label\";s:22:\"award_program_settings\";s:4:\"link\";s:37:\"admin/settings/award_program_settings\";s:4:\"icon\";s:9:\"fa fa-cog\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2022-01-20 03:17:30\";s:6:\"status\";s:1:\"2\";}i:148;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"206\";s:5:\"label\";s:19:\"client_award_points\";s:4:\"link\";s:27:\"admin/invoice/client_awards\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2022-01-20 19:39:41\";s:6:\"status\";s:1:\"1\";}i:149;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"207\";s:5:\"label\";s:20:\"best_selling_product\";s:4:\"link\";s:18:\"admin/best_selling\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2022-01-21 00:43:52\";s:6:\"status\";s:1:\"1\";}i:150;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"209\";s:5:\"label\";s:7:\"warning\";s:4:\"link\";s:13:\"admin/warning\";s:4:\"icon\";s:13:\"fa fa-warning\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2022-08-07 06:47:01\";s:6:\"status\";s:1:\"1\";}i:151;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"210\";s:5:\"label\";s:9:\"promotion\";s:4:\"link\";s:15:\"admin/promotion\";s:4:\"icon\";s:21:\"fa fa-arrow-circle-up\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2022-08-07 06:49:28\";s:6:\"status\";s:1:\"1\";}i:152;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"211\";s:5:\"label\";s:11:\"termination\";s:4:\"link\";s:17:\"admin/termination\";s:4:\"icon\";s:12:\"fa fa-eraser\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2022-08-07 06:50:45\";s:6:\"status\";s:1:\"1\";}i:153;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"212\";s:5:\"label\";s:11:\"resignation\";s:4:\"link\";s:17:\"admin/resignation\";s:4:\"icon\";s:14:\"fa fa-scissors\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2022-08-07 06:54:31\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772087754;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('es9mep4uh67gmp7maj9ckg664l7nirjp', '103.215.54.198', 1772094667, '__ci_last_regenerate|i:1772094424;user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772094437;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";url|s:33:\"admin/dashboard/pinned_menu_items\";menu_active_id|a:2:{i:0;s:2:\"26\";i:1;s:1:\"0\";}user_roll|a:154:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-05-18 10:49:03\";s:6:\"status\";s:1:\"1\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:4:\"user\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:17:\"transactions_menu\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2018-05-13 06:27:58\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:28:33\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-05-13 06:28:37\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-05-13 06:28:40\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-05-13 06:28:44\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-05-13 06:28:47\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-05-13 06:28:51\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-04 12:49:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-05-13 06:28:59\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:09:40\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2019-05-01 10:22:56\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-25 12:48:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-31 06:43:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"29\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"33\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"34\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"35\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"36\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"37\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:29:51\";s:6:\"status\";s:1:\"1\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 19:12:23\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-03-07 00:45:25\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:5:\"stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-05 10:19:30\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-05 07:53:11\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:11:\"credit_note\";s:4:\"link\";s:17:\"admin/credit_note\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-09 20:32:05\";s:6:\"status\";s:1:\"1\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"157\";s:5:\"label\";s:20:\"credit_note_settings\";s:4:\"link\";s:26:\"admin/settings/credit_note\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"proposals_settings\";s:4:\"link\";s:24:\"admin/settings/proposals\";s:4:\"icon\";s:16:\"fa fa-fw fa-leaf\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:17:\"projects_settings\";s:4:\"link\";s:23:\"admin/settings/projects\";s:4:\"icon\";s:25:\"fa fa-fw fa-folder-open-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:4:\"tags\";s:4:\"link\";s:19:\"admin/settings/tags\";s:4:\"icon\";s:16:\"fa fa-fw fa-tags\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"lead_form\";s:4:\"link\";s:25:\"admin/leads/all_lead_form\";s:4:\"icon\";s:18:\"fa fa-fw fa-rocket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:21:\"transactions_settings\";s:4:\"link\";s:27:\"admin/settings/transactions\";s:4:\"icon\";s:22:\"fa fa-fw fa-building-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:12:\"sms_settings\";s:4:\"link\";s:27:\"admin/settings/sms_settings\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:142;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"164\";s:5:\"label\";s:9:\"pos_sales\";s:4:\"link\";s:23:\"admin/invoice/pos_sales\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2021-10-15 18:53:10\";s:6:\"status\";s:1:\"1\";}i:143;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"186\";s:5:\"label\";s:9:\"warehouse\";s:4:\"link\";s:22:\"admin/warehouse/manage\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2021-10-18 03:24:24\";s:6:\"status\";s:1:\"1\";}i:144;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"187\";s:5:\"label\";s:12:\"transferItem\";s:4:\"link\";s:24:\"admin/items/transferItem\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-10-14 05:56:08\";s:6:\"status\";s:1:\"1\";}i:145;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"203\";s:5:\"label\";s:13:\"award_setting\";s:4:\"link\";s:20:\"admin/settings/award\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2022-01-18 23:51:40\";s:6:\"status\";s:1:\"2\";}i:146;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"204\";s:5:\"label\";s:18:\"award_rule_setting\";s:4:\"link\";s:34:\"admin/settings/award_rule_settingh\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2022-01-19 03:53:50\";s:6:\"status\";s:1:\"2\";}i:147;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"205\";s:5:\"label\";s:22:\"award_program_settings\";s:4:\"link\";s:37:\"admin/settings/award_program_settings\";s:4:\"icon\";s:9:\"fa fa-cog\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2022-01-20 03:17:30\";s:6:\"status\";s:1:\"2\";}i:148;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"206\";s:5:\"label\";s:19:\"client_award_points\";s:4:\"link\";s:27:\"admin/invoice/client_awards\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2022-01-20 19:39:41\";s:6:\"status\";s:1:\"1\";}i:149;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"207\";s:5:\"label\";s:20:\"best_selling_product\";s:4:\"link\";s:18:\"admin/best_selling\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2022-01-21 00:43:52\";s:6:\"status\";s:1:\"1\";}i:150;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"209\";s:5:\"label\";s:7:\"warning\";s:4:\"link\";s:13:\"admin/warning\";s:4:\"icon\";s:13:\"fa fa-warning\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2022-08-07 06:47:01\";s:6:\"status\";s:1:\"1\";}i:151;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"210\";s:5:\"label\";s:9:\"promotion\";s:4:\"link\";s:15:\"admin/promotion\";s:4:\"icon\";s:21:\"fa fa-arrow-circle-up\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2022-08-07 06:49:28\";s:6:\"status\";s:1:\"1\";}i:152;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"211\";s:5:\"label\";s:11:\"termination\";s:4:\"link\";s:17:\"admin/termination\";s:4:\"icon\";s:12:\"fa fa-eraser\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2022-08-07 06:50:45\";s:6:\"status\";s:1:\"1\";}i:153;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"212\";s:5:\"label\";s:11:\"resignation\";s:4:\"link\";s:17:\"admin/resignation\";s:4:\"icon\";s:14:\"fa fa-scissors\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2022-08-07 06:54:31\";s:6:\"status\";s:1:\"1\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fkgj53rmq012sjb8om1q63al8vnn9jqp', '5.31.213.51', 1772093399, '__ci_last_regenerate|i:1772093399;menu_active_id|a:2:{i:0;s:1:\"1\";i:1;s:1:\"0\";}url|s:15:\"admin/dashboard\";user_roll|a:154:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-05-18 10:49:03\";s:6:\"status\";s:1:\"1\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:4:\"user\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:17:\"transactions_menu\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2018-05-13 06:27:58\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:28:33\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-05-13 06:28:37\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-05-13 06:28:40\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-05-13 06:28:44\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-05-13 06:28:47\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-05-13 06:28:51\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-04 12:49:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-05-13 06:28:59\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:09:40\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2019-05-01 10:22:56\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-25 12:48:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-31 06:43:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"29\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"33\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"34\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"35\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"36\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"37\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:29:51\";s:6:\"status\";s:1:\"1\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 19:12:23\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-03-07 00:45:25\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:5:\"stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-05 10:19:30\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-05 07:53:11\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:11:\"credit_note\";s:4:\"link\";s:17:\"admin/credit_note\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-09 20:32:05\";s:6:\"status\";s:1:\"1\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"157\";s:5:\"label\";s:20:\"credit_note_settings\";s:4:\"link\";s:26:\"admin/settings/credit_note\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"proposals_settings\";s:4:\"link\";s:24:\"admin/settings/proposals\";s:4:\"icon\";s:16:\"fa fa-fw fa-leaf\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:17:\"projects_settings\";s:4:\"link\";s:23:\"admin/settings/projects\";s:4:\"icon\";s:25:\"fa fa-fw fa-folder-open-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:4:\"tags\";s:4:\"link\";s:19:\"admin/settings/tags\";s:4:\"icon\";s:16:\"fa fa-fw fa-tags\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"lead_form\";s:4:\"link\";s:25:\"admin/leads/all_lead_form\";s:4:\"icon\";s:18:\"fa fa-fw fa-rocket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:21:\"transactions_settings\";s:4:\"link\";s:27:\"admin/settings/transactions\";s:4:\"icon\";s:22:\"fa fa-fw fa-building-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:12:\"sms_settings\";s:4:\"link\";s:27:\"admin/settings/sms_settings\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:142;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"164\";s:5:\"label\";s:9:\"pos_sales\";s:4:\"link\";s:23:\"admin/invoice/pos_sales\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2021-10-15 18:53:10\";s:6:\"status\";s:1:\"1\";}i:143;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"186\";s:5:\"label\";s:9:\"warehouse\";s:4:\"link\";s:22:\"admin/warehouse/manage\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2021-10-18 03:24:24\";s:6:\"status\";s:1:\"1\";}i:144;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"187\";s:5:\"label\";s:12:\"transferItem\";s:4:\"link\";s:24:\"admin/items/transferItem\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-10-14 05:56:08\";s:6:\"status\";s:1:\"1\";}i:145;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"203\";s:5:\"label\";s:13:\"award_setting\";s:4:\"link\";s:20:\"admin/settings/award\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2022-01-18 23:51:40\";s:6:\"status\";s:1:\"2\";}i:146;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"204\";s:5:\"label\";s:18:\"award_rule_setting\";s:4:\"link\";s:34:\"admin/settings/award_rule_settingh\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2022-01-19 03:53:50\";s:6:\"status\";s:1:\"2\";}i:147;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"205\";s:5:\"label\";s:22:\"award_program_settings\";s:4:\"link\";s:37:\"admin/settings/award_program_settings\";s:4:\"icon\";s:9:\"fa fa-cog\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2022-01-20 03:17:30\";s:6:\"status\";s:1:\"2\";}i:148;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"206\";s:5:\"label\";s:19:\"client_award_points\";s:4:\"link\";s:27:\"admin/invoice/client_awards\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2022-01-20 19:39:41\";s:6:\"status\";s:1:\"1\";}i:149;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"207\";s:5:\"label\";s:20:\"best_selling_product\";s:4:\"link\";s:18:\"admin/best_selling\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2022-01-21 00:43:52\";s:6:\"status\";s:1:\"1\";}i:150;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"209\";s:5:\"label\";s:7:\"warning\";s:4:\"link\";s:13:\"admin/warning\";s:4:\"icon\";s:13:\"fa fa-warning\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2022-08-07 06:47:01\";s:6:\"status\";s:1:\"1\";}i:151;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"210\";s:5:\"label\";s:9:\"promotion\";s:4:\"link\";s:15:\"admin/promotion\";s:4:\"icon\";s:21:\"fa fa-arrow-circle-up\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2022-08-07 06:49:28\";s:6:\"status\";s:1:\"1\";}i:152;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"211\";s:5:\"label\";s:11:\"termination\";s:4:\"link\";s:17:\"admin/termination\";s:4:\"icon\";s:12:\"fa fa-eraser\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2022-08-07 06:50:45\";s:6:\"status\";s:1:\"1\";}i:153;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"212\";s:5:\"label\";s:11:\"resignation\";s:4:\"link\";s:17:\"admin/resignation\";s:4:\"icon\";s:14:\"fa fa-scissors\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2022-08-07 06:54:31\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772087754;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gkpemdplsg03ic3t6nvvoo1lam68cg97', '5.31.213.51', 1772092972, '__ci_last_regenerate|i:1772092972;menu_active_id|a:3:{i:0;s:2:\"94\";i:1;s:2:\"89\";i:2;s:1:\"0\";}url|s:33:\"admin/payroll/salary_templateList\";user_roll|a:10:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772087754;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m1ibapsbcoaiud2g568e4rg6s2703o3s', '5.31.213.51', 1772094030, '__ci_last_regenerate|i:1772094030;menu_active_id|a:3:{i:0;s:2:\"98\";i:1;s:2:\"89\";i:2;s:1:\"0\";}url|s:38:\"admin/payroll/advance_salary_details/2\";user_roll|a:154:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-05-18 10:49:03\";s:6:\"status\";s:1:\"1\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:4:\"user\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:17:\"transactions_menu\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2018-05-13 06:27:58\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:28:33\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-05-13 06:28:37\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-05-13 06:28:40\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-05-13 06:28:44\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-05-13 06:28:47\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-05-13 06:28:51\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-04 12:49:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-05-13 06:28:59\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:09:40\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2019-05-01 10:22:56\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-25 12:48:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-31 06:43:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"29\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"33\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"34\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"35\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"36\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"37\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:29:51\";s:6:\"status\";s:1:\"1\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 19:12:23\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-03-07 00:45:25\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:5:\"stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-05 10:19:30\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-05 07:53:11\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:11:\"credit_note\";s:4:\"link\";s:17:\"admin/credit_note\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-09 20:32:05\";s:6:\"status\";s:1:\"1\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"157\";s:5:\"label\";s:20:\"credit_note_settings\";s:4:\"link\";s:26:\"admin/settings/credit_note\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"proposals_settings\";s:4:\"link\";s:24:\"admin/settings/proposals\";s:4:\"icon\";s:16:\"fa fa-fw fa-leaf\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:17:\"projects_settings\";s:4:\"link\";s:23:\"admin/settings/projects\";s:4:\"icon\";s:25:\"fa fa-fw fa-folder-open-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:4:\"tags\";s:4:\"link\";s:19:\"admin/settings/tags\";s:4:\"icon\";s:16:\"fa fa-fw fa-tags\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"lead_form\";s:4:\"link\";s:25:\"admin/leads/all_lead_form\";s:4:\"icon\";s:18:\"fa fa-fw fa-rocket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:21:\"transactions_settings\";s:4:\"link\";s:27:\"admin/settings/transactions\";s:4:\"icon\";s:22:\"fa fa-fw fa-building-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:12:\"sms_settings\";s:4:\"link\";s:27:\"admin/settings/sms_settings\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:142;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"164\";s:5:\"label\";s:9:\"pos_sales\";s:4:\"link\";s:23:\"admin/invoice/pos_sales\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2021-10-15 18:53:10\";s:6:\"status\";s:1:\"1\";}i:143;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"186\";s:5:\"label\";s:9:\"warehouse\";s:4:\"link\";s:22:\"admin/warehouse/manage\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2021-10-18 03:24:24\";s:6:\"status\";s:1:\"1\";}i:144;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"187\";s:5:\"label\";s:12:\"transferItem\";s:4:\"link\";s:24:\"admin/items/transferItem\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-10-14 05:56:08\";s:6:\"status\";s:1:\"1\";}i:145;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"203\";s:5:\"label\";s:13:\"award_setting\";s:4:\"link\";s:20:\"admin/settings/award\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2022-01-18 23:51:40\";s:6:\"status\";s:1:\"2\";}i:146;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"204\";s:5:\"label\";s:18:\"award_rule_setting\";s:4:\"link\";s:34:\"admin/settings/award_rule_settingh\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2022-01-19 03:53:50\";s:6:\"status\";s:1:\"2\";}i:147;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"205\";s:5:\"label\";s:22:\"award_program_settings\";s:4:\"link\";s:37:\"admin/settings/award_program_settings\";s:4:\"icon\";s:9:\"fa fa-cog\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2022-01-20 03:17:30\";s:6:\"status\";s:1:\"2\";}i:148;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"206\";s:5:\"label\";s:19:\"client_award_points\";s:4:\"link\";s:27:\"admin/invoice/client_awards\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2022-01-20 19:39:41\";s:6:\"status\";s:1:\"1\";}i:149;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"207\";s:5:\"label\";s:20:\"best_selling_product\";s:4:\"link\";s:18:\"admin/best_selling\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2022-01-21 00:43:52\";s:6:\"status\";s:1:\"1\";}i:150;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"209\";s:5:\"label\";s:7:\"warning\";s:4:\"link\";s:13:\"admin/warning\";s:4:\"icon\";s:13:\"fa fa-warning\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2022-08-07 06:47:01\";s:6:\"status\";s:1:\"1\";}i:151;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"210\";s:5:\"label\";s:9:\"promotion\";s:4:\"link\";s:15:\"admin/promotion\";s:4:\"icon\";s:21:\"fa fa-arrow-circle-up\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2022-08-07 06:49:28\";s:6:\"status\";s:1:\"1\";}i:152;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"211\";s:5:\"label\";s:11:\"termination\";s:4:\"link\";s:17:\"admin/termination\";s:4:\"icon\";s:12:\"fa fa-eraser\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2022-08-07 06:50:45\";s:6:\"status\";s:1:\"1\";}i:153;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"212\";s:5:\"label\";s:11:\"resignation\";s:4:\"link\";s:17:\"admin/resignation\";s:4:\"icon\";s:14:\"fa fa-scissors\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2022-08-07 06:54:31\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772087754;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pd5ql3bos19u6mdfgg5b8ocn88kt6l1r', '49.44.87.228', 1772094458, '__ci_last_regenerate|i:1772094457;menu_active_id|a:2:{i:0;s:2:\"25\";i:1;s:1:\"0\";}url|s:14:\"admin/settings\";user_roll|a:154:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:10;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"21\";s:5:\"label\";s:10:\"quotations\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-paste\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:11;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"22\";s:5:\"label\";s:15:\"quotations_list\";s:4:\"link\";s:16:\"admin/quotations\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-05-18 10:49:03\";s:6:\"status\";s:1:\"1\";}i:12;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"23\";s:5:\"label\";s:15:\"quotations_form\";s:4:\"link\";s:32:\"admin/quotations/quotations_form\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"21\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:13;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"24\";s:5:\"label\";s:4:\"user\";s:4:\"link\";s:20:\"admin/user/user_list\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:14;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"25\";s:5:\"label\";s:8:\"settings\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:10:\"fa fa-cogs\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:15;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"26\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:14:\"fa fa-database\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:16;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"29\";s:5:\"label\";s:17:\"transactions_menu\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2018-05-13 06:27:58\";s:6:\"status\";s:1:\"1\";}i:17;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"30\";s:5:\"label\";s:7:\"deposit\";s:4:\"link\";s:26:\"admin/transactions/deposit\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:28:33\";s:6:\"status\";s:1:\"1\";}i:18;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"31\";s:5:\"label\";s:7:\"expense\";s:4:\"link\";s:26:\"admin/transactions/expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-05-13 06:28:37\";s:6:\"status\";s:1:\"1\";}i:19;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"32\";s:5:\"label\";s:8:\"transfer\";s:4:\"link\";s:27:\"admin/transactions/transfer\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-05-13 06:28:40\";s:6:\"status\";s:1:\"1\";}i:20;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"33\";s:5:\"label\";s:19:\"transactions_report\";s:4:\"link\";s:38:\"admin/transactions/transactions_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-05-13 06:28:44\";s:6:\"status\";s:1:\"1\";}i:21;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"34\";s:5:\"label\";s:13:\"balance_sheet\";s:4:\"link\";s:32:\"admin/transactions/balance_sheet\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-05-13 06:28:47\";s:6:\"status\";s:1:\"1\";}i:22;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"36\";s:5:\"label\";s:9:\"bank_cash\";s:4:\"link\";s:28:\"admin/account/manage_account\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-05-13 06:28:51\";s:6:\"status\";s:1:\"1\";}i:23;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"39\";s:5:\"label\";s:5:\"items\";s:4:\"link\";s:22:\"admin/items/items_list\";s:4:\"icon\";s:10:\"fa fa-cube\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2019-05-04 12:49:50\";s:6:\"status\";s:1:\"1\";}i:24;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"42\";s:5:\"label\";s:6:\"report\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:25;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"43\";s:5:\"label\";s:17:\"account_statement\";s:4:\"link\";s:30:\"admin/report/account_statement\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:26;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"44\";s:5:\"label\";s:13:\"income_report\";s:4:\"link\";s:26:\"admin/report/income_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:27;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"45\";s:5:\"label\";s:14:\"expense_report\";s:4:\"link\";s:27:\"admin/report/expense_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:28;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"46\";s:5:\"label\";s:14:\"income_expense\";s:4:\"link\";s:27:\"admin/report/income_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:29;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"47\";s:5:\"label\";s:16:\"date_wise_report\";s:4:\"link\";s:29:\"admin/report/date_wise_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:30;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"48\";s:5:\"label\";s:10:\"all_income\";s:4:\"link\";s:23:\"admin/report/all_income\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:31;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"49\";s:5:\"label\";s:11:\"all_expense\";s:4:\"link\";s:24:\"admin/report/all_expense\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:32;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"50\";s:5:\"label\";s:15:\"all_transaction\";s:4:\"link\";s:28:\"admin/report/all_transaction\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:33;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"51\";s:5:\"label\";s:17:\"recurring_invoice\";s:4:\"link\";s:31:\"admin/invoice/recurring_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:34;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"52\";s:5:\"label\";s:15:\"transfer_report\";s:4:\"link\";s:34:\"admin/transactions/transfer_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"29\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-05-13 06:28:59\";s:6:\"status\";s:1:\"1\";}i:35;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"53\";s:5:\"label\";s:15:\"report_by_month\";s:4:\"link\";s:28:\"admin/report/report_by_month\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"146\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:36;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"54\";s:5:\"label\";s:5:\"tasks\";s:4:\"link\";s:20:\"admin/tasks/all_task\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:37;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"55\";s:5:\"label\";s:5:\"leads\";s:4:\"link\";s:11:\"admin/leads\";s:4:\"icon\";s:12:\"fa fa-rocket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:38;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"56\";s:5:\"label\";s:13:\"opportunities\";s:4:\"link\";s:19:\"admin/opportunities\";s:4:\"icon\";s:12:\"fa fa-filter\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:39;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"57\";s:5:\"label\";s:8:\"projects\";s:4:\"link\";s:14:\"admin/projects\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:40;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"58\";s:5:\"label\";s:4:\"bugs\";s:4:\"link\";s:10:\"admin/bugs\";s:4:\"icon\";s:9:\"fa fa-bug\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:41;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"59\";s:5:\"label\";s:7:\"project\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-folder-open-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:42;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"60\";s:5:\"label\";s:12:\"tasks_report\";s:4:\"link\";s:25:\"admin/report/tasks_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:43;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"61\";s:5:\"label\";s:11:\"bugs_report\";s:4:\"link\";s:24:\"admin/report/bugs_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:44;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"62\";s:5:\"label\";s:14:\"tickets_report\";s:4:\"link\";s:27:\"admin/report/tickets_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:09:39\";s:6:\"status\";s:1:\"1\";}i:45;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"63\";s:5:\"label\";s:13:\"client_report\";s:4:\"link\";s:26:\"admin/report/client_report\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2018-01-07 01:09:40\";s:6:\"status\";s:1:\"1\";}i:46;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"66\";s:5:\"label\";s:16:\"tasks_assignment\";s:4:\"link\";s:29:\"admin/report/tasks_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:47;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"67\";s:5:\"label\";s:15:\"bugs_assignment\";s:4:\"link\";s:28:\"admin/report/bugs_assignment\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:48;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"68\";s:5:\"label\";s:14:\"project_report\";s:4:\"link\";s:27:\"admin/report/project_report\";s:4:\"icon\";s:18:\"fa fa-dot-circle-o\";s:6:\"parent\";s:2:\"59\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:49;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"69\";s:5:\"label\";s:13:\"goal_tracking\";s:4:\"link\";s:19:\"admin/goal_tracking\";s:4:\"icon\";s:12:\"fa fa-shield\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:50;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"70\";s:5:\"label\";s:11:\"departments\";s:4:\"link\";s:17:\"admin/departments\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:51;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"71\";s:5:\"label\";s:7:\"holiday\";s:4:\"link\";s:13:\"admin/holiday\";s:4:\"icon\";s:21:\"fa fa-calendar-plus-o\";s:6:\"parent\";s:2:\"73\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:52;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"72\";s:5:\"label\";s:16:\"leave_management\";s:4:\"link\";s:22:\"admin/leave_management\";s:4:\"icon\";s:11:\"fa fa-plane\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:53;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"73\";s:5:\"label\";s:9:\"utilities\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:10:\"fa fa-gift\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:54;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"74\";s:5:\"label\";s:8:\"overtime\";s:4:\"link\";s:24:\"admin/utilities/overtime\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:55;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"75\";s:5:\"label\";s:12:\"office_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-codepen\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2019-05-01 10:22:56\";s:6:\"status\";s:1:\"1\";}i:56;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"76\";s:5:\"label\";s:14:\"stock_category\";s:4:\"link\";s:26:\"admin/stock/stock_category\";s:4:\"icon\";s:13:\"fa fa-sliders\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:57;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"77\";s:5:\"label\";s:12:\"manage_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:13:\"fa fa-archive\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:58;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"78\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:59;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"79\";s:5:\"label\";s:12:\"stock_report\";s:4:\"link\";s:18:\"admin/stock/report\";s:4:\"icon\";s:16:\"fa fa-line-chart\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-25 12:48:25\";s:6:\"status\";s:1:\"1\";}i:60;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"81\";s:5:\"label\";s:10:\"stock_list\";s:4:\"link\";s:22:\"admin/stock/stock_list\";s:4:\"icon\";s:20:\"fa fa-stack-exchange\";s:6:\"parent\";s:2:\"75\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-26 10:11:10\";s:6:\"status\";s:1:\"1\";}i:61;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"82\";s:5:\"label\";s:12:\"assign_stock\";s:4:\"link\";s:24:\"admin/stock/assign_stock\";s:4:\"icon\";s:16:\"fa fa-align-left\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:62;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"83\";s:5:\"label\";s:19:\"assign_stock_report\";s:4:\"link\";s:31:\"admin/stock/assign_stock_report\";s:4:\"icon\";s:15:\"fa fa-bar-chart\";s:6:\"parent\";s:2:\"78\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:63;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"84\";s:5:\"label\";s:13:\"stock_history\";s:4:\"link\";s:25:\"admin/stock/stock_history\";s:4:\"icon\";s:17:\"fa fa-file-text-o\";s:6:\"parent\";s:2:\"77\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:55:02\";s:6:\"status\";s:1:\"1\";}i:64;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"85\";s:5:\"label\";s:11:\"performance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:14:\"fa fa-dribbble\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:65;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"86\";s:5:\"label\";s:21:\"performance_indicator\";s:4:\"link\";s:39:\"admin/performance/performance_indicator\";s:4:\"icon\";s:12:\"fa fa-random\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:66;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"87\";s:5:\"label\";s:18:\"performance_report\";s:4:\"link\";s:36:\"admin/performance/performance_report\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:67;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"88\";s:5:\"label\";s:14:\"give_appraisal\";s:4:\"link\";s:44:\"admin/performance/give_performance_appraisal\";s:4:\"icon\";s:10:\"fa fa-plus\";s:6:\"parent\";s:2:\"85\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:23\";s:6:\"status\";s:1:\"1\";}i:68;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"89\";s:5:\"label\";s:7:\"payroll\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:69;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"90\";s:5:\"label\";s:21:\"manage_salary_details\";s:4:\"link\";s:35:\"admin/payroll/manage_salary_details\";s:4:\"icon\";s:9:\"fa fa-usd\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:70;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"91\";s:5:\"label\";s:20:\"employee_salary_list\";s:4:\"link\";s:34:\"admin/payroll/employee_salary_list\";s:4:\"icon\";s:17:\"fa fa-user-secret\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:71;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"92\";s:5:\"label\";s:12:\"make_payment\";s:4:\"link\";s:26:\"admin/payroll/make_payment\";s:4:\"icon\";s:11:\"fa fa-tasks\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:72;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"93\";s:5:\"label\";s:16:\"generate_payslip\";s:4:\"link\";s:30:\"admin/payroll/generate_payslip\";s:4:\"icon\";s:13:\"fa fa-list-ul\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:73;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"94\";s:5:\"label\";s:15:\"salary_template\";s:4:\"link\";s:29:\"admin/payroll/salary_template\";s:4:\"icon\";s:11:\"fa fa-money\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:74;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"95\";s:5:\"label\";s:11:\"hourly_rate\";s:4:\"link\";s:25:\"admin/payroll/hourly_rate\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:75;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"96\";s:5:\"label\";s:15:\"payroll_summary\";s:4:\"link\";s:29:\"admin/payroll/payroll_summary\";s:4:\"icon\";s:18:\"fa fa-camera-retro\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2017-04-23 02:06:37\";s:6:\"status\";s:1:\"1\";}i:76;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"97\";s:5:\"label\";s:14:\"provident_fund\";s:4:\"link\";s:28:\"admin/payroll/provident_fund\";s:4:\"icon\";s:15:\"fa fa-briefcase\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:77;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"98\";s:5:\"label\";s:14:\"advance_salary\";s:4:\"link\";s:28:\"admin/payroll/advance_salary\";s:4:\"icon\";s:19:\"fa fa-cc-mastercard\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2017-06-10 08:04:23\";s:6:\"status\";s:1:\"1\";}i:78;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"99\";s:5:\"label\";s:14:\"employee_award\";s:4:\"link\";s:11:\"admin/award\";s:4:\"icon\";s:12:\"fa fa-trophy\";s:6:\"parent\";s:2:\"89\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2017-06-10 08:05:47\";s:6:\"status\";s:1:\"1\";}i:79;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"100\";s:5:\"label\";s:13:\"announcements\";s:4:\"link\";s:19:\"admin/announcements\";s:4:\"icon\";s:19:\"fa fa-bullhorn icon\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:80;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"101\";s:5:\"label\";s:8:\"training\";s:4:\"link\";s:14:\"admin/training\";s:4:\"icon\";s:14:\"fa fa-suitcase\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:81;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"102\";s:5:\"label\";s:12:\"job_circular\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"fa fa-globe\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:82;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"103\";s:5:\"label\";s:11:\"jobs_posted\";s:4:\"link\";s:30:\"admin/job_circular/jobs_posted\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:83;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"104\";s:5:\"label\";s:17:\"jobs_applications\";s:4:\"link\";s:36:\"admin/job_circular/jobs_applications\";s:4:\"icon\";s:13:\"fa fa-compass\";s:6:\"parent\";s:3:\"102\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:84;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"105\";s:5:\"label\";s:10:\"attendance\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:85;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"106\";s:5:\"label\";s:18:\"timechange_request\";s:4:\"link\";s:35:\"admin/attendance/timechange_request\";s:4:\"icon\";s:16:\"fa fa-calendar-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:86;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"107\";s:5:\"label\";s:17:\"attendance_report\";s:4:\"link\";s:34:\"admin/attendance/attendance_report\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:87;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"108\";s:5:\"label\";s:12:\"time_history\";s:4:\"link\";s:29:\"admin/attendance/time_history\";s:4:\"icon\";s:13:\"fa fa-clock-o\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-30 02:50:21\";s:6:\"status\";s:1:\"1\";}i:88;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"109\";s:5:\"label\";s:9:\"pull-down\";s:4:\"link\";s:0:\"\";s:4:\"icon\";s:0:\"\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2016-05-31 06:43:20\";s:6:\"status\";s:1:\"0\";}i:89;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"110\";s:5:\"label\";s:11:\"filemanager\";s:4:\"link\";s:17:\"admin/filemanager\";s:4:\"icon\";s:10:\"fa fa-file\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:90;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"111\";s:5:\"label\";s:15:\"company_details\";s:4:\"link\";s:14:\"admin/settings\";s:4:\"icon\";s:23:\"fa fa-fw fa-info-circle\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:91;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"112\";s:5:\"label\";s:15:\"system_settings\";s:4:\"link\";s:21:\"admin/settings/system\";s:4:\"icon\";s:19:\"fa fa-fw fa-desktop\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:92;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"113\";s:5:\"label\";s:14:\"email_settings\";s:4:\"link\";s:20:\"admin/settings/email\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-25 11:08:46\";s:6:\"status\";s:1:\"2\";}i:93;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"114\";s:5:\"label\";s:15:\"email_templates\";s:4:\"link\";s:24:\"admin/settings/templates\";s:4:\"icon\";s:25:\"fa fa-fw fa-pencil-square\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:94;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"115\";s:5:\"label\";s:17:\"email_integration\";s:4:\"link\";s:32:\"admin/settings/email_integration\";s:4:\"icon\";s:22:\"fa fa-fw fa-envelope-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:95;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"116\";s:5:\"label\";s:16:\"payment_settings\";s:4:\"link\";s:23:\"admin/settings/payments\";s:4:\"icon\";s:18:\"fa fa-fw fa-dollar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"7\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:96;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"117\";s:5:\"label\";s:16:\"invoice_settings\";s:4:\"link\";s:22:\"admin/settings/invoice\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:97;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"118\";s:5:\"label\";s:17:\"estimate_settings\";s:4:\"link\";s:23:\"admin/settings/estimate\";s:4:\"icon\";s:18:\"fa fa-fw fa-file-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:98;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"119\";s:5:\"label\";s:22:\"tickets_leads_settings\";s:4:\"link\";s:22:\"admin/settings/tickets\";s:4:\"icon\";s:18:\"fa fa-fw fa-ticket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"14\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:99;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"120\";s:5:\"label\";s:14:\"theme_settings\";s:4:\"link\";s:20:\"admin/settings/theme\";s:4:\"icon\";s:16:\"fa fa-fw fa-code\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"20\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:100;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"121\";s:5:\"label\";s:12:\"working_days\";s:4:\"link\";s:27:\"admin/settings/working_days\";s:4:\"icon\";s:20:\"fa fa-fw fa-calendar\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"22\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:101;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"122\";s:5:\"label\";s:14:\"leave_category\";s:4:\"link\";s:29:\"admin/settings/leave_category\";s:4:\"icon\";s:21:\"fa fa-fw fa-pagelines\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"23\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:102;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"123\";s:5:\"label\";s:15:\"income_category\";s:4:\"link\";s:30:\"admin/settings/income_category\";s:4:\"icon\";s:23:\"fa fa-fw fa-certificate\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"24\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:103;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"124\";s:5:\"label\";s:16:\"expense_category\";s:4:\"link\";s:31:\"admin/settings/expense_category\";s:4:\"icon\";s:17:\"fa fa-fw fa-tasks\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"25\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:104;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"125\";s:5:\"label\";s:14:\"customer_group\";s:4:\"link\";s:29:\"admin/settings/customer_group\";s:4:\"icon\";s:17:\"fa fa-fw fa-users\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"26\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:105;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"127\";s:5:\"label\";s:11:\"lead_status\";s:4:\"link\";s:26:\"admin/settings/lead_status\";s:4:\"icon\";s:19:\"fa fa-fw fa-list-ul\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"16\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:106;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"128\";s:5:\"label\";s:11:\"lead_source\";s:4:\"link\";s:26:\"admin/settings/lead_source\";s:4:\"icon\";s:22:\"fa fa-fw fa-arrow-down\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"17\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:107;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"129\";s:5:\"label\";s:26:\"opportunities_state_reason\";s:4:\"link\";s:41:\"admin/settings/opportunities_state_reason\";s:4:\"icon\";s:24:\"fa fa-fw fa-dot-circle-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"19\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:108;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"130\";s:5:\"label\";s:12:\"custom_field\";s:4:\"link\";s:27:\"admin/settings/custom_field\";s:4:\"icon\";s:18:\"fa fa-fw fa-star-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:109;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"131\";s:5:\"label\";s:14:\"payment_method\";s:4:\"link\";s:29:\"admin/settings/payment_method\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"29\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:110;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"132\";s:5:\"label\";s:7:\"cronjob\";s:4:\"link\";s:22:\"admin/settings/cronjob\";s:4:\"icon\";s:18:\"fa fa-fw fa-contao\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:111;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"133\";s:5:\"label\";s:15:\"menu_allocation\";s:4:\"link\";s:30:\"admin/settings/menu_allocation\";s:4:\"icon\";s:22:\"fa fa-fw fa fa-compass\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:112;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"134\";s:5:\"label\";s:12:\"notification\";s:4:\"link\";s:27:\"admin/settings/notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"33\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:113;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"135\";s:5:\"label\";s:18:\"email_notification\";s:4:\"link\";s:33:\"admin/settings/email_notification\";s:4:\"icon\";s:18:\"fa fa-fw fa-bell-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"34\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:114;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"136\";s:5:\"label\";s:15:\"database_backup\";s:4:\"link\";s:30:\"admin/settings/database_backup\";s:4:\"icon\";s:20:\"fa fa-fw fa-database\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"35\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:115;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"137\";s:5:\"label\";s:12:\"translations\";s:4:\"link\";s:27:\"admin/settings/translations\";s:4:\"icon\";s:20:\"fa fa-fw fa-language\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"36\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:116;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"138\";s:5:\"label\";s:13:\"system_update\";s:4:\"link\";s:28:\"admin/settings/system_update\";s:4:\"icon\";s:27:\"fa fa-fw fa-pencil-square-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"37\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:117;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"139\";s:5:\"label\";s:12:\"private_chat\";s:4:\"link\";s:18:\"chat/conversations\";s:4:\"icon\";s:14:\"fa fa-envelope\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"28\";s:4:\"time\";s:19:\"2018-01-07 01:05:18\";s:6:\"status\";s:1:\"1\";}i:118;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"140\";s:5:\"label\";s:9:\"proposals\";s:4:\"link\";s:15:\"admin/proposals\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}i:119;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"141\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:21:\"fa fa-question-circle\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:120;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"142\";s:5:\"label\";s:10:\"categories\";s:4:\"link\";s:30:\"admin/knowledgebase/categories\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:121;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"143\";s:5:\"label\";s:8:\"articles\";s:4:\"link\";s:28:\"admin/knowledgebase/articles\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:122;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"144\";s:5:\"label\";s:13:\"knowledgebase\";s:4:\"link\";s:19:\"admin/knowledgebase\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"141\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:123;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"145\";s:5:\"label\";s:18:\"dashboard_settings\";s:4:\"link\";s:24:\"admin/settings/dashboard\";s:4:\"icon\";s:21:\"fa fa-fw fa-dashboard\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"21\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:124;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"146\";s:5:\"label\";s:20:\"transactions_reports\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2018-05-13 06:29:51\";s:6:\"status\";s:1:\"1\";}i:125;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"147\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:25:\"admin/report/sales_report\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:2:\"42\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2018-01-06 19:12:23\";s:6:\"status\";s:1:\"1\";}i:126;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"148\";s:5:\"label\";s:15:\"mark_attendance\";s:4:\"link\";s:21:\"admin/mark_attendance\";s:4:\"icon\";s:15:\"fa fa-file-text\";s:6:\"parent\";s:3:\"105\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2018-03-07 00:45:25\";s:6:\"status\";s:1:\"1\";}i:127;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"149\";s:5:\"label\";s:10:\"allowed_ip\";s:4:\"link\";s:25:\"admin/settings/allowed_ip\";s:4:\"icon\";s:12:\"fa fa-server\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"27\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:128;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"150\";s:5:\"label\";s:5:\"stock\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:11:\"icon-layers\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"8\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:129;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"151\";s:5:\"label\";s:8:\"supplier\";s:4:\"link\";s:14:\"admin/supplier\";s:4:\"icon\";s:14:\"icon-briefcase\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:130;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"152\";s:5:\"label\";s:8:\"purchase\";s:4:\"link\";s:14:\"admin/purchase\";s:4:\"icon\";s:12:\"icon-handbag\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2019-05-01 12:10:52\";s:6:\"status\";s:1:\"1\";}i:131;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"153\";s:5:\"label\";s:12:\"return_stock\";s:4:\"link\";s:18:\"admin/return_stock\";s:4:\"icon\";s:14:\"icon-share-alt\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2019-05-05 10:19:30\";s:6:\"status\";s:1:\"1\";}i:132;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"154\";s:5:\"label\";s:16:\"purchase_payment\";s:4:\"link\";s:27:\"admin/purchase/all_payments\";s:4:\"icon\";s:16:\"icon-credit-card\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2019-05-05 07:53:11\";s:6:\"status\";s:1:\"1\";}i:133;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"155\";s:5:\"label\";s:17:\"purchase_settings\";s:4:\"link\";s:23:\"admin/settings/purchase\";s:4:\"icon\";s:18:\"fa-fw icon-handbag\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"12\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:134;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"156\";s:5:\"label\";s:11:\"credit_note\";s:4:\"link\";s:17:\"admin/credit_note\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-09 20:32:05\";s:6:\"status\";s:1:\"1\";}i:135;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"157\";s:5:\"label\";s:20:\"credit_note_settings\";s:4:\"link\";s:26:\"admin/settings/credit_note\";s:4:\"icon\";s:17:\"fa fa-fw fa-money\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:136;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"158\";s:5:\"label\";s:18:\"proposals_settings\";s:4:\"link\";s:24:\"admin/settings/proposals\";s:4:\"icon\";s:16:\"fa fa-fw fa-leaf\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:137;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"159\";s:5:\"label\";s:17:\"projects_settings\";s:4:\"link\";s:23:\"admin/settings/projects\";s:4:\"icon\";s:25:\"fa fa-fw fa-folder-open-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:138;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"160\";s:5:\"label\";s:4:\"tags\";s:4:\"link\";s:19:\"admin/settings/tags\";s:4:\"icon\";s:16:\"fa fa-fw fa-tags\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:139;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"161\";s:5:\"label\";s:9:\"lead_form\";s:4:\"link\";s:25:\"admin/leads/all_lead_form\";s:4:\"icon\";s:18:\"fa fa-fw fa-rocket\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"18\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:140;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"162\";s:5:\"label\";s:21:\"transactions_settings\";s:4:\"link\";s:27:\"admin/settings/transactions\";s:4:\"icon\";s:22:\"fa fa-fw fa-building-o\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"15\";s:4:\"time\";s:19:\"2021-07-30 00:18:09\";s:6:\"status\";s:1:\"2\";}i:141;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"163\";s:5:\"label\";s:12:\"sms_settings\";s:4:\"link\";s:27:\"admin/settings/sms_settings\";s:4:\"icon\";s:20:\"fa fa-fw fa-envelope\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-07-30 00:18:08\";s:6:\"status\";s:1:\"2\";}i:142;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"164\";s:5:\"label\";s:9:\"pos_sales\";s:4:\"link\";s:23:\"admin/invoice/pos_sales\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2021-10-15 18:53:10\";s:6:\"status\";s:1:\"1\";}i:143;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"186\";s:5:\"label\";s:9:\"warehouse\";s:4:\"link\";s:22:\"admin/warehouse/manage\";s:4:\"icon\";s:16:\"fa fa-building-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2021-10-18 03:24:24\";s:6:\"status\";s:1:\"1\";}i:144;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"187\";s:5:\"label\";s:12:\"transferItem\";s:4:\"link\";s:24:\"admin/items/transferItem\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:3:\"150\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2021-10-14 05:56:08\";s:6:\"status\";s:1:\"1\";}i:145;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"203\";s:5:\"label\";s:13:\"award_setting\";s:4:\"link\";s:20:\"admin/settings/award\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"30\";s:4:\"time\";s:19:\"2022-01-18 23:51:40\";s:6:\"status\";s:1:\"2\";}i:146;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"204\";s:5:\"label\";s:18:\"award_rule_setting\";s:4:\"link\";s:34:\"admin/settings/award_rule_settingh\";s:4:\"icon\";s:10:\"fa fa-star\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"31\";s:4:\"time\";s:19:\"2022-01-19 03:53:50\";s:6:\"status\";s:1:\"2\";}i:147;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"205\";s:5:\"label\";s:22:\"award_program_settings\";s:4:\"link\";s:37:\"admin/settings/award_program_settings\";s:4:\"icon\";s:9:\"fa fa-cog\";s:6:\"parent\";s:2:\"25\";s:4:\"sort\";s:2:\"32\";s:4:\"time\";s:19:\"2022-01-20 03:17:30\";s:6:\"status\";s:1:\"2\";}i:148;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"206\";s:5:\"label\";s:19:\"client_award_points\";s:4:\"link\";s:27:\"admin/invoice/client_awards\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2022-01-20 19:39:41\";s:6:\"status\";s:1:\"1\";}i:149;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"207\";s:5:\"label\";s:20:\"best_selling_product\";s:4:\"link\";s:18:\"admin/best_selling\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:2:\"11\";s:4:\"time\";s:19:\"2022-01-21 00:43:52\";s:6:\"status\";s:1:\"1\";}i:150;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"209\";s:5:\"label\";s:7:\"warning\";s:4:\"link\";s:13:\"admin/warning\";s:4:\"icon\";s:13:\"fa fa-warning\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2022-08-07 06:47:01\";s:6:\"status\";s:1:\"1\";}i:151;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"210\";s:5:\"label\";s:9:\"promotion\";s:4:\"link\";s:15:\"admin/promotion\";s:4:\"icon\";s:21:\"fa fa-arrow-circle-up\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"4\";s:4:\"time\";s:19:\"2022-08-07 06:49:28\";s:6:\"status\";s:1:\"1\";}i:152;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"211\";s:5:\"label\";s:11:\"termination\";s:4:\"link\";s:17:\"admin/termination\";s:4:\"icon\";s:12:\"fa fa-eraser\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2022-08-07 06:50:45\";s:6:\"status\";s:1:\"1\";}i:153;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:3:\"212\";s:5:\"label\";s:11:\"resignation\";s:4:\"link\";s:17:\"admin/resignation\";s:4:\"icon\";s:14:\"fa fa-scissors\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"6\";s:4:\"time\";s:19:\"2022-08-07 06:54:31\";s:6:\"status\";s:1:\"1\";}}');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r5c4l6csfek0rr0bg8pp36r0mj28tmfd', '5.31.213.51', 1772088258, '__ci_last_regenerate|i:1772088258;menu_active_id|a:3:{i:0;s:2:\"94\";i:1;s:2:\"89\";i:2;s:1:\"0\";}url|s:33:\"admin/payroll/salary_templateList\";user_roll|a:10:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772087754;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');
INSERT INTO `tbl_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tp5thqksa8ojl3n34l5eq2rbcs8dqjfs', '5.31.213.51', 1772087558, '__ci_last_regenerate|i:1772087558;menu_active_id|a:2:{i:0;s:2:\"24\";i:1;s:1:\"0\";}url|s:19:\"admin/user/userList\";user_roll|a:10:{i:0;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"1\";s:5:\"label\";s:9:\"dashboard\";s:4:\"link\";s:15:\"admin/dashboard\";s:4:\"icon\";s:15:\"fa fa-dashboard\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-22 19:39:36\";s:6:\"status\";s:1:\"1\";}i:1;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"2\";s:5:\"label\";s:8:\"calendar\";s:4:\"link\";s:14:\"admin/calendar\";s:4:\"icon\";s:14:\"fa fa-calendar\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:2;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"4\";s:5:\"label\";s:6:\"client\";s:4:\"link\";s:26:\"admin/client/manage_client\";s:4:\"icon\";s:11:\"fa fa-users\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"13\";s:4:\"time\";s:19:\"2018-01-07 01:05:17\";s:6:\"status\";s:1:\"1\";}i:3;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"5\";s:5:\"label\";s:7:\"mailbox\";s:4:\"link\";s:13:\"admin/mailbox\";s:4:\"icon\";s:16:\"fa fa-envelope-o\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"2\";s:4:\"time\";s:19:\"2017-06-10 08:16:25\";s:6:\"status\";s:1:\"1\";}i:4;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:1:\"6\";s:5:\"label\";s:7:\"tickets\";s:4:\"link\";s:13:\"admin/tickets\";s:4:\"icon\";s:12:\"fa fa-ticket\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:2:\"10\";s:4:\"time\";s:19:\"2018-06-08 07:39:39\";s:6:\"status\";s:1:\"1\";}i:5;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"12\";s:5:\"label\";s:5:\"sales\";s:4:\"link\";s:1:\"#\";s:4:\"icon\";s:19:\"fa fa-shopping-cart\";s:6:\"parent\";s:1:\"0\";s:4:\"sort\";s:1:\"9\";s:4:\"time\";s:19:\"2017-06-10 08:02:58\";s:6:\"status\";s:1:\"1\";}i:6;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"13\";s:5:\"label\";s:7:\"invoice\";s:4:\"link\";s:28:\"admin/invoice/manage_invoice\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"0\";s:4:\"time\";s:19:\"2017-04-23 13:57:23\";s:6:\"status\";s:1:\"1\";}i:7;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"14\";s:5:\"label\";s:9:\"estimates\";s:4:\"link\";s:15:\"admin/estimates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"1\";s:4:\"time\";s:19:\"2017-06-10 08:02:05\";s:6:\"status\";s:1:\"1\";}i:8;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"15\";s:5:\"label\";s:17:\"payments_received\";s:4:\"link\";s:26:\"admin/invoice/all_payments\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"3\";s:4:\"time\";s:19:\"2017-04-23 13:57:24\";s:6:\"status\";s:1:\"1\";}i:9;O:8:\"stdClass\":8:{s:7:\"menu_id\";s:2:\"16\";s:5:\"label\";s:9:\"tax_rates\";s:4:\"link\";s:23:\"admin/invoice/tax_rates\";s:4:\"icon\";s:14:\"fa fa-circle-o\";s:6:\"parent\";s:2:\"12\";s:4:\"sort\";s:1:\"5\";s:4:\"time\";s:19:\"2018-01-07 01:05:16\";s:6:\"status\";s:1:\"1\";}}user_name|s:8:\"adminerp\";email|s:14:\"alpha@mail.com\";name|s:17:\"HAYAT MANPOWER.AE\";photo|s:20:\"uploads/Untitled.jpg\";user_id|s:1:\"5\";last_login|s:19:\"2026-02-25 16:17:40\";online_time|i:1772085113;loggedin|b:1;user_type|s:1:\"1\";user_flag|s:1:\"1\";direction|s:3:\"ltr\";warehouse_id|N;designations_id|s:1:\"0\";');


#
# TABLE STRUCTURE FOR: tbl_status
#

DROP TABLE IF EXISTS `tbl_status`;

CREATE TABLE `tbl_status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status` varchar(200) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (1, 'answered');
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (2, 'closed');
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (3, 'open');
INSERT INTO `tbl_status` (`status_id`, `status`) VALUES (5, 'in_progress');


#
# TABLE STRUCTURE FOR: tbl_stock
#

DROP TABLE IF EXISTS `tbl_stock`;

CREATE TABLE `tbl_stock` (
  `stock_id` int NOT NULL AUTO_INCREMENT,
  `stock_sub_category_id` int DEFAULT NULL,
  `item_name` varchar(200) NOT NULL,
  `total_stock` int DEFAULT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_stock_category
#

DROP TABLE IF EXISTS `tbl_stock_category`;

CREATE TABLE `tbl_stock_category` (
  `stock_category_id` int NOT NULL AUTO_INCREMENT,
  `stock_category` varchar(200) NOT NULL,
  PRIMARY KEY (`stock_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_stock_sub_category
#

DROP TABLE IF EXISTS `tbl_stock_sub_category`;

CREATE TABLE `tbl_stock_sub_category` (
  `stock_sub_category_id` int NOT NULL AUTO_INCREMENT,
  `stock_category_id` int NOT NULL,
  `stock_sub_category` varchar(200) NOT NULL,
  PRIMARY KEY (`stock_sub_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_suppliers
#

DROP TABLE IF EXISTS `tbl_suppliers`;

CREATE TABLE `tbl_suppliers` (
  `supplier_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` text,
  `vat` varchar(200) DEFAULT NULL,
  `permission` text,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_tags
#

DROP TABLE IF EXISTS `tbl_tags`;

CREATE TABLE `tbl_tags` (
  `tag_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL,
  `style` text,
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_task
#

DROP TABLE IF EXISTS `tbl_task`;

CREATE TABLE `tbl_task` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `project_id` int DEFAULT NULL,
  `milestones_id` int DEFAULT NULL,
  `opportunities_id` int DEFAULT NULL,
  `goal_tracking_id` int DEFAULT NULL,
  `sub_task_id` int DEFAULT NULL,
  `transactions_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `task_name` varchar(200) DEFAULT NULL,
  `task_description` text,
  `task_start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `task_created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `task_status` varchar(30) DEFAULT NULL,
  `task_progress` int DEFAULT NULL,
  `calculate_progress` varchar(200) DEFAULT NULL,
  `task_hour` varchar(10) DEFAULT NULL,
  `tasks_notes` text,
  `timer_status` enum('on','off') NOT NULL DEFAULT 'off',
  `timer_started_by` varchar(300) DEFAULT NULL,
  `start_time` varchar(300) DEFAULT NULL,
  `logged_time` varchar(300) DEFAULT '0',
  `leads_id` int DEFAULT NULL,
  `bug_id` int DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `permission` text,
  `client_visible` varchar(5) DEFAULT NULL,
  `custom_date` text,
  `hourly_rate` decimal(18,2) DEFAULT '0.00',
  `billable` varchar(20) NOT NULL DEFAULT 'No',
  `index_no` int DEFAULT NULL,
  `milestones_order` int NOT NULL DEFAULT '0',
  `tags` text,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_task_comment
#

DROP TABLE IF EXISTS `tbl_task_comment`;

CREATE TABLE `tbl_task_comment` (
  `task_comment_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `comment` text NOT NULL,
  `comments_attachment` text,
  `comment_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `module` varchar(50) DEFAULT NULL,
  `module_field_id` int DEFAULT NULL,
  `attachments_id` int DEFAULT '0',
  `uploaded_files_id` int DEFAULT '0',
  `comments_reply_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`task_comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_tasks_timer
#

DROP TABLE IF EXISTS `tbl_tasks_timer`;

CREATE TABLE `tbl_tasks_timer` (
  `tasks_timer_id` int NOT NULL AUTO_INCREMENT,
  `task_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `timer_status` enum('on','off') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT 'off',
  `start_time` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `end_time` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `date_timed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reason` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `edited_by` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  PRIMARY KEY (`tasks_timer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_tax_rates
#

DROP TABLE IF EXISTS `tbl_tax_rates`;

CREATE TABLE `tbl_tax_rates` (
  `tax_rates_id` int NOT NULL AUTO_INCREMENT,
  `tax_rate_name` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL DEFAULT '0',
  `tax_rate_percent` decimal(10,2) NOT NULL DEFAULT '0.00',
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  KEY `Index 1` (`tax_rates_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_terminations
#

DROP TABLE IF EXISTS `tbl_terminations`;

CREATE TABLE `tbl_terminations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `attachment` text,
  `notice_date` date NOT NULL,
  `termination_date` date NOT NULL,
  `termination_type` varchar(190) NOT NULL,
  `description` varchar(190) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_tickets
#

DROP TABLE IF EXISTS `tbl_tickets`;

CREATE TABLE `tbl_tickets` (
  `tickets_id` int NOT NULL AUTO_INCREMENT,
  `project_id` int DEFAULT '0',
  `ticket_code` varchar(32) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `subject` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `body` text,
  `status` varchar(200) DEFAULT NULL,
  `departments_id` int DEFAULT NULL,
  `reporter` int DEFAULT '0',
  `priority` varchar(50) DEFAULT NULL,
  `upload_file` text,
  `comment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `permission` text,
  `tags` text,
  `last_reply` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`tickets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_tickets_replies
#

DROP TABLE IF EXISTS `tbl_tickets_replies`;

CREATE TABLE `tbl_tickets_replies` (
  `tickets_replies_id` int NOT NULL AUTO_INCREMENT,
  `tickets_id` bigint DEFAULT NULL,
  `ticket_reply_id` int DEFAULT '0',
  `body` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `replier` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `replierid` int DEFAULT NULL,
  `attachment` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tickets_replies_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_todo
#

DROP TABLE IF EXISTS `tbl_todo`;

CREATE TABLE `tbl_todo` (
  `todo_id` int NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_id` longtext CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date NOT NULL,
  `status` int NOT NULL DEFAULT '0' COMMENT '1= in_progress 2= on hold 3= done',
  `assigned` int NOT NULL DEFAULT '0',
  `order` int NOT NULL,
  PRIMARY KEY (`todo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

#
# TABLE STRUCTURE FOR: tbl_training
#

DROP TABLE IF EXISTS `tbl_training`;

CREATE TABLE `tbl_training` (
  `training_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `assigned_by` int NOT NULL,
  `training_name` varchar(100) NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `finish_date` date NOT NULL,
  `training_cost` varchar(300) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = pending, 1 = started, 2 = completed, 3 = terminated',
  `performance` tinyint(1) DEFAULT '0' COMMENT '0 = not concluded, 1 = satisfactory, 2 = average, 3 = poor, 4 = excellent',
  `remarks` text NOT NULL,
  `upload_file` text,
  `permission` text,
  PRIMARY KEY (`training_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_transactions
#

DROP TABLE IF EXISTS `tbl_transactions`;

CREATE TABLE `tbl_transactions` (
  `transactions_id` int NOT NULL AUTO_INCREMENT,
  `project_id` int DEFAULT NULL,
  `account_id` int NOT NULL,
  `invoices_id` int NOT NULL DEFAULT '0',
  `warehouse_id` int DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `transaction_prefix` varchar(50) DEFAULT NULL,
  `type` enum('Income','Expense','Transfer') NOT NULL,
  `category_id` int DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `recurring_type` varchar(50) DEFAULT NULL,
  `repeat_every` int DEFAULT NULL,
  `recurring` enum('Yes','No') DEFAULT NULL,
  `total_cycles` int DEFAULT NULL,
  `done_cycles` int DEFAULT NULL,
  `custom_recurring` tinyint(1) DEFAULT '0',
  `last_recurring_date` date DEFAULT NULL,
  `recurring_from` int DEFAULT NULL,
  `paid_by` int DEFAULT '0',
  `payment_methods_id` varchar(100) DEFAULT NULL,
  `reference` varchar(200) NOT NULL,
  `status` enum('non_approved','paid','unpaid') DEFAULT 'non_approved',
  `notes` text NOT NULL,
  `tags` text,
  `tax` decimal(18,2) NOT NULL DEFAULT '0.00',
  `date` date NOT NULL,
  `create_date` datetime DEFAULT NULL,
  `debit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `total_balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `transfer_id` int NOT NULL DEFAULT '0',
  `permission` text,
  `attachement` text,
  `client_visible` enum('Yes','No') NOT NULL DEFAULT 'No',
  `added_by` int NOT NULL DEFAULT '0',
  `paid` int NOT NULL DEFAULT '0',
  `billable` enum('Yes','No') NOT NULL DEFAULT 'No',
  `deposit` text,
  `deposit_2` text,
  `under_55` text,
  PRIMARY KEY (`transactions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_transfer
#

DROP TABLE IF EXISTS `tbl_transfer`;

CREATE TABLE `tbl_transfer` (
  `transfer_id` int NOT NULL AUTO_INCREMENT,
  `to_account_id` int NOT NULL,
  `from_account_id` int NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `payment_methods_id` int NOT NULL,
  `reference` varchar(200) NOT NULL,
  `status` enum('Cleared','Uncleared','Reconciled','Void') NOT NULL DEFAULT 'Cleared',
  `notes` text NOT NULL,
  `date` date NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'Transfer',
  `permission` mediumtext,
  `attachement` mediumtext,
  PRIMARY KEY (`transfer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_transfer_item
#

DROP TABLE IF EXISTS `tbl_transfer_item`;

CREATE TABLE `tbl_transfer_item` (
  `transfer_item_id` int NOT NULL AUTO_INCREMENT,
  `reference_no` varchar(50) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `status` enum('pending','complete','send','approved','rejected') DEFAULT NULL,
  `shipping_cost` varchar(100) DEFAULT NULL,
  `notes` text,
  `attachment` text,
  `from_warehouse_id` int NOT NULL,
  `to_warehouse_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `show_quantity_as` varchar(20) DEFAULT NULL,
  `tax` decimal(18,3) DEFAULT NULL,
  `total_tax` text NOT NULL,
  `permission` text,
  PRIMARY KEY (`transfer_item_id`),
  UNIQUE KEY `reference_no` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_transfer_itemlist
#

DROP TABLE IF EXISTS `tbl_transfer_itemlist`;

CREATE TABLE `tbl_transfer_itemlist` (
  `transfer_itemList_id` int NOT NULL AUTO_INCREMENT,
  `transfer_item_id` int NOT NULL,
  `saved_items_id` int DEFAULT '0',
  `warehouse_id` int DEFAULT NULL,
  `item_tax_rate` decimal(10,2) DEFAULT '0.00',
  `item_tax_name` text,
  `item_name` varchar(150) DEFAULT 'Item Name',
  `item_desc` longtext,
  `unit_cost` decimal(10,2) DEFAULT '0.00',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `item_tax_total` decimal(10,2) DEFAULT '0.00',
  `total_cost` decimal(10,2) DEFAULT '0.00',
  `date_saved` timestamp NOT NULL DEFAULT '2018-12-12 19:00:00',
  `unit` varchar(200) DEFAULT NULL,
  `hsn_code` text,
  `order` int DEFAULT '0',
  PRIMARY KEY (`transfer_itemList_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_uploaded_files
#

DROP TABLE IF EXISTS `tbl_uploaded_files`;

CREATE TABLE `tbl_uploaded_files` (
  `uploaded_files_id` int NOT NULL,
  `files_id` int NOT NULL,
  `files` text NOT NULL,
  `uploaded_path` text NOT NULL,
  `file_name` text NOT NULL,
  `size` int NOT NULL,
  `ext` varchar(100) NOT NULL,
  `is_image` int NOT NULL,
  `image_width` int NOT NULL,
  `image_height` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_user_role
#

DROP TABLE IF EXISTS `tbl_user_role`;

CREATE TABLE `tbl_user_role` (
  `user_role_id` int NOT NULL AUTO_INCREMENT,
  `designations_id` int DEFAULT NULL,
  `menu_id` int NOT NULL,
  `view` int DEFAULT '0',
  `created` int DEFAULT '0',
  `edited` int DEFAULT '0',
  `deleted` int DEFAULT '0',
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=583 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (100, 2, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (101, 2, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (102, 2, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (103, 2, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (104, 2, 209, 209, 209, 209, 209);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (105, 2, 57, 57, 57, 57, 57);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (106, 2, 54, 54, 54, 54, 54);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (107, 2, 58, 58, 58, 58, 58);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (108, 2, 56, 56, 56, 56, 56);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (109, 2, 55, 55, 55, 55, 55);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (110, 2, 150, 150, 150, 150, 150);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (111, 2, 39, 39, 39, 39, 39);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (112, 2, 151, 151, 151, 151, 151);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (113, 2, 152, 152, 152, 152, 152);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (114, 2, 153, 153, 153, 153, 153);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (115, 2, 186, 186, 186, 186, 186);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (116, 2, 154, 154, 154, 154, 154);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (117, 2, 187, 187, 187, 187, 187);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (118, 2, 12, 12, 12, 12, 12);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (119, 2, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (120, 2, 164, 164, 164, 164, 164);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (121, 2, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (122, 2, 156, 156, 156, 156, 156);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (123, 2, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (124, 2, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (125, 2, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (126, 2, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (127, 2, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (128, 2, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (129, 2, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (130, 2, 206, 206, 206, 206, 206);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (131, 2, 207, 207, 207, 207, 207);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (132, 2, 6, 6, 6, 6, 6);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (133, 2, 141, 141, 141, 141, 141);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (134, 2, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (135, 2, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (136, 2, 142, 142, 142, 142, 142);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (137, 2, 29, 29, 29, 29, 29);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (138, 2, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (139, 2, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (140, 2, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (141, 2, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (142, 2, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (143, 2, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (144, 2, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (145, 2, 70, 70, 70, 70, 70);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (146, 2, 75, 75, 75, 75, 75);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (147, 2, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (148, 2, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (149, 2, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (150, 2, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (151, 2, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (152, 2, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (153, 2, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (154, 2, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (155, 2, 89, 89, 89, 89, 89);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (156, 2, 94, 94, 94, 94, 94);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (157, 2, 95, 95, 95, 95, 95);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (158, 2, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (159, 2, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (160, 2, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (161, 2, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (162, 2, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (163, 2, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (164, 2, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (165, 2, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (166, 2, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (167, 2, 85, 85, 85, 85, 85);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (168, 2, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (169, 2, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (170, 2, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (171, 2, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (172, 2, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (173, 2, 100, 100, 100, 100, 100);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (174, 2, 73, 73, 73, 73, 73);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (175, 2, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (176, 2, 69, 69, 69, 69, 69);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (177, 2, 42, 42, 42, 42, 42);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (178, 2, 147, 147, 147, 147, 147);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (179, 2, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (180, 2, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (181, 2, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (182, 2, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (183, 2, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (184, 2, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (185, 2, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (186, 2, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (187, 2, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (188, 2, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (189, 2, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (190, 2, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (191, 2, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (192, 2, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (193, 2, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (194, 2, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (195, 2, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (196, 2, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (197, 2, 24, 24, 24, 24, 24);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (198, 2, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (199, 3, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (200, 3, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (201, 3, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (202, 3, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (203, 3, 209, 209, 209, 209, 209);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (204, 3, 57, 57, 57, 57, 57);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (205, 3, 54, 54, 54, 54, 54);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (206, 3, 58, 58, 58, 58, 58);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (207, 3, 56, 56, 56, 56, 56);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (208, 3, 55, 55, 55, 55, 55);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (209, 3, 150, 150, 150, 150, 150);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (210, 3, 39, 39, 39, 39, 39);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (211, 3, 151, 151, 151, 151, 151);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (212, 3, 152, 152, 152, 152, 152);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (213, 3, 153, 153, 153, 153, 153);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (214, 3, 186, 186, 186, 186, 186);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (215, 3, 154, 154, 154, 154, 154);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (216, 3, 187, 187, 187, 187, 187);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (217, 3, 12, 12, 12, 12, 12);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (218, 3, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (219, 3, 164, 164, 164, 164, 164);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (220, 3, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (221, 3, 156, 156, 156, 156, 156);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (222, 3, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (223, 3, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (224, 3, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (225, 3, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (226, 3, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (227, 3, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (228, 3, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (229, 3, 206, 206, 206, 206, 206);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (230, 3, 207, 207, 207, 207, 207);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (231, 3, 6, 6, 6, 6, 6);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (232, 3, 141, 141, 141, 141, 141);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (233, 3, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (234, 3, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (235, 3, 142, 142, 142, 142, 142);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (236, 3, 29, 29, 29, 29, 29);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (237, 3, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (238, 3, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (239, 3, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (240, 3, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (241, 3, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (242, 3, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (243, 3, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (244, 3, 70, 70, 70, 70, 70);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (245, 3, 75, 75, 75, 75, 75);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (246, 3, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (247, 3, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (248, 3, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (249, 3, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (250, 3, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (251, 3, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (252, 3, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (253, 3, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (254, 3, 89, 89, 89, 89, 89);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (255, 3, 94, 94, 94, 94, 94);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (256, 3, 95, 95, 95, 95, 95);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (257, 3, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (258, 3, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (259, 3, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (260, 3, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (261, 3, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (262, 3, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (263, 3, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (264, 3, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (265, 3, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (266, 3, 85, 85, 85, 85, 85);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (267, 3, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (268, 3, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (269, 3, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (270, 3, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (271, 3, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (272, 3, 100, 100, 100, 100, 100);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (273, 3, 73, 73, 73, 73, 73);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (274, 3, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (275, 3, 69, 69, 69, 69, 69);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (276, 3, 42, 42, 42, 42, 42);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (277, 3, 147, 147, 147, 147, 147);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (278, 3, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (279, 3, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (280, 3, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (281, 3, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (282, 3, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (283, 3, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (284, 3, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (285, 3, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (286, 3, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (287, 3, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (288, 3, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (289, 3, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (290, 3, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (291, 3, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (292, 3, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (293, 3, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (294, 3, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (295, 3, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (296, 3, 24, 24, 24, 24, 24);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (297, 3, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (298, 4, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (299, 4, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (300, 4, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (301, 4, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (302, 4, 209, 209, 209, 209, 209);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (303, 4, 57, 57, 57, 57, 57);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (304, 4, 210, 210, 210, 210, 210);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (305, 4, 54, 54, 54, 54, 54);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (306, 4, 211, 211, 211, 211, 211);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (307, 4, 58, 58, 58, 58, 58);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (308, 4, 212, 212, 212, 212, 212);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (309, 4, 56, 56, 56, 56, 56);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (310, 4, 55, 55, 55, 55, 55);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (311, 4, 150, 150, 150, 150, 150);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (312, 4, 39, 39, 39, 39, 39);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (313, 4, 151, 151, 151, 151, 151);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (314, 4, 152, 152, 152, 152, 152);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (315, 4, 153, 153, 153, 153, 153);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (316, 4, 186, 186, 186, 186, 186);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (317, 4, 154, 154, 154, 154, 154);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (318, 4, 187, 187, 187, 187, 187);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (319, 4, 12, 12, 12, 12, 12);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (320, 4, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (321, 4, 164, 164, 164, 164, 164);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (322, 4, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (323, 4, 156, 156, 156, 156, 156);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (324, 4, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (325, 4, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (326, 4, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (327, 4, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (328, 4, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (329, 4, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (330, 4, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (331, 4, 206, 206, 206, 206, 206);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (332, 4, 207, 207, 207, 207, 207);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (333, 4, 6, 6, 6, 6, 6);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (334, 4, 141, 141, 141, 141, 141);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (335, 4, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (336, 4, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (337, 4, 142, 142, 142, 142, 142);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (338, 4, 29, 29, 29, 29, 29);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (339, 4, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (340, 4, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (341, 4, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (342, 4, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (343, 4, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (344, 4, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (345, 4, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (346, 4, 4, 4, 4, 4, 4);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (347, 4, 70, 70, 70, 70, 70);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (348, 4, 75, 75, 75, 75, 75);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (349, 4, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (350, 4, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (351, 4, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (352, 4, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (353, 4, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (354, 4, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (355, 4, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (356, 4, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (357, 4, 105, 105, 105, 105, 105);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (358, 4, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (359, 4, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (360, 4, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (361, 4, 148, 148, 148, 148, 148);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (362, 4, 102, 102, 102, 102, 102);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (363, 4, 103, 103, 103, 103, 103);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (364, 4, 104, 104, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (365, 4, 89, 89, 89, 89, 89);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (366, 4, 94, 94, 94, 94, 94);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (367, 4, 95, 95, 95, 95, 95);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (368, 4, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (369, 4, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (370, 4, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (371, 4, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (372, 4, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (373, 4, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (374, 4, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (375, 4, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (376, 4, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (377, 4, 85, 85, 85, 85, 85);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (378, 4, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (379, 4, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (380, 4, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (381, 4, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (382, 4, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (383, 4, 100, 100, 100, 100, 100);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (384, 4, 73, 73, 73, 73, 73);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (385, 4, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (386, 4, 69, 69, 69, 69, 69);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (387, 4, 42, 42, 42, 42, 42);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (388, 4, 147, 147, 147, 147, 147);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (389, 4, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (390, 4, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (391, 4, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (392, 4, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (393, 4, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (394, 4, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (395, 4, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (396, 4, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (397, 4, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (398, 4, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (399, 4, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (400, 4, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (401, 4, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (402, 4, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (403, 4, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (404, 4, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (405, 4, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (406, 4, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (407, 4, 24, 24, 24, 24, 24);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (408, 4, 25, 25, 25, 25, 25);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (409, 4, 111, 111, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (410, 4, 112, 112, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (411, 4, 113, 113, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (412, 4, 163, 163, 163, 163, 163);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (413, 4, 114, 114, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (414, 4, 115, 115, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (415, 4, 116, 116, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (416, 4, 117, 117, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (417, 4, 157, 157, 157, 157, 157);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (418, 4, 118, 118, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (419, 4, 158, 158, 158, 158, 158);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (420, 4, 155, 155, 155, 155, 155);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (421, 4, 159, 159, 159, 159, 159);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (422, 4, 119, 119, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (423, 4, 162, 162, 162, 162, 162);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (424, 4, 127, 127, 127, 127, 127);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (425, 4, 128, 128, 128, 128, 128);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (426, 4, 161, 161, 161, 161, 161);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (427, 4, 129, 129, 129, 129, 129);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (428, 4, 120, 120, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (429, 4, 145, 145, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (430, 4, 121, 121, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (431, 4, 122, 122, 122, 122, 122);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (432, 4, 123, 123, 123, 123, 123);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (433, 4, 124, 124, 124, 124, 124);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (434, 4, 125, 125, 125, 125, 125);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (435, 4, 149, 149, 149, 149, 149);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (436, 4, 130, 130, 130, 130, 130);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (437, 4, 131, 131, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (438, 4, 160, 160, 160, 160, 160);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (439, 4, 203, 203, 203, 203, 203);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (440, 4, 132, 132, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (441, 4, 204, 204, 204, 204, 204);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (442, 4, 133, 133, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (443, 4, 205, 205, 205, 205, 205);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (444, 4, 134, 134, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (445, 4, 135, 135, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (446, 4, 136, 136, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (447, 4, 137, 137, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (448, 4, 138, 138, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (449, 4, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (450, 4, 139, 139, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (451, 5, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (452, 5, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (453, 5, 105, 105, 105, 105, 105);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (454, 5, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (455, 5, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (456, 5, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (457, 5, 148, 148, 148, 148, 148);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (458, 6, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (459, 6, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (460, 6, 105, 105, 105, 105, 105);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (461, 6, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (462, 6, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (463, 6, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (464, 6, 148, 148, 148, 148, 148);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (465, 7, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (466, 7, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (467, 7, 105, 105, 105, 105, 105);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (468, 7, 108, 108, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (469, 7, 106, 106, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (470, 7, 107, 107, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (471, 7, 148, 148, 148, 148, 148);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (472, 1, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (473, 1, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (474, 1, 5, 5, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (475, 1, 110, 110, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (476, 1, 209, 209, 209, 209, 209);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (477, 1, 57, 57, 57, 57, 57);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (478, 1, 54, 54, 54, 54, 54);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (479, 1, 58, 58, 58, 58, 58);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (480, 1, 56, 56, 56, 56, 56);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (481, 1, 55, 55, 55, 55, 55);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (482, 1, 150, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (483, 1, 39, 39, 39, 39, 39);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (484, 1, 151, 151, 151, 151, 151);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (485, 1, 152, 152, 152, 152, 152);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (486, 1, 153, 153, 153, 153, 153);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (487, 1, 186, 186, 186, 186, 186);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (488, 1, 154, 154, 154, 154, 154);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (489, 1, 187, 187, 187, 187, 187);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (490, 1, 12, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (491, 1, 13, 13, 13, 13, 13);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (492, 1, 164, 164, 164, 164, 164);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (493, 1, 14, 14, 14, 14, 14);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (494, 1, 156, 156, 156, 156, 156);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (495, 1, 51, 51, 51, 51, 51);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (496, 1, 15, 15, 15, 15, 15);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (497, 1, 140, 140, 140, 140, 140);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (498, 1, 16, 16, 16, 16, 16);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (499, 1, 21, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (500, 1, 22, 22, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (501, 1, 23, 23, 23, 23, 23);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (502, 1, 206, 206, 206, 206, 206);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (503, 1, 207, 207, 207, 207, 207);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (504, 1, 6, 6, 6, 6, 6);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (505, 1, 141, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (506, 1, 144, 144, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (507, 1, 143, 143, 143, 143, 143);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (508, 1, 142, 142, 142, 142, 142);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (509, 1, 29, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (510, 1, 31, 31, 31, 31, 31);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (511, 1, 30, 30, 30, 30, 30);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (512, 1, 32, 32, 32, 32, 32);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (513, 1, 33, 33, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (514, 1, 52, 52, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (515, 1, 34, 34, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (516, 1, 36, 36, 36, 36, 36);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (517, 1, 70, 70, 70, 70, 70);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (518, 1, 75, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (519, 1, 76, 76, 76, 76, 76);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (520, 1, 81, 81, 81, 81, 81);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (521, 1, 77, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (522, 1, 84, 84, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (523, 1, 78, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (524, 1, 82, 82, 82, 82, 82);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (525, 1, 83, 83, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (526, 1, 79, 79, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (527, 1, 89, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (528, 1, 94, 94, 94, 94, 94);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (529, 1, 95, 95, 95, 95, 95);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (530, 1, 90, 90, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (531, 1, 91, 91, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (532, 1, 92, 92, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (533, 1, 93, 93, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (534, 1, 96, 96, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (535, 1, 98, 98, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (536, 1, 97, 97, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (537, 1, 74, 74, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (538, 1, 99, 99, 99, 99, 99);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (539, 1, 85, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (540, 1, 86, 86, 86, 86, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (541, 1, 88, 88, 88, 88, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (542, 1, 87, 87, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (543, 1, 72, 72, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (544, 1, 101, 101, 101, 101, 101);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (545, 1, 100, 100, 100, 100, 100);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (546, 1, 73, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (547, 1, 71, 71, 71, 71, 71);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (548, 1, 69, 69, 69, 69, 69);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (549, 1, 42, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (550, 1, 147, 147, 147, 147, 147);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (551, 1, 146, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (552, 1, 43, 43, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (553, 1, 45, 45, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (554, 1, 44, 44, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (555, 1, 46, 46, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (556, 1, 47, 47, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (557, 1, 53, 53, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (558, 1, 48, 48, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (559, 1, 49, 49, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (560, 1, 50, 50, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (561, 1, 59, 0, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (562, 1, 66, 66, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (563, 1, 67, 67, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (564, 1, 68, 68, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (565, 1, 60, 60, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (566, 1, 61, 61, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (567, 1, 62, 62, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (568, 1, 63, 63, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (569, 1, 24, 24, 24, 24, 24);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (570, 1, 26, 26, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (571, 8, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (572, 8, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (573, 9, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (574, 9, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (575, 10, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (576, 10, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (577, 11, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (578, 11, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (579, 12, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (580, 12, 2, 2, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (581, 13, 1, 1, 0, 0, 0);
INSERT INTO `tbl_user_role` (`user_role_id`, `designations_id`, `menu_id`, `view`, `created`, `edited`, `deleted`) VALUES (582, 13, 2, 2, 0, 0, 0);


#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `role_id` int NOT NULL DEFAULT '2',
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `new_password_key` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `new_email_key` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `last_ip` varchar(40) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `online_time` int NOT NULL DEFAULT '0' COMMENT '1 = online 0 = offline ',
  `permission` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  `active_email` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_email_type` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_encription` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_action` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_host_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_username` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `smtp_additional_flag` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `last_postmaster_run` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `media_path_slug` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (5, 'adminerp', '6abfcc59dc4e59d889fd97ba5e0888b0be2c7e49b75672891dcde36f661af6e8ffb938eb81e535ffdfdff68d5e2a0da82921d3da479e95b42ec6916c60ac3c6f', 'alpha@mail.com', 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, '2026-02-25 16:17:40', '2025-11-02 11:09:52', '2026-02-26 12:31:06', 1772094666, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (6, 'karthik', '1909fcb615a4eb7c75ba4e480d16f7c271646861314e84bc0aad5d7f471718bd6d0f5778cb3d6f12ca43909468b5d539bc3ae0a281a9e632e9251d142de9f4fc', 'karthik@hayatjadidagroups.com', 1, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.202.195.223', '2025-11-19 13:54:34', NULL, '2025-11-19 13:54:34', 1763546063, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (8, 'YAHYA', '830af5c4ccf93636c8eab2c0299724c6d166484711a44a8ffee68d441a42c28cff7857853ea6541d1931ccdbefb6af45efd24f55bbc3d9b3ef5c0aa50ac6507f', 'yahya@hayatjadidagroups.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', '2025-11-02 21:20:37', NULL, '2026-01-21 14:12:28', 0, '{\"6\":[\"view\"]}', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (9, 'joel', '251ad7d401deaf4d4868036e5aa7bdcfc135df654e4623cece48ed0c6950c65a3c4f7203744e6d83b2f31254adf0b680d6a22e31bea9b5dc35dcf3cc601c573d', 'joel@hayatjadidagroups.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', '2025-11-07 19:58:08', NULL, '2025-11-10 11:12:17', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (10, 'ERIC', '9bdf5aecdbbd2ace036a8ccb229dc92d52c2eaea0c9931b78358cd3499de9a0d509104e3b4e274541499a0e26ba770e52b5f27883ac848502e974839a01aaa0b', 'eric@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 11:15:24', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (12, 'AYASH', '2a66b397df802ffca6deeb3e6e570930a9fb64d3a0b82515cf87189621b5f5a1e929f442bd577789c4797aeb68c8787d0d4b21627def280f31067682358409d5', 'ayash@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 09:58:24', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (13, 'ABDURAHMAN', '11e5be46a24f46a60903453bba2d822216c039ae872fb5ef70437451c65e480db859b23d9bc71b3e09e5155fcf1793d6161c4ed014eaf5c07e65bafb69c0e838', 'abdurahman@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 11:23:08', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (14, 'JEMAL', 'fe5e2e1ea3f6b01d2c1d9514a428e6f6bb71062c983205738a131871524141fe8b3fd8600e2e62ae27625005be1db5773fcb7e3900cfed13a6735c3495dcab51', 'jemal@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-21 12:58:13', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (15, 'UMER', '607dd8c6f04c6469898a5827e169f99191f352ae1e04f745d710e77f8b7ab06f25dbac228610edd86d3aea5e26fd24e571d408e0431a3cba011ce67e7fe4fa8b', 'umer@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', '2025-11-10 11:39:21', NULL, '2026-02-25 10:12:41', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (16, 'DIRIBA', 'a9b5cb0c4e221c76f69e0601f745ff5dcb8670c6247cc8b95478c55b99a0bdd6ef1097c3eb1f72c476f0e8705b989892d6ac025d62f9b7722156fb63aab4ae16', 'diriba@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 11:55:24', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (17, 'ADISU', '0484dbefbb4e5bf720cd9624372f126e7bf7773ab30c28d6aa85297081f5ca5d382453235218edd9cc6a75ac43c8c258ed878ea132e12253aba3288c64365e2a', 'adisu@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 13:06:14', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (18, 'EFREM', 'c2596b7bc8d01f508eece7645e80e767be53148e5dffceb99dce78cad7c34d2176ce131b21083695d7065be9b4f48234597818c8b21524bcf667f4d1975d766a', 'efrem@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 13:40:57', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (19, 'AJAIB', 'd8822e7d4c3da16581db1229afde6264965c205f85d144d495657aba2b7e85dab62a3b30379c25bc1e160106be689295ee7a3c6128f9c2f1634fb95004503fbc', 'ajaib@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 13:43:42', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (20, 'ABDULJEBAR', '5667d6fb05fe132c859b504d4cb2dd5a926e128da992184a4f01d9d6d7933e6176b12fdea080852aa308f24c9622227e813c903b092cb46422f6bf90ce7c5db2', 'abduljebar@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 10:29:32', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (23, 'HAJI', '564443eb7baea8224461e7770dedfa1abcab99c2b0d635be249ffb8ac703df37856fe16f56277bdbb43716bdbc537e25a10ce3cefe33d903619a7bb20da4ab17', 'haji@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 13:56:06', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (24, 'JAINULABUDEEN ', '55f92b90236ed947391f370457e55ff3c72fa4981aad1531237b4e636ad47bf7c867d0b4e788ad84b8b604e33d3a39f18912457bc24475f75aa5e80ce5111b63', 'jain@hayat.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '94.203.229.18', NULL, NULL, '2025-11-10 14:00:32', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (25, 'muktar', 'a3919cbeccf07fc34c0a5d13d9dbf49ce5cc01a96e50781ca66f3aed2bec004edfb84ff05aef388310b0011d3a70936b7533e018e089ebdaf315d22f8d3bf9a5', 'muktar@hayatjadidagroups.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 10:34:03', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (26, 'gutama', 'bb341ae432fd012ea62a711a130322b9ca71632906944ba6e0764e4c5816d4c067a9a3c9f4d713373ae6cde1710856f4f0a43ea9d6b651f52351a440ea2c5ae7', 'gutama@hayatjadidagroups.com', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '106.51.171.243', NULL, NULL, '2025-11-19 13:42:29', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (29, 'ANANIOUS', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'ANANIOUS@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:32:02', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (30, 'JOSEPH', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'JOSEPH@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 12:14:03', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (31, 'SOLOMON', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'SOLOMON@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 12:21:32', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (32, 'AWOL', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'AWOL@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 12:24:30', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (33, 'CHINNAIYAN', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'CHINNAIYAN@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:17:12', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (34, 'ISAAC', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'ISAAC@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 12:31:30', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (35, 'PERIYASAMY', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'PERIYASAMY@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-24 15:23:53', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (36, 'RICHMOND', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'RICHMOND@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:24:24', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (37, 'GIDEON', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'GIDEON@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:46:55', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (38, 'PRINCE', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'PRINCE@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 12:54:50', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (39, 'KARTHIKEYAN', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'KARTHIKEYAN@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:49:12', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (40, 'PANJAVARNAM', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'PANJAVARNAM@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 13:26:08', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (41, 'FRANK', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'FRANK@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 13:36:23', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (42, 'EMMANUEL', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'EMMANUEL@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 13:40:02', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (43, 'ISSAC OPOKU', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'ISSACOPOKU@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 13:31:42', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (44, 'EMMANUEL EFFUM', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'EMMANUELEFFUM@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:54:44', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (45, 'ISSAHAHMED', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'ISSAHAHMED@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:56:00', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (46, 'COLLINS BOYE', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'COLLINSBOYE@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:57:12', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (47, 'ELIJAH YENNUBE LAARI', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'ELIJAH@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 13:58:04', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (48, 'EMILE NSHEMEZIMANA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'EMILENSHEMEZIMANA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 14:14:28', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (49, 'THERENCE NITANGA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'THERENCENITANGA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 14:15:51', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (50, 'PRIMACY MURINDWA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'PRIMACYMURINDWA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 16:29:21', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (51, 'BISMARK MINTAH', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'BISMARKMINTAH@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 16:31:11', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (52, 'ANDREW LUVUUMA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'ANDREWLUVUUMA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 16:32:08', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (53, 'JEAN MARIE SINIREMERA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'JEANMARIESINIREMERA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 16:34:11', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (54, 'EMMANUEL OFORI', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'EMMANUELOFORI@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-23 16:52:32', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (55, 'BALPOLO KWABENA BIIFA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'BALPOLOKWABENABIIFA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:16:56', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (56, 'LATIF INUSAH', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'LATIFINUSAH@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:17:48', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (57, 'SADIQUE ALI KAVUNGATHODI', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'SADIQUEALIKAVUNGATHODI@HAYAT.COM', 1, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:20:25', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (58, 'RANJITHKUMAR PALANIVEL', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'RANJITHKUMARPALANIVEL@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:21:21', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (59, 'EBENEZER SENIOR KWAKYE', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'EBENEZERSENIORKWAKYE@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:22:20', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (60, 'KELVIN LORD BUABENG ASANTE', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'KELVINRDBUABENGASANTE@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:23:57', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (61, 'AMOS KWABENA ATTA', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'AMOSKWABENAATTA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:24:56', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (62, 'EMMANUEL KOFI AGYAPONG', 'b4f31801acdbc4b0c2da6b599542322dc3e96f952535ec02b8463fc1d41748b8310c2d6940f39b51444e78dbef73ff9e196a89c13e80df6efc6eabf393deec49', 'EMMANUELKOFIAGYAPONG@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.242.87', NULL, NULL, '2026-01-24 13:25:49', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (63, 'DANIEL ANNOR', '467d8c3d800e7db9ba021fcce5871a75e3326c24b9f83f180d08c5f18a665cd3771b7b75649e4b27dc674a7b8ec10bca67bbaaeb7ec801bf0a289f2941ac5423', 'DANIEL@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:40:17', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (64, 'DAVID SAKYI', 'cc9939cc10947d3186501e0fb0df7eb881ccbee16d9c462cf665f8b3133210f25d2ce4f23ebf37603637b17bee297deb55c3655b52a60cfedbd2a1ffa7510491', 'DAVIDSAKYI@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:43:06', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (65, 'DEVASUNDAR', '703fa377e57aef956152db99b8667d15610d13d6d91f4f82d2a58b11b7e480ea5bac1a6cafdb5657b2a23ead4cd46cec3a42c8276f34814e4ef2879f455c77a6', 'DEVASUNDARRASAPAN@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:45:13', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (66, 'ALEX OPOKU', '0f5639c0adaaf1929c7d175fd17df47323ed841bcb66ef4b10172be098d98d9f3cf14d24a0bcf950c85854932b860b30f7463749af17e69abbb97f3cdb51de4c', 'ALEXOPOKU@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 15:31:02', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (67, 'MICHAEL OPPONG', 'aad2d1579d33fa5799167ae06c3b6050c34d8867fc5a5243ebb7d874f5d530c32a77fc434a3b61bde4ad9f262435d31d59e21ca346b79dd74af475dabdac4c4a', 'MICHAELOPPONG@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:48:51', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (68, 'BISMARK', '04f7d35f3728c6bc985ca2777960b9ecb3e48575b7274bd6d15a04bb80c2338d99c2d61f648f6dc1fb1417e12eac89384a8a093eaca41065cf1c5463fa58c7f2', 'BISMARK@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:56:10', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (69, 'SHOWKAT', '470b07fd0414882aea8b24c0b9ed93c3eef1fe10c1803020f84326e2e883c67e1d889ab5570edb17ed164f285fbb003622077175fe51563e7ca16a1d99da50c0', 'SHOWKAT@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 12:58:38', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (70, 'MOROALI', 'aa16b02e66e5298b89818cbdd9dde554866f9cc520fccc610a21f9660eac9a887b72ba33e0b4addb95a32b34536b7e0eb3bea1c1ec6fa9f18296be9e2323fec6', 'MOROALI@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 13:00:28', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (71, 'JOUHARA', '9c8bc0c87a188ed723b00205ff4709cf4b5a2d7b085244555bbab85955e2d2ffce326397baad1c24d7376e3cd7edef2002d2bf078f3250582a7deb6d2de2b1e6', 'JOUHARA@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 15:14:25', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (72, 'SAMPSON', '7633194a323877b2b4b95d64b4b2740082c867d876e112a5881783d5598ff9062a347f27c7e18db58a0bbfbedbf20e3dc7fee6fb1911c7f16b70fe9e1a9281bd', 'SAMPSON@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 15:15:56', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (73, 'IBRAHIM', 'c69cf4e2efe2ebd2a79714daa1e8f40aa744939a44f2be9beb2ef9f197dcb41c4413afa00ae78e132320e70b1f6092bd798c42a0ed6f31ff1e60b9860392a3ea', 'IBRAHIM@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-23 15:36:13', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (74, 'JAMES POURSAH KONFAREH', 'e8209a14bb8e81a47cfedd8944eeb62d455c5f88f9f2fa3378c20a757f98ef1612b2da68698a61e675a519f71ed9fc94103db37afb8fdb9887308faf3f9b3ee3', 'JAMES@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-24 11:03:19', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `tbl_users` (`user_id`, `username`, `password`, `email`, `role_id`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`, `online_time`, `permission`, `active_email`, `smtp_email_type`, `smtp_encription`, `smtp_action`, `smtp_host_name`, `smtp_username`, `smtp_password`, `smtp_port`, `smtp_additional_flag`, `last_postmaster_run`, `media_path_slug`) VALUES (75, 'AFZAL', '050c0ed1a56fdd144259acffd499722e48c520a831276bb41e830e625476defbc07c99ce9180b8d0bc48a67c0fa56c2187903004db349bd90e24f9085fa6a0d1', 'AFZAL@HAYAT.COM', 3, 1, 0, NULL, NULL, NULL, NULL, NULL, '5.31.213.51', NULL, NULL, '2026-02-25 10:54:37', 0, 'all', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_warehouse
#

DROP TABLE IF EXISTS `tbl_warehouse`;

CREATE TABLE `tbl_warehouse` (
  `warehouse_id` int NOT NULL AUTO_INCREMENT,
  `warehouse_code` varchar(100) DEFAULT NULL,
  `warehouse_name` varchar(250) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address` text,
  `image` text,
  `permission` text,
  `status` enum('published','unpublished') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'published',
  PRIMARY KEY (`warehouse_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

INSERT INTO `tbl_warehouse` (`warehouse_id`, `warehouse_code`, `warehouse_name`, `phone`, `mobile`, `email`, `address`, `image`, `permission`, `status`) VALUES (1, 'WH1', 'WH1', '987456331', '987456331', 'wh@hayatjadidagroups.com', '', NULL, 'all', 'published');
INSERT INTO `tbl_warehouse` (`warehouse_id`, `warehouse_code`, `warehouse_name`, `phone`, `mobile`, `email`, `address`, `image`, `permission`, `status`) VALUES (2, 'HK', 'House Keeping', '+971 50 756 4693', '+971 50 756 4693', 'admin@hayatjadidagroups.com', '', NULL, 'all', 'published');
INSERT INTO `tbl_warehouse` (`warehouse_id`, `warehouse_code`, `warehouse_name`, `phone`, `mobile`, `email`, `address`, `image`, `permission`, `status`) VALUES (3, 'CIVIL', 'CV1', '(+91) 903538319.+918', '987456331', 'accounts@hayatjadidagroups.com', '', NULL, 'all', 'published');


#
# TABLE STRUCTURE FOR: tbl_warehouses_products
#

DROP TABLE IF EXISTS `tbl_warehouses_products`;

CREATE TABLE `tbl_warehouses_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `warehouse_id` int NOT NULL,
  `quantity` decimal(15,4) NOT NULL,
  `rack` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `warehouse_id` (`warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_warnings
#

DROP TABLE IF EXISTS `tbl_warnings`;

CREATE TABLE `tbl_warnings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `warning_to` int NOT NULL,
  `warning_by` int NOT NULL,
  `warning_type` int NOT NULL,
  `attachment` text,
  `subject` varchar(190) NOT NULL,
  `warning_date` date NOT NULL,
  `description` varchar(190) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;

#
# TABLE STRUCTURE FOR: tbl_working_days
#

DROP TABLE IF EXISTS `tbl_working_days`;

CREATE TABLE `tbl_working_days` (
  `working_days_id` int NOT NULL AUTO_INCREMENT,
  `day_id` int NOT NULL,
  `start_hours` varchar(20) NOT NULL,
  `end_hours` varchar(20) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  PRIMARY KEY (`working_days_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

